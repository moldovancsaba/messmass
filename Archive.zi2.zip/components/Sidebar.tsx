'use client';

import React, { useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import styles from './Sidebar.module.css';
import packageJson from '../package.json';
import { useSidebar } from '@/contexts/SidebarContext';
import MaterialIcon from '@/components/MaterialIcon';
import { canAccessMenuItem } from '@/lib/permissions';
import type { UserRole } from '@/lib/users';

const FOCUSABLE_SELECTOR = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';

/* What: Navigation item structure
   Why: Type-safe navigation configuration with Material Icons */
interface NavItem {
  label: string;
  path: string;
  icon: string; // Material Icon name
  iconVariant?: 'outlined' | 'rounded';
}

interface NavSection {
  title: string;
  items: NavItem[];
}

/* What: Responsive sidebar component for admin navigation with role-based filtering
   Why: TailAdmin V2-inspired sidebar with desktop/tablet/mobile variants
   
   Behavior:
   - Desktop (≥1280px): Full-width sidebar with section groups
   - Tablet (768-1279px): Collapsed mini variant (icons only)
   - Mobile (<768px): Overlay drawer with scrim, hamburger toggle
   - Menu items filtered by user role (guest → user → admin → superadmin)
   
   No breadcrumbs (explicitly prohibited by policy) */
export default function Sidebar() {
  const pathname = usePathname();
  /* WHAT: Use shared sidebar context instead of local state
   * WHY: AdminLayout needs to know collapse state to adjust main content margin */
  const { isCollapsed, setIsCollapsed, isMobileOpen, setIsMobileOpen } = useSidebar();
  
  // WHAT: Track user role for menu filtering
  // WHY: Show only menu items user has permission to access
  const [userRole, setUserRole] = useState<UserRole | undefined>(undefined);
  const [loadingRole, setLoadingRole] = useState(true);
  
  // WHAT: Fetch user role on component mount
  // WHY: Determine which menu items to show
  useEffect(() => {
    const fetchUserRole = async () => {
      try {
        const response = await fetch('/api/admin/auth', { cache: 'no-store' });
        if (response.ok) {
          const data = await response.json();
          if (data.user?.role) {
            setUserRole(data.user.role as UserRole);
          }
        }
      } catch (error) {
        console.error('Failed to fetch user role:', error);
      } finally {
        setLoadingRole(false);
      }
    };
    
    fetchUserRole();
  }, []);
  
  /* WHAT: Reorganized navigation structure per user requirements
     WHY: More intuitive order - removed Dashboard (logo serves same purpose),
          grouped logically from core content to admin tools */
  const navSections: NavSection[] = [
    {
      title: 'Core',
      items: [
        { label: 'Partners', path: '/admin/partners', icon: 'handshake' },
        { label: 'Events', path: '/admin/events', icon: 'event' },
        { label: 'Filters', path: '/admin/filter', icon: 'search' },
      ],
    },
    {
      title: 'Management',
      items: [
        { label: 'Users', path: '/admin/users', icon: 'group' },
        { label: 'Insights', path: '/admin/insights', icon: 'lightbulb' },
        { label: 'KYC', path: '/admin/kyc', icon: 'lock' },
        { label: 'Algorithms', path: '/admin/charts', icon: 'trending_up' },
        { label: 'Clicker Manager', path: '/admin/clicker-manager', icon: 'swap_horiz' },
        { label: 'Bitly Manager', path: '/admin/bitly', icon: 'link' },
        { label: 'Hashtag Manager', path: '/admin/hashtags', icon: 'label' },
        { label: 'Category Manager', path: '/admin/categories', icon: 'public' },
      ],
    },
    {
      title: 'System',
      items: [
        { label: 'Reporting', path: '/admin/visualization', icon: 'visibility' },
        { label: 'Style Editor', path: '/admin/styles', icon: 'palette' },
        { label: 'Cache Management', path: '/admin/cache', icon: 'delete' },
      ],
    },
    {
      title: 'Help',
      items: [
        { label: 'User Guide', path: '/admin/help', icon: 'menu_book' },
        { label: 'Main page', path: '/admin/mainpage', icon: 'home' },
        { label: 'Messages', path: '/admin/messages', icon: 'mail' },
      ],
    },
  ];
  
  /* What: Check if current path matches nav item
     Why: Highlight active navigation item for user orientation */
  const isActive = (path: string) => {
    if (path === '/admin') {
      return pathname === '/admin';
    }
    return pathname.startsWith(path);
  };
  
  /* What: Close mobile drawer on route change
     Why: Better UX - user expects drawer to close after navigation */
  useEffect(() => {
    setIsMobileOpen(false);
  }, [pathname, setIsMobileOpen]);
  
  /* What: Close drawer on Escape key
     Why: Accessibility requirement for modal-like overlays */
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMobileOpen) {
        setIsMobileOpen(false);
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isMobileOpen, setIsMobileOpen]);
  
  /* What: Prevent body scroll when mobile drawer is open
     Why: Better UX - focus on drawer, prevent background scrolling */
  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isMobileOpen]);

  /* OPS-ADMIN-01: Focus trap when mobile drawer is open – keep focus inside sidebar */
  const sidebarRef = useRef<HTMLElement | null>(null);
  useEffect(() => {
    if (!isMobileOpen) return;
    const el = document.getElementById('sidebar');
    sidebarRef.current = el;
    const focusables = el ? Array.from(el.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)) : [];
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (first) first.focus();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return;
      const target = document.activeElement as HTMLElement | null;
      if (!el?.contains(target)) return;
      if (e.shiftKey) {
        if (target === first) {
          e.preventDefault();
          last?.focus();
        }
      } else {
        if (target === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isMobileOpen]);

  return (
    <>
      {/* What: Mobile hamburger button
         Why: Toggle drawer on mobile devices */}
      <button
        className={styles.mobileToggle}
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        aria-label="Toggle navigation menu"
        aria-expanded={isMobileOpen}
        aria-controls="sidebar"
      >
        <span className={styles.hamburger}>
          <span></span>
          <span></span>
          <span></span>
        </span>
      </button>
      
      {/* What: Mobile overlay scrim
         Why: Dim background when drawer is open, click to close */}
      {isMobileOpen && (
        <div 
          className={styles.mobileScrim}
          onClick={() => setIsMobileOpen(false)}
          aria-hidden="true"
        />
      )}
      
      {/* WHAT: Desktop/tablet collapse toggle - positioned OUTSIDE sidebar
          WHY: Better UX - clearer affordance for sidebar control */}
      <button
        className={`${styles.collapseToggle} ${isCollapsed ? styles.collapseToggleCollapsed : ''}`}
        onClick={() => setIsCollapsed(!isCollapsed)}
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        title={isCollapsed ? 'Expand' : 'Collapse'}
      >
        {isCollapsed ? '»' : '«'}
      </button>
      
      {/* What: Main sidebar navigation
         Why: Core navigation structure with responsive behavior */}
      <aside
        id="sidebar"
        className={`${styles.sidebar} ${isCollapsed ? styles.collapsed : ''} ${isMobileOpen ? styles.mobileOpen : ''}`}
        role="navigation"
        aria-label="Main navigation"
      >
        {/* What: Sidebar header with logo and collapse toggle
           Why: Branding and responsive control */}
        <div className={styles.sidebarHeader}>
          <Link href="/admin" className={styles.logo}>
            {/* WHAT: Logo icon stays same size in both states
                WHY: Visual consistency - only text hides on collapse */}
            <Image src="/messmass-logo.png" alt="{messmass}" className={styles.logoImage} width={32} height={32} priority />
            
            {/* WHAT: 'messmass' text in Pacifico font, only visible when expanded
                WHY: User-requested branding with Google Font */}
            {!isCollapsed && (
              <span className={styles.logoText}>messmass</span>
            )}
          </Link>
        </div>
        
        {/* What: Scrollable navigation sections with role-based filtering
           Why: Handle many nav items without overflow issues, show only authorized items */}
        <nav className={styles.sidebarNav}>
          {navSections.map((section) => {
            // WHAT: Filter section items based on user role permissions
            // WHY: Only show menu items user has access to
            const visibleItems = section.items.filter(item => 
              !loadingRole && canAccessMenuItem(userRole, item.label)
            );
            
            // WHAT: Skip entire section if no items are visible
            // WHY: Avoid empty sections in navigation
            if (visibleItems.length === 0) {
              return null;
            }
            
            return (
              <div key={section.title} className={styles.navSection}>
                {/* WHAT: Section titles removed to prevent menu jumping
                    WHY: User request - cleaner UI without section headers */}
                
                <ul className={styles.navList}>
                  {visibleItems.map((item) => (
                    <li key={item.path}>
                      <Link
                        href={item.path}
                        className={`${styles.navLink} ${isActive(item.path) ? styles.active : ''}`}
                        title={isCollapsed ? item.label : undefined}
                        aria-current={isActive(item.path) ? 'page' : undefined}
                      >
                        <span className={styles.navIcon}>
                          <MaterialIcon
                            name={item.icon}
                            variant={item.iconVariant || 'outlined'}
                            // WHAT: Fixed fontSize override for sidebar icons
                            // WHY: Sidebar needs larger icons (1.25rem) than MaterialIcon default (1rem)
                            // eslint-disable-next-line react/forbid-dom-props
                            style={{ fontSize: '1.25rem' }}
                          />
                        </span>
                        {!isCollapsed && (
                          <span className={styles.navLabel}>{item.label}</span>
                        )}
                        {isActive(item.path) && !isCollapsed && (
                          <span className={styles.activeIndicator} aria-label="Current page" />
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </nav>
        
        {/* WHAT: Unified footer with copyright and auto-updated version from package.json
           WHY: Single source of truth - reads version dynamically, avoids hardcoded duplicates */}
        <div className={styles.sidebarFooter}>
          {!isCollapsed && (
            <>
              <div className={styles.footerText}>
                © 2025 {'{messmass}'}. All rights reserved.
              </div>
              <div className={styles.versionInfo}>
                <span className={styles.versionLabel}>Version</span>
                <span className={styles.versionNumber}>v{packageJson.version}</span>
              </div>
            </>
          )}
        </div>
      </aside>
    </>
  );
}
