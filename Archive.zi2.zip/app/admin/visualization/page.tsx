'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import ReportChart from '@/app/report/[slug]/ReportChart';
import { ChartConfiguration, ChartCalculationResult, HeroBlockSettings, BlockAlignmentSettings } from '@/lib/chartConfigTypes';
import { calculateActiveCharts } from '@/lib/chartCalculator';
import UnifiedAdminHeroWithSearch from '@/components/UnifiedAdminHeroWithSearch';
import ColoredCard from '@/components/ColoredCard';
import FormModal from '@/components/modals/FormModal';
import ConfirmDialog from '@/components/modals/ConfirmDialog';
import vizStyles from './Visualization.module.css';
import { apiPost, apiPut, apiDelete } from '@/lib/apiClient';
import MaterialIcon from '@/components/MaterialIcon';
import SaveStatusIndicator, { SaveStatus } from '@/components/SaveStatusIndicator';
import { validateBlockForEditor, checkPublishValidity, type EditorBlockInput } from '@/lib/editorValidationAPI';
import type { BlockValidationResult } from '@/lib/editorValidationAPI';

// WHAT: Data visualization block from data_blocks collection
// WHY: Reusable blocks of charts that can be composed into report templates
interface DataVisualizationBlock {
  _id?: string;
  name: string;
  charts: BlockChart[];
  order: number;
  isActive: boolean;
  showTitle?: boolean;
  blockAspectRatio?: string; // R-LAYOUT-02.1: Optional block aspect ratio override (e.g., "4:6")
  tableHeightMultiplier?: number; // Table height control: height = blockWidth × multiplier (0.1 to 5.0)
  createdAt?: string;
  updatedAt?: string;
}

// WHAT: Chart reference within a block
// WHY: Links charts to blocks with layout information
interface BlockChart {
  chartId: string;
  width: number;
  order: number;
  unitSize?: LayoutUnit;
  aspectRatio?: LayoutAspectRatio;
}

type LayoutUnit = 1 | 2;
type LayoutAspectRatio = '1:1' | '2:1' | '16:9' | '9:16';
type LayoutItemType = 'kpi' | 'pie' | 'bar' | 'text' | 'table' | 'image' | 'valuechain';

const LAYOUT_V2_ALLOWED_ASPECT_RATIOS: Record<LayoutItemType, LayoutAspectRatio[]> = {
  kpi: ['1:1'],
  pie: ['1:1'],
  bar: ['1:1', '2:1'],
  text: ['1:1', '2:1'],
  table: ['1:1', '2:1'],
  image: ['1:1', '16:9', '9:16'],
  valuechain: ['1:1']
};

const LAYOUT_V2_ALLOWED_UNIT_SIZES: Record<LayoutItemType, LayoutUnit[]> = {
  kpi: [1],
  pie: [1],
  bar: [1, 2],
  text: [1, 2],
  table: [1, 2],
  image: [1, 2],
  valuechain: [1]
};

const DEFAULT_ASPECT_RATIO: Record<LayoutItemType, LayoutAspectRatio> = {
  kpi: '1:1',
  pie: '1:1',
  bar: '1:1',
  text: '1:1',
  table: '1:1',
  image: '1:1',
  valuechain: '1:1'
};

const ASPECT_RATIO_UNIT_MAP: Record<LayoutAspectRatio, LayoutUnit> = {
  '1:1': 1,
  '2:1': 2,
  '16:9': 2,
  '9:16': 1
};

const ASPECT_RATIO_LABELS: Record<LayoutAspectRatio, string> = {
  '1:1': '1:1 (square)',
  '2:1': '2:1 (wide)',
  '16:9': '16:9 (landscape)',
  '9:16': '9:16 (portrait)'
};

const normalizeUnitSize = (value?: number): LayoutUnit => {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value >= 2 ? 2 : 1;
  }
  return 1;
};

// Available chart type for chart assignment
interface AvailableChart {
  chartId: string;
  title: string;
  type: string;
  order: number;
  isActive: boolean;
  emoji?: string;
}

interface ReportTemplate {
  _id: string;
  name: string;
  type: 'event' | 'partner' | 'global';
  isDefault: boolean;
  dataBlocks: Array<{ blockId: string; order: number }>;
  gridSettings: { desktopUnits: number; tabletUnits: number; mobileUnits: number };
  heroSettings?: HeroBlockSettings;
  alignmentSettings?: BlockAlignmentSettings;
}

export default function VisualizationPage() {
  const router = useRouter();
  const [dataBlocks, setDataBlocks] = useState<DataVisualizationBlock[]>([]);
  const [availableCharts, setAvailableCharts] = useState<AvailableChart[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingBlock, setEditingBlock] = useState<DataVisualizationBlock | null>(null);
  const [showCreateBlock, setShowCreateBlock] = useState(false);
  
  // WHAT: Template selection state
  // WHY: Allow editing different report templates on this page
  const [templates, setTemplates] = useState<ReportTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(null);
  
  // WHAT: Template creation modal state
  // WHY: Allow creating new templates from this page
  const [showCreateTemplate, setShowCreateTemplate] = useState(false);
  const [templateForm, setTemplateForm] = useState({
    name: '',
    description: '',
    type: 'event' as 'event' | 'partner' | 'global',
    isDefault: false
  });
  
  // WHAT: Template management modal state (rename, copy, delete)
  // WHY: Allow managing existing templates
  const [showTemplateEditModal, setShowTemplateEditModal] = useState(false);
  const [templateEditName, setTemplateEditName] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // WHAT: Track which block editors are expanded (default: all collapsed)
  // WHY: Cleaner UX on page load - focus on chart previews, not implementation details
  const [expandedBlocks, setExpandedBlocks] = useState<Set<string>>(new Set());

  // WHAT: Status message for smooth UX feedback (no alerts)
  // WHY: Non-blocking notifications, auto-dismiss after 5 seconds
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // WHAT: Save status tracking for block operations
  // WHY: Provide visual feedback during save operations (like clicker pattern)
  const [blockSaveStatus, setBlockSaveStatus] = useState<SaveStatus>('idle');
  const [templateSaveStatus, setTemplateSaveStatus] = useState<SaveStatus>('idle');

  // Live chart preview state (calculated using the same pipeline as stats pages)
  const [chartConfigs, setChartConfigs] = useState<ChartConfiguration[]>([]);
  const [previewResults, setPreviewResults] = useState<Record<string, ChartCalculationResult>>({});
  const [isCalculating, setIsCalculating] = useState(false);

  // Grid settings for per-block preview alignment
  const [gridUnits, setGridUnits] = useState<{ desktop: number; tablet: number; mobile: number }>({ desktop: 4, tablet: 2, mobile: 1 });
  const [gridForm, setGridForm] = useState<{ desktop: number; tablet: number; mobile: number }>({ desktop: 4, tablet: 2, mobile: 1 });

  // HERO settings state for template configuration
  const [heroSettings, setHeroSettings] = useState<HeroBlockSettings>({
    showEmoji: true,
    showDateInfo: true,
    showExportOptions: true
  });
  const [alignmentSettings, setAlignmentSettings] = useState<BlockAlignmentSettings>({
    alignTitles: true,
    alignDescriptions: true,
    alignCharts: true,
    minElementHeight: undefined
  });



  // Form states for new data block
  const [blockForm, setBlockForm] = useState({
    name: '',
    charts: [] as BlockChart[],
    order: 0,
    isActive: true,
    showTitle: true // NEW: Default to showing title
  });

  const chartConfigMap = useMemo(() => {
    const map = new Map<string, ChartConfiguration>();
    chartConfigs.forEach(config => {
      map.set(config.chartId, config);
    });
    return map;
  }, [chartConfigs]);

  const availableChartTypeMap = useMemo(() => {
    const map = new Map<string, LayoutItemType>();
    availableCharts.forEach(chart => {
      const chartType = chart.type;
      if (chartType === 'kpi' || chartType === 'pie' || chartType === 'bar' || chartType === 'text' || chartType === 'table' || chartType === 'image' || chartType === 'valuechain') {
        map.set(chart.chartId, chartType);
      }
    });
    return map;
  }, [availableCharts]);

  const resolveChartType = useCallback((chartId: string): LayoutItemType => {
    const chartType = availableChartTypeMap.get(chartId) || chartConfigMap.get(chartId)?.type;
    if (chartType === 'kpi' || chartType === 'pie' || chartType === 'bar' || chartType === 'text' || chartType === 'table' || chartType === 'image' || chartType === 'valuechain') {
      return chartType;
    }
    return 'kpi';
  }, [availableChartTypeMap, chartConfigMap]);

  const normalizeChartLayout = useCallback((chart: BlockChart): BlockChart => {
    const chartType = resolveChartType(chart.chartId);
    const allowedAspects = LAYOUT_V2_ALLOWED_ASPECT_RATIOS[chartType] || ['1:1'];
    const allowedUnits = LAYOUT_V2_ALLOWED_UNIT_SIZES[chartType] || [1];

    const configAspectRatio = chartConfigMap.get(chart.chartId)?.aspectRatio;
    const configAspect = (configAspectRatio && ['1:1', '2:1', '16:9', '9:16'].includes(configAspectRatio))
      ? (configAspectRatio as LayoutAspectRatio)
      : undefined;

    let aspectRatio = chart.aspectRatio || configAspect || DEFAULT_ASPECT_RATIO[chartType];
    if (!allowedAspects.includes(aspectRatio)) {
      aspectRatio = allowedAspects[0];
    }

    let unitSize = normalizeUnitSize(chart.unitSize ?? chart.width ?? ASPECT_RATIO_UNIT_MAP[aspectRatio]);
    if (!allowedUnits.includes(unitSize)) {
      unitSize = allowedUnits[0];
    }

    if (chartType === 'image') {
      if (unitSize === 2 && aspectRatio !== '16:9') {
        aspectRatio = '16:9';
      }
      if (unitSize === 1 && aspectRatio === '16:9') {
        aspectRatio = '1:1';
      }
    } else if (chartType === 'bar' || chartType === 'text' || chartType === 'table') {
      if (unitSize === 2 && aspectRatio !== '2:1') {
        aspectRatio = '2:1';
      }
      if (unitSize === 1 && aspectRatio === '2:1') {
        aspectRatio = '1:1';
      }
    } else {
      aspectRatio = '1:1';
      unitSize = 1;
    }

    return {
      ...chart,
      unitSize,
      width: unitSize,
      aspectRatio
    };
  }, [chartConfigMap, resolveChartType]);

  const normalizeBlockForLayoutV2 = useCallback((block: DataVisualizationBlock): DataVisualizationBlock => {
    return {
      ...block,
      charts: block.charts.map(chart => normalizeChartLayout(chart))
    };
  }, [normalizeChartLayout]);

  const getBlockUnitTotal = useCallback((block: DataVisualizationBlock): number => {
    return block.charts.reduce((total, chart) => total + normalizeUnitSize(chart.unitSize ?? chart.width), 0);
  }, []);

  const validateLayoutV2Block = useCallback((block: DataVisualizationBlock): { valid: boolean; error?: string } => {
    const normalizedBlock = normalizeBlockForLayoutV2(block);
    const totalUnits = getBlockUnitTotal(normalizedBlock);
    if (totalUnits > 4) {
      return {
        valid: false,
        error: `Block "${block.name}" exceeds 4-unit capacity (current total: ${totalUnits}).`
      };
    }

    for (const chart of block.charts) {
      const chartType = resolveChartType(chart.chartId);
      const allowedAspects = LAYOUT_V2_ALLOWED_ASPECT_RATIOS[chartType] || ['1:1'];
      const allowedUnits = LAYOUT_V2_ALLOWED_UNIT_SIZES[chartType] || [1];

      if (chart.unitSize !== undefined) {
        const unitSize = normalizeUnitSize(chart.unitSize);
        if (!allowedUnits.includes(unitSize)) {
          return {
            valid: false,
            error: `Chart "${chart.chartId}" uses invalid unit size (${unitSize}) for ${chartType}.`
          };
        }
      }

      if (chart.aspectRatio && !allowedAspects.includes(chart.aspectRatio)) {
        return {
          valid: false,
          error: `Chart "${chart.chartId}" uses invalid aspect ratio (${chart.aspectRatio}) for ${chartType}.`
        };
      }
    }

    return { valid: true };
  }, [getBlockUnitTotal, normalizeBlockForLayoutV2, resolveChartType]);

  const getChartDefaultLayout = useCallback((chartId: string): Pick<BlockChart, 'unitSize' | 'aspectRatio' | 'width'> => {
    const chartType = resolveChartType(chartId);
    const allowedAspects = LAYOUT_V2_ALLOWED_ASPECT_RATIOS[chartType] || ['1:1'];
    const allowedUnits = LAYOUT_V2_ALLOWED_UNIT_SIZES[chartType] || [1];

    const configAspectRatio = chartConfigMap.get(chartId)?.aspectRatio;
    let aspectRatio = (configAspectRatio && ['1:1', '2:1', '16:9', '9:16'].includes(configAspectRatio))
      ? (configAspectRatio as LayoutAspectRatio)
      : DEFAULT_ASPECT_RATIO[chartType];

    if (!allowedAspects.includes(aspectRatio)) {
      aspectRatio = allowedAspects[0];
    }

    let unitSize = ASPECT_RATIO_UNIT_MAP[aspectRatio];
    if (!allowedUnits.includes(unitSize)) {
      unitSize = allowedUnits[0];
    }

    return {
      unitSize,
      width: unitSize,
      aspectRatio
    };
  }, [chartConfigMap, resolveChartType]);

  // WHAT: Helper to show status messages
  // WHY: Replace all alert() calls with smooth, auto-dismissing messages
  const showMessage = useCallback((type: 'success' | 'error' | 'info', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage(null), 5000); // Auto-dismiss after 5 seconds
  }, []);

  useEffect(() => {
    const initializeData = async () => {
      const templates = await loadTemplates();
      await loadUserPreferences(templates); // Pass templates to avoid race condition
      loadAvailableCharts();
      loadChartConfigs();
    };
    
    initializeData();
  }, []);
  
  const loadTemplateConfig = useCallback(async (templateId: string) => {
    try {
      setLoading(true);
      const template = templates.find(t => t._id === templateId);
      if (!template) {
        console.log('❌ Template not found:', templateId);
        return;
      }
      
      console.log('📋 Loading template config for:', template.name);
      console.log('📋 Template dataBlocks:', template.dataBlocks);
      
      // Load data blocks for this template
      const blockIds = template.dataBlocks.map(b => b.blockId).filter((id): id is string => id != null);
      console.log('📋 Block IDs to load:', blockIds);
      
      if (blockIds.length > 0) {
        const response = await fetch('/api/data-blocks');
        const data = await response.json();
        if (data.success) {
          // Filter blocks that belong to this template and sort by order
          const templateBlocks = data.blocks
            .filter((b: DataVisualizationBlock) => b._id && blockIds.includes(b._id))
            .sort((a: DataVisualizationBlock, b: DataVisualizationBlock) => {
              const aRef = template.dataBlocks.find(ref => ref.blockId === a._id);
              const bRef = template.dataBlocks.find(ref => ref.blockId === b._id);
              return (aRef?.order || 0) - (bRef?.order || 0);
            });
          console.log('📋 Loaded template blocks:', templateBlocks.length);
          setDataBlocks(templateBlocks.map(normalizeBlockForLayoutV2));
        }
      } else {
        console.log('📋 No data blocks configured for this template');
        setDataBlocks([]);
      }
      
      // Set grid settings from template
      setGridUnits({
        desktop: template.gridSettings.desktopUnits,
        tablet: template.gridSettings.tabletUnits,
        mobile: template.gridSettings.mobileUnits
      });
      setGridForm({
        desktop: template.gridSettings.desktopUnits,
        tablet: template.gridSettings.tabletUnits,
        mobile: template.gridSettings.mobileUnits
      });

      // Set HERO settings from template (with defaults if not present)
      setHeroSettings({
        showEmoji: template.heroSettings?.showEmoji ?? true,
        showDateInfo: template.heroSettings?.showDateInfo ?? true,
        showExportOptions: template.heroSettings?.showExportOptions ?? true
      });
      // WHAT: Convert null to undefined for TypeScript compatibility
      // WHY: MongoDB stores undefined as null, but TypeScript expects undefined
      setAlignmentSettings({
        alignTitles: template.alignmentSettings?.alignTitles ?? true,
        alignDescriptions: template.alignmentSettings?.alignDescriptions ?? true,
        alignCharts: template.alignmentSettings?.alignCharts ?? true,
        minElementHeight: template.alignmentSettings?.minElementHeight || undefined
      });
      
    } catch (error) {
      console.error('Failed to load template config:', error);
    } finally {
      setLoading(false);
    }
  }, [templates, normalizeBlockForLayoutV2]);

  // WHAT: Load blocks and grid for selected template
  // WHY: Each template has its own visualization config
  useEffect(() => {
    if (selectedTemplateId) {
      loadTemplateConfig(selectedTemplateId);
    }
  }, [selectedTemplateId, loadTemplateConfig]);

  // WHAT: Load user preferences (last selected template)
  // WHY: Remember user's last choice across browsers and sessions
  const loadUserPreferences = async (availableTemplates: ReportTemplate[]) => {
    try {
      const response = await fetch('/api/user-preferences');
      const data = await response.json();
      
      // Handle authentication errors gracefully
      if (!data.success) {
        // Fall through to default template selection
      } else if (data.preferences?.lastSelectedTemplateId) {
        const preferredTemplateId = data.preferences.lastSelectedTemplateId;
        
        // Verify the preferred template still exists
        const templateExists = availableTemplates.some(t => t._id === preferredTemplateId);
        
        if (templateExists) {
          setSelectedTemplateId(preferredTemplateId);
          return;
        }
      }
      
      // Fall back to default template if no preference or preference is invalid
      const defaultTemplate = availableTemplates.find((t: ReportTemplate) => t.isDefault);
      if (defaultTemplate) {
        setSelectedTemplateId(defaultTemplate._id);
      } else if (availableTemplates.length > 0) {
        setSelectedTemplateId(availableTemplates[0]._id);
      }
    } catch (error) {
      console.error('Failed to load user preferences:', error);
      // Fall back to default template on error
      const defaultTemplate = availableTemplates.find((t: ReportTemplate) => t.isDefault);
      if (defaultTemplate) {
        setSelectedTemplateId(defaultTemplate._id);
      } else if (availableTemplates.length > 0) {
        setSelectedTemplateId(availableTemplates[0]._id);
      }
    }
  };

  // WHAT: Save template selection to preferences
  // WHY: Persist user choice across sessions and browsers
  const handleTemplateChange = async (templateId: string) => {
    if (!templateId || templateId === selectedTemplateId) return;
    
    console.log('Setting template to:', templateId);
    setSelectedTemplateId(templateId);
    
    // WHAT: Save to preferences using apiPut for CSRF protection
    // WHY: Persist selection so it's remembered on next visit
    // HOW: Fire and forget - ignore errors silently to not block UI
    try {
      await apiPut('/api/user-preferences', { lastSelectedTemplateId: templateId });
    } catch (error) {
      // WHAT: Silently ignore errors (auth, network, etc.)
      // WHY: Preference saving shouldn't block template selection
      console.warn('Failed to save template preference:', error);
    }
  };

  // WHAT: Load templates and select default on mount
  // WHY: Populate template selector
  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/report-templates?includeAssociations=false');
      const data = await response.json();
      
      if (data.success && data.templates) {
        setTemplates(data.templates);
        return data.templates; // Return templates for use in initialization
      } else {
        console.error('Templates API returned error:', data.error);
        return [];
      }
    } catch (error) {
      console.error('Failed to load templates:', error);
      return [];
    }
  };
  

  // WHAT: Reload template config after changes
  // WHY: Keep UI in sync with database
  const reloadCurrentTemplate = async () => {
    if (selectedTemplateId) {
      await loadTemplateConfig(selectedTemplateId);
    }
  };
  
  const loadAvailableCharts = async () => {
    try {
      const response = await fetch('/api/chart-configs');
      const data = await response.json();
      if (data.success) {
        setAvailableCharts(data.configs);
      }
    } catch (error) {
      console.error('Failed to load available charts:', error);
    }
  };

  // Load chart configurations used by stats pages (public subset)
  const loadChartConfigs = async () => {
    try {
      const response = await fetch('/api/chart-config/public');
      const data = await response.json();
      if (data.success) {
        setChartConfigs(data.configurations);
      }
    } catch (error) {
      console.error('Failed to load chart configurations:', error);
    }
  };

  // WHAT: Save updated template configuration with save status tracking
  // WHY: Persist changes to selected template with visual feedback and CSRF protection
  // HOW: Use apiPut() for CSRF protection, track save status, retry on network errors
  const saveTemplateConfig = async (updatedDataBlocks?: DataVisualizationBlock[], retryCount = 0): Promise<boolean> => {
    if (!selectedTemplateId) return false;
    
    const template = templates.find(t => t._id === selectedTemplateId);
    if (!template) return false;
    
    const blocksToSave = updatedDataBlocks || dataBlocks;
    const dataBlockRefs = blocksToSave
      .filter(block => block._id)
      .map((block, index) => ({
        blockId: block._id!,
        order: index
      }));
    
    setTemplateSaveStatus('saving');
    
    try {
      // WHAT: Use apiPut() instead of fetch() for CSRF protection
      // WHY: Production middleware requires X-CSRF-Token header
      const data = await apiPut(`/api/report-templates?templateId=${selectedTemplateId}`, {
        dataBlocks: dataBlockRefs,
        gridSettings: {
          desktopUnits: gridUnits.desktop,
          tabletUnits: gridUnits.tablet,
          mobileUnits: gridUnits.mobile
        },
        heroSettings,
        alignmentSettings
      });
      
      if (data.success) {
        // Update local templates state
        setTemplates(prev => prev.map(t => 
          t._id === selectedTemplateId 
            ? { 
                ...t, 
                dataBlocks: dataBlockRefs, 
                gridSettings: {
                  desktopUnits: gridUnits.desktop,
                  tabletUnits: gridUnits.tablet,
                  mobileUnits: gridUnits.mobile
                },
                heroSettings,
                alignmentSettings
              }
            : t
        ));
        
        setTemplateSaveStatus('saved');
        setTimeout(() => setTemplateSaveStatus('idle'), 2000);
        return true;
      } else {
        throw new Error(data.error || 'Failed to save template config');
      }
    } catch (error) {
      console.error('Failed to save template config:', error);
      
      // WHAT: Retry once on network errors
      // WHY: Handle transient network issues
      if (retryCount === 0 && error instanceof Error && error.message.includes('network')) {
        console.log('Retrying template save...');
        await new Promise(resolve => setTimeout(resolve, 1000));
        return saveTemplateConfig(updatedDataBlocks, 1);
      }
      
      setTemplateSaveStatus('error');
      setTimeout(() => setTemplateSaveStatus('idle'), 3000);
      return false;
    }
  };

  // WHAT: Save HERO settings to template immediately (like blocks do)
  // WHY: Follow the same pattern as block updates - save immediately on change
  const saveHeroSettings = useCallback(async (newHeroSettings: HeroBlockSettings, newAlignmentSettings: BlockAlignmentSettings) => {
    if (!selectedTemplateId) return;
    
    try {
      // WHAT: Convert minElementHeight to undefined if it's null or 0
      // WHY: MongoDB stores undefined as null, causing TypeScript type errors
      const cleanedAlignmentSettings = {
        ...newAlignmentSettings,
        minElementHeight: newAlignmentSettings.minElementHeight || undefined
      };
      
      // WHAT: Use apiPut() for CSRF protection
      // WHY: Consistent with other save operations
      const data = await apiPut(`/api/report-templates?templateId=${selectedTemplateId}`, {
        heroSettings: newHeroSettings,
        alignmentSettings: cleanedAlignmentSettings
      });
      
      if (!data.success) {
        console.error('Failed to save HERO settings:', data.error);
      }
      // Don't update local templates state to avoid triggering loadTemplateConfig
      // The settings are already updated in the component state by the onChange handlers
    } catch (error) {
      console.error('Failed to save HERO settings:', error);
    }
  }, [selectedTemplateId]);
  
  // WHAT: Convert DataVisualizationBlock to EditorBlockInput for Layout Grammar validation
  // WHY: Validation API requires EditorBlockInput format with content metadata
  // HOW: Map block charts to cells, extract chart types and metadata from chartConfigs and previewResults
  const convertBlockToEditorInput = useCallback((block: DataVisualizationBlock): EditorBlockInput | null => {
    if (!block._id) return null;
    
    // WHAT: Convert block charts to EditorBlockInput cells
    // WHY: Validation API expects cells with elementType, width, and contentMetadata
    const cells = block.charts.map(chartRef => {
      const chartConfig = chartConfigMap.get(chartRef.chartId);
      const chartType = resolveChartType(chartRef.chartId);
      const unitSize = normalizeUnitSize(chartRef.unitSize ?? chartRef.width);
      
      // WHAT: Extract content metadata from preview results or chart config
      // WHY: Validation needs barCount, legendItemCount, etc. for accurate height calculation
      const contentMetadata: Record<string, unknown> = {};
      
      if (chartType === 'bar' && previewResults[chartRef.chartId]) {
        const result = previewResults[chartRef.chartId];
        if (result.elements && Array.isArray(result.elements)) {
          contentMetadata.barCount = result.elements.length;
        }
      } else if (chartType === 'pie' && previewResults[chartRef.chartId]) {
        const result = previewResults[chartRef.chartId];
        if (result.elements && Array.isArray(result.elements)) {
          contentMetadata.legendItemCount = result.elements.length;
        }
      }
      
      return {
        chartId: chartRef.chartId,
        elementType: chartType as 'text' | 'table' | 'pie' | 'bar' | 'kpi' | 'image',
        width: unitSize,
        contentMetadata: Object.keys(contentMetadata).length > 0 ? contentMetadata : undefined,
        imageMode: chartType === 'image' ? ('setIntrinsic' as 'cover' | 'setIntrinsic') : undefined
      };
    });
    
    return {
      blockId: block._id,
      cells,
      // WHAT: No block-level aspect ratio or max height constraints in current editor
      // WHY: These are template-level settings, not block-level
      blockAspectRatio: undefined,
      maxAllowedHeight: undefined
    };
  }, [chartConfigMap, previewResults, resolveChartType]);
  
  // WHAT: Validate block for Layout Grammar compliance before save
  // WHY: Prevent invalid configurations (scrolling, truncation, clipping) from being saved
  // HOW: Use editor validation API to check block configuration
  const validateBlockBeforeSave = useCallback((block: DataVisualizationBlock): {
    isValid: boolean;
    validationResult?: BlockValidationResult;
    errorMessage?: string;
  } => {
    const editorInput = convertBlockToEditorInput(block);
    if (!editorInput) {
      return {
        isValid: false,
        errorMessage: 'Block ID is missing'
      };
    }
    
    // WHAT: Use standard desktop width for validation (1200px)
    // WHY: Validation needs block width in pixels, desktop is the most common viewport
    // HOW: This is an estimate; actual width depends on viewport and grid settings
    const blockWidthPx = 1200; // Standard desktop width
    
    try {
      const validationResult = validateBlockForEditor(editorInput, blockWidthPx);
      
      // WHAT: Check if block should be blocked from publishing
      // WHY: Layout Grammar violations (scrolling, truncation, clipping) must be prevented
      if (validationResult.publishBlocked) {
        const reason = validationResult.publishBlockReason || 'Layout Grammar violation detected';
        return {
          isValid: false,
          validationResult,
          errorMessage: `Cannot save block "${block.name}": ${reason}`
        };
      }
      
      // WHAT: Check for required actions that indicate problems
      // WHY: Some violations require user action before save
      if (validationResult.requiredActions.length > 0) {
        const actions = validationResult.requiredActions.join(', ');
        return {
          isValid: false,
          validationResult,
          errorMessage: `Block "${block.name}" requires: ${actions}`
        };
      }
      
      return {
        isValid: true,
        validationResult
      };
    } catch (error) {
      console.error('Validation error:', error);
      // WHAT: Non-blocking validation error - allow save but log warning
      // WHY: Don't block user workflow if validation API fails
      return {
        isValid: true, // Allow save on validation error
        errorMessage: 'Validation check failed, but save will proceed'
      };
    }
  }, [convertBlockToEditorInput]);

  // OPS-LAYOUT-01: Real-time Layout Grammar validation feedback in block edit modal
  const liveBlockValidation = useMemo(() => {
    if (!editingBlock?._id) return null;
    const normalized = normalizeBlockForLayoutV2(editingBlock);
    return validateBlockBeforeSave(normalized);
  }, [editingBlock, normalizeBlockForLayoutV2, validateBlockBeforeSave]);
  
  // WHAT: Update block with save status tracking and auto-save support
  // WHY: Provide visual feedback, support onBlur auto-save pattern
  // HOW: Track save status, update block then save template, handle errors
  const handleUpdateBlock = async (block: DataVisualizationBlock, closeModal = true) => {
    // WHAT: Validate before attempting save
    // WHY: Prevent invalid saves
    if (!block.name.trim()) {
      showMessage('error', 'Block name is required');
      return;
    }
    
    if (!block._id) {
      showMessage('error', 'Block ID is missing');
      return;
    }
    
    const normalizedBlock = normalizeBlockForLayoutV2(block);

    // WHAT: LayoutV2 validation (capacity + allowed layout values)
    // WHY: Prevent invalid LayoutV2 blocks from being saved
    const layoutV2Validation = validateLayoutV2Block(normalizedBlock);
    if (!layoutV2Validation.valid) {
      setBlockSaveStatus('error');
      showMessage('error', layoutV2Validation.error || 'LayoutV2 validation failed');
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
      return;
    }

    // WHAT: Layout Grammar validation before save
    // WHY: Prevent invalid configurations (scrolling, truncation, clipping) from being saved
    const validation = validateBlockBeforeSave(normalizedBlock);
    if (!validation.isValid) {
      setBlockSaveStatus('error');
      showMessage('error', validation.errorMessage || 'Block validation failed');
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
      return;
    }
    
    setBlockSaveStatus('saving');
    
    try {
      // WHAT: Update block via API
      // WHY: Persist block changes to database
      const data = await apiPut('/api/data-blocks', normalizedBlock);
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to update block');
      }
      
      // WHAT: Update local state and save template config
      // WHY: Keep UI in sync and persist template changes
      const updatedBlocks = dataBlocks.map(b => b._id === block._id ? normalizedBlock : b);
      setDataBlocks(updatedBlocks);
      
      const templateSaved = await saveTemplateConfig(updatedBlocks);
      
      if (templateSaved) {
        setBlockSaveStatus('saved');
        if (closeModal) {
          setEditingBlock(null);
        }
        showMessage('success', 'Block updated successfully!');
        setTimeout(() => setBlockSaveStatus('idle'), 2000);
      } else {
        // WHAT: Block updated but template save failed
        // WHY: Show warning but block is still updated
        setBlockSaveStatus('error');
        showMessage('error', 'Block updated but template save failed. Please refresh and try again.');
        setTimeout(() => setBlockSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('Failed to update block:', error);
      setBlockSaveStatus('error');
      const errorMessage = error instanceof Error ? error.message : 'Failed to update block';
      showMessage('error', errorMessage);
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
    }
  };
  
  const handleDeleteBlock = async (blockId: string) => {
    // TODO: Replace confirm() with modal dialog in future enhancement
    if (!confirm('Are you sure you want to delete this data block?')) {
      return;
    }
    
    try {
      const data = await apiDelete(`/api/data-blocks?id=${blockId}`);
      
      if (data.success) {
        const updatedBlocks = dataBlocks.filter(b => b._id !== blockId);
        setDataBlocks(updatedBlocks);
        await saveTemplateConfig(updatedBlocks);
        showMessage('success', 'Block deleted successfully!');
      } else {
        showMessage('error', 'Failed to delete block: ' + data.error);
      }
    } catch (error) {
      console.error('Failed to delete block:', error);
      showMessage('error', 'Failed to delete block');
    }
  };
  
  // WHAT: Create new block and save to template atomically
  // WHY: Ensure block is always added to template, provide visual feedback
  // HOW: Track save status, create block then save template, handle errors gracefully
  const handleCreateBlock = async () => {
    // WHAT: Validate before attempting save
    // WHY: Prevent invalid saves
    if (!blockForm.name.trim()) {
      showMessage('error', 'Block name is required');
      return;
    }
    
    if (!selectedTemplateId) {
      showMessage('error', 'Please select a template first');
      return;
    }
    
    const normalizedBlockForm = {
      ...blockForm,
      charts: blockForm.charts.map(chart => normalizeChartLayout(chart))
    };

    // WHAT: Layout Grammar validation before save
    // WHY: Prevent invalid configurations (scrolling, truncation, clipping) from being saved
    // HOW: Convert blockForm to DataVisualizationBlock format for validation
    const blockForValidation: DataVisualizationBlock = {
      _id: 'temp', // Temporary ID for validation
      name: normalizedBlockForm.name,
      charts: normalizedBlockForm.charts,
      order: normalizedBlockForm.order,
      isActive: normalizedBlockForm.isActive,
      showTitle: normalizedBlockForm.showTitle
    };

    const layoutV2Validation = validateLayoutV2Block(blockForValidation);
    if (!layoutV2Validation.valid) {
      setBlockSaveStatus('error');
      showMessage('error', layoutV2Validation.error || 'LayoutV2 validation failed');
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
      return;
    }

    const validation = validateBlockBeforeSave(blockForValidation);
    if (!validation.isValid) {
      setBlockSaveStatus('error');
      showMessage('error', validation.errorMessage || 'Block validation failed');
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
      return;
    }
    
    setBlockSaveStatus('saving');
    
    try {
      // WHAT: Step 1: Create block via API
      // WHY: Block must exist before adding to template
      const data = await apiPost('/api/data-blocks', normalizedBlockForm);
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to create block');
      }
      
      // WHAT: Step 2: Add block to template (atomic operation)
      // WHY: Ensure block is always in template after creation
      const newBlock = data.block;
      const updatedBlocks = [...dataBlocks, newBlock];
      setDataBlocks(updatedBlocks);
      
      // WHAT: Save template config with retry logic
      // WHY: If template save fails, block still exists (no rollback needed)
      const templateSaved = await saveTemplateConfig(updatedBlocks);
      
      if (templateSaved) {
        setBlockSaveStatus('saved');
        setShowCreateBlock(false);
        setBlockForm({
          name: '',
          charts: [],
          order: 0,
          isActive: true,
          showTitle: true
        });
        showMessage('success', 'Data block created and added to template!');
        setTimeout(() => setBlockSaveStatus('idle'), 2000);
      } else {
        // WHAT: Block created but template save failed
        // WHY: Show warning but don't delete block (user can manually add it)
        setBlockSaveStatus('error');
        showMessage('error', 'Block created but failed to add to template. Please refresh and try again.');
        setTimeout(() => setBlockSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('Failed to create block:', error);
      setBlockSaveStatus('error');
      const errorMessage = error instanceof Error ? error.message : 'Failed to create block';
      showMessage('error', errorMessage);
      setTimeout(() => setBlockSaveStatus('idle'), 3000);
    }
  };
  
  
  
  // Calculate preview results for a given block's charts using the same pipeline as stats pages
  const calculatePreviewForBlock = useCallback((block: DataVisualizationBlock) => {
    console.log('🔍 calculatePreviewForBlock called:', {
      blockName: block.name,
      blockCharts: block.charts.map(c => c.chartId),
      chartConfigsAvailable: chartConfigs.length
    });
    
    if (!chartConfigs || chartConfigs.length === 0) {
      console.warn('⚠️ No chart configs available for preview calculation');
      return;
    }

    try {
      setIsCalculating(true);
      // Build a fake baseline stats object that covers all fields with non-zero values
      // Why: Admin preview must render charts even without a specific project loaded
      const baselineStats: any = {
        remoteImages: 120, hostessImages: 80, selfies: 40,
        indoor: 200, outdoor: 150, stadium: 50,
        female: 180, male: 220,
        genAlpha: 60, genYZ: 180, genX: 100, boomer: 60,
        merched: 90, jersey: 70, scarf: 40, flags: 30, baseballCap: 25, other: 15,
        approvedImages: 180, rejectedImages: 20,
        visitQrCode: 120, visitShortUrl: 40, visitWeb: 300, visitFacebook: 80, visitInstagram: 120,
        visitYoutube: 40, visitTiktok: 50, visitX: 35, visitTrustpilot: 10,
        eventAttendees: 12000, eventTicketPurchases: 9500,
        eventResultHome: 2, eventResultVisitor: 1,
        eventValuePropositionVisited: 600, eventValuePropositionPurchases: 75,
        jerseyPrice: 70, scarfPrice: 15, flagsPrice: 20, capPrice: 25, otherPrice: 10
      };

      // Add sample image and text data for report content charts
      for (let i = 1; i <= 100; i++) {
        baselineStats[`reportImage${i}`] = `https://picsum.photos/400/300?random=${i}`;
        baselineStats[`reportText${i}`] = `Sample text content ${i}`;
      }

      // Calculate using the shared calculator
      const results = calculateActiveCharts(chartConfigs, baselineStats);
      console.log('✅ calculateActiveCharts returned:', {
        resultsCount: results.length,
        chartIds: results.map(r => r.chartId)
      });
      
      // Normalize into a map for quick lookup by chartId
      const map: Record<string, ChartCalculationResult> = {};
      results.forEach(r => { map[r.chartId] = r; });
      console.log('📊 Preview results map:', Object.keys(map));
      setPreviewResults(prev => ({ ...prev, ...map }));
    } catch (err) {
      console.error('Failed to calculate preview charts:', err);
    } finally {
      setIsCalculating(false);
    }
  }, [chartConfigs]);

  // Auto-calculate previews when both chart configurations and blocks are available
  // Why: The admin needs to see an immediate WYSIWYG preview without any interactions
  useEffect(() => {
    if (chartConfigs.length > 0 && dataBlocks.length > 0) {
      dataBlocks.forEach(b => calculatePreviewForBlock(b));
    }
  }, [chartConfigs, dataBlocks, calculatePreviewForBlock]);

  const addChartToBlock = (block: DataVisualizationBlock, chartId: string) => {
    const chart = availableCharts.find(c => c.chartId === chartId);
    if (!chart) return;

    const defaultLayout = getChartDefaultLayout(chartId);
    const newChart: BlockChart = normalizeChartLayout({
      chartId,
      order: block.charts.length,
      ...defaultLayout
    });
    
    const updatedBlock = {
      ...block,
      charts: [...block.charts, newChart]
    };
    
    console.log('🔵🔵🔵 ADDING CHART TO BLOCK:', {
      blockName: block.name,
      blockId: block._id,
      addingChart: chartId,
      newTotalCharts: updatedBlock.charts.length,
      allChartIds: updatedBlock.charts.map(c => c.chartId)
    });
    
    // WHAT: Show visible status message when adding chart
    // WHY: Console logs are being lost due to 11k+ message overflow
    showMessage('info', `Adding "${chart.title}" to ${block.name}...`);
    
    handleUpdateBlock(updatedBlock);
    // Recalculate preview for this block so the new chart immediately appears
    calculatePreviewForBlock(updatedBlock);
  };
  
  const removeChartFromBlock = (block: DataVisualizationBlock, chartIndex: number) => {
    const updatedCharts = block.charts.filter((_, index) => index !== chartIndex);
    // Reorder remaining charts
    const reorderedCharts = updatedCharts.map((chart, index) => ({ ...chart, order: index }));
    
    const updatedBlock = {
      ...block,
      charts: reorderedCharts
    };
    
    handleUpdateBlock(updatedBlock);
  };
  
  const updateChartWidth = (block: DataVisualizationBlock, chartIndex: number, newWidth: number) => {
    const updatedCharts = [...block.charts];
    // WHAT: Clamp width to 1 or 2 units (Spec v2.0)
    // WHY: Deterministic layout requires simplified unit system
    // HOW: Accept user input but clamp to [1, 2] range
    const unitSize = normalizeUnitSize(newWidth);
    updatedCharts[chartIndex] = normalizeChartLayout({
      ...updatedCharts[chartIndex],
      unitSize,
      width: unitSize
    });
    
    const updatedBlock = {
      ...block,
      charts: updatedCharts
    };
    
    handleUpdateBlock(updatedBlock);
    // No need to recalc data; width change affects only layout span, preview already computed
  };

  const updateChartAspectRatio = (block: DataVisualizationBlock, chartIndex: number, aspectRatio: LayoutAspectRatio) => {
    const updatedCharts = [...block.charts];
    const unitSize = ASPECT_RATIO_UNIT_MAP[aspectRatio];
    updatedCharts[chartIndex] = normalizeChartLayout({
      ...updatedCharts[chartIndex],
      aspectRatio,
      unitSize,
      width: unitSize
    });

    const updatedBlock = {
      ...block,
      charts: updatedCharts
    };

    handleUpdateBlock(updatedBlock);
  };
  
  const resetBlockForm = () => {
    setBlockForm({
      name: '',
      charts: [],
      order: 0,
      isActive: true,
      showTitle: true // NEW: Default to showing title
    });
  };
  
  // WHAT: Toggle block editor visibility
  // WHY: Single function handles add/remove from Set for any block
  const toggleBlockEditor = (blockId: string) => {
    setExpandedBlocks(prev => {
      const next = new Set(prev);
      if (next.has(blockId)) {
        next.delete(blockId);
      } else {
        next.add(blockId);
      }
      return next;
    });
  };
  
  // WHAT: Create new template with CSRF protection
  // WHY: Allow creating templates with empty config, then auto-select
  // HOW: Use apiPost() for automatic CSRF token handling
  const handleCreateTemplate = async () => {
    if (!templateForm.name.trim()) {
      showMessage('error', 'Template name is required');
      return;
    }
    
    try {
      // WHAT: Use apiPost() for automatic CSRF token handling
      // WHY: Production middleware requires X-CSRF-Token header for POST requests
      const data = await apiPost('/api/report-templates', {
        name: templateForm.name.trim(),
        description: templateForm.description.trim(),
        type: templateForm.type,
        isDefault: templateForm.isDefault,
        dataBlocks: [],
        gridSettings: {
          desktopUnits: 4,
          tabletUnits: 2,
          mobileUnits: 1
        }
      });
      
      if (data.success && data.template) {
        // Reload templates list
        await loadTemplates();
        // Auto-select newly created template
        setSelectedTemplateId(data.template._id);
        // Close modal and reset form
        setShowCreateTemplate(false);
        setTemplateForm({
          name: '',
          description: '',
          type: 'event',
          isDefault: false
        });
        showMessage('success', 'Template created successfully!');
      } else {
        showMessage('error', data.error || 'Failed to create template');
      }
    } catch (error) {
      console.error('Failed to create template:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to create template';
      showMessage('error', errorMessage);
    }
  };
  
  // WHAT: Handle template rename
  // WHY: Allow updating template name
  const handleRenameTemplate = async () => {
    if (!selectedTemplateId || !templateEditName.trim()) {
      showMessage('error', 'Template name is required');
      return;
    }
    
    try {
      const data = await apiPut(`/api/report-templates?templateId=${selectedTemplateId}`, {
        name: templateEditName.trim()
      });
      
      if (data.success) {
        await loadTemplates();
        showMessage('success', 'Template renamed successfully!');
      } else {
        showMessage('error', data.error || 'Failed to rename template');
      }
    } catch (error) {
      console.error('Failed to rename template:', error);
      showMessage('error', 'Failed to rename template');
    }
  };
  
  // WHAT: Handle template copy
  // WHY: Allow duplicating templates with independent blocks
  const handleCopyTemplate = async () => {
    if (!selectedTemplateId) return;
    
    const selectedTemplate = templates.find(t => t._id === selectedTemplateId);
    if (!selectedTemplate) return;
    
    try {
      // WHAT: Fetch all blocks referenced by the original template
      // WHY: Need to create copies of blocks, not just reference the same ones
      const blockIds = (selectedTemplate.dataBlocks || []).map((ref: any) => ref.blockId);
      
      if (blockIds.length > 0) {
        // WHAT: Fetch full block data from database
        // WHY: Need block content (name, charts, etc.) to create copies
        const blocksResponse = await fetch('/api/data-blocks');
        const blocksData = await blocksResponse.json();
        
        if (!blocksData.success) {
          throw new Error('Failed to fetch blocks');
        }
        
        // WHAT: Find blocks that belong to this template
        // WHY: Only copy blocks that are actually used by this template
        const originalBlocks = blocksData.blocks.filter((block: any) => 
          blockIds.includes(block._id)
        );
        
        // WHAT: Create new copies of each block
        // WHY: New template needs independent blocks, not references to original blocks
        const newBlockRefs = [];
        for (const originalBlock of originalBlocks) {
          // WHAT: Create new block with same content but new ID
          // WHY: Each template copy must have its own independent blocks
          const newBlockResponse = await apiPost('/api/data-blocks', {
            name: originalBlock.name,
            charts: originalBlock.charts || [],
            order: originalBlock.order || 0,
            isActive: originalBlock.isActive !== false,
            showTitle: originalBlock.showTitle !== false
          });
          
          if (newBlockResponse.success && newBlockResponse.blockId) {
            // WHAT: Find original order in template
            // WHY: Preserve block order from original template
            const originalRef = selectedTemplate.dataBlocks.find((ref: any) => 
              ref.blockId === originalBlock._id || ref.blockId === originalBlock._id.toString()
            );
            
            newBlockRefs.push({
              blockId: newBlockResponse.blockId,
              order: originalRef?.order ?? newBlockRefs.length
            });
          }
        }
        
        // WHAT: Sort by original order to maintain template structure
        // WHY: Preserve the visual layout of the original template
        newBlockRefs.sort((a, b) => a.order - b.order);
        
        // WHAT: Create template with new block references
        // WHY: New template points to new blocks, completely independent
        const copyData: any = {
          name: `Copy of ${selectedTemplate.name}`,
          type: selectedTemplate.type,
          isDefault: false, // WHAT: Never mark copy as default
          dataBlocks: newBlockRefs,
          gridSettings: selectedTemplate.gridSettings || {
            desktopUnits: 4,
            tabletUnits: 2,
            mobileUnits: 1
          },
          heroSettings: selectedTemplate.heroSettings,
          alignmentSettings: selectedTemplate.alignmentSettings
        };
        
        // WHAT: Include description if it exists (optional field)
        // WHY: Some templates may have description, preserve it in copy
        if ((selectedTemplate as any).description) {
          copyData.description = (selectedTemplate as any).description;
        }
        
        const data = await apiPost('/api/report-templates', copyData);
        
        if (data.success && data.template) {
          await loadTemplates();
          // WHAT: Auto-select newly copied template
          // WHY: User expects to edit the copy immediately
          setSelectedTemplateId(data.template._id);
          setShowTemplateEditModal(false);
          showMessage('success', 'Template copied successfully with independent blocks!');
        } else {
          showMessage('error', data.error || 'Failed to copy template');
        }
      } else {
        // WHAT: Template has no blocks, just copy template structure
        // WHY: Some templates might be empty
        const copyData: any = {
          name: `Copy of ${selectedTemplate.name}`,
          type: selectedTemplate.type,
          isDefault: false,
          dataBlocks: [],
          gridSettings: selectedTemplate.gridSettings || {
            desktopUnits: 4,
            tabletUnits: 2,
            mobileUnits: 1
          },
          heroSettings: selectedTemplate.heroSettings,
          alignmentSettings: selectedTemplate.alignmentSettings
        };
        
        if ((selectedTemplate as any).description) {
          copyData.description = (selectedTemplate as any).description;
        }
        
        const data = await apiPost('/api/report-templates', copyData);
        
        if (data.success && data.template) {
          await loadTemplates();
          setSelectedTemplateId(data.template._id);
          setShowTemplateEditModal(false);
          showMessage('success', 'Template copied successfully!');
        } else {
          showMessage('error', data.error || 'Failed to copy template');
        }
      }
    } catch (error) {
      console.error('Failed to copy template:', error);
      showMessage('error', 'Failed to copy template: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  };
  
  // WHAT: Handle template delete
  // WHY: Allow removing unused templates
  const handleDeleteTemplate = async () => {
    if (!selectedTemplateId) return;
    
    const selectedTemplate = templates.find(t => t._id === selectedTemplateId);
    if (!selectedTemplate) return;
    
    try {
      const data = await apiDelete(`/api/report-templates?templateId=${selectedTemplateId}`);
      
      if (data.success) {
        await loadTemplates();
        // WHAT: Clear selection if deleted template was selected
        // WHY: Prevent editing non-existent template
        setSelectedTemplateId(null);
        setShowTemplateEditModal(false);
        setShowDeleteConfirm(false);
        showMessage('success', 'Template deleted successfully!');
      } else {
        showMessage('error', data.error || 'Failed to delete template');
        setShowDeleteConfirm(false);
      }
    } catch (error) {
      console.error('Failed to delete template:', error);
      showMessage('error', 'Failed to delete template');
      setShowDeleteConfirm(false);
    }
  };

  if (loading) {
    return (
      <div className="page-container">
        <ColoredCard accentColor="#6366f1" hoverable={false} className="p-8 text-center">
          <div className="loading-spinner-viz"></div>
          <p>Loading data visualization blocks...</p>
        </ColoredCard>
      </div>
    );
  }

  return (
    <div className="page-container">
      <UnifiedAdminHeroWithSearch
        title="👁️ Visualization Manager"
        subtitle="Manage data visualization blocks and chart layouts"
        backLink="/admin"
        showSearch={false}
      />
      
      {/* WHAT: Status Message - Smooth UX feedback without page reloads
          WHY: Replace alert() dialogs with auto-dismissing status messages */}
      {statusMessage && (
        <div className={`${vizStyles.statusMessage} ${statusMessage.type === 'success' ? vizStyles.statusSuccess : vizStyles.statusError}`}>
          {statusMessage.type === 'success' ? '✅' : '❌'} {statusMessage.text}
        </div>
      )}
      
      {/* WHAT: Template Selector Card
          WHY: Allow selecting which template to edit */}
      <ColoredCard accentColor="#3b82f6" hoverable={false}>
        <div className={vizStyles.templateSelector}>
          <div className={vizStyles.templateSelectorHeader}>
            {/* eslint-disable-next-line react/forbid-dom-props */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
              <h3 className={vizStyles.templateSelectorTitle}>📊 Select Report Template</h3>
              <SaveStatusIndicator status={templateSaveStatus} />
            </div>
            <p className={vizStyles.templateSelectorSubtitle}>
              Choose a template to configure its visualization blocks and charts
            </p>
            
          </div>
          
          <div className={vizStyles.templateSelectorControls}>
            
            <div className={vizStyles.templateSelectorRow}>
              <select
                className={vizStyles.templateDropdown}
                value={selectedTemplateId || ''}
                onChange={(e) => {
                  console.log('Template dropdown changed to:', e.target.value);
                  const selectedTemplate = templates.find(t => t._id === e.target.value);
                  console.log('Selected template:', selectedTemplate?.name);
                  handleTemplateChange(e.target.value);
                }}
              >
                <option value="" disabled>Select a template...</option>
                {templates.map(template => {
                  const isLivePartnerReportTemplate = template.name === 'Default Event Report' && template.type === 'event';
                  const isPartnerTemplate = template.type === 'partner';
                  return (
                    <option key={template._id} value={template._id}>
                      {template.isDefault && '⭐ '}
                      {isLivePartnerReportTemplate && '🎯 '}
                      {template.name} ({template.type})
                      {isLivePartnerReportTemplate && ' - Fallback Template for Partner Reports'}
                      {isPartnerTemplate && ' - Partner-Specific Template'}
                    </option>
                  );
                })}
              </select>
              
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  // Find and select the Default Event Report template
                  const defaultEventTemplate = templates.find(t => t.name === 'Default Event Report' && t.type === 'event');
                  if (defaultEventTemplate) {
                    const confirmed = confirm(
                      'This will switch to "Default Event Report" template, which is the fallback template for partner reports.\n\n' +
                      'Click OK to edit the fallback template, or Cancel to continue editing your current selection (which may be used by specific partners).'
                    );
                    if (confirmed) {
                      handleTemplateChange(defaultEventTemplate._id);
                    }
                  }
                }}
                type="button"
                className={`btn btn-small btn-secondary ${vizStyles.buttonSpacing}`}
              >
                🎯 Edit Live Partner Reports
              </button>
              
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setShowCreateTemplate(true);
                }}
                type="button"
                className="btn btn-small btn-primary"
              >
                ➕ New Template
              </button>
              
              {selectedTemplateId && (
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const selectedTemplate = templates.find(t => t._id === selectedTemplateId);
                    if (selectedTemplate) {
                      setTemplateEditName(selectedTemplate.name);
                      setShowTemplateEditModal(true);
                    }
                  }}
                  type="button"
                  className="btn btn-small btn-secondary"
                  title="Edit template (rename, copy, delete)"
                >
                  <MaterialIcon name="edit" variant="outlined" style={{ fontSize: '1rem', marginRight: '0.25rem' }} />
                  Edit Template
                </button>
              )}
            </div>
            
            {selectedTemplateId && (
              <div className={vizStyles.templateInfo}>
                <span className={vizStyles.templateInfoItem}>
                  📊 {dataBlocks.length} blocks
                </span>
                <span className={vizStyles.templateInfoItem}>
                  🔲 {gridUnits.desktop}x grid
                </span>
              </div>
            )}
          </div>
        </div>
      </ColoredCard>
      
      {/* WHAT: Create Template Modal
          WHY: Allow creating new report templates with empty config */}
      <FormModal
        isOpen={showCreateTemplate}
        onClose={() => {
          setShowCreateTemplate(false);
          setTemplateForm({ name: '', description: '', type: 'event', isDefault: false });
        }}
        onSubmit={handleCreateTemplate}
        title="➕ Create New Report Template"
        size="md"
      >
        <div className="form-section">
          <div className="form-group mb-4">
            <label className="form-label-block">Template Name *</label>
            <input
              type="text"
              value={templateForm.name}
              onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
              placeholder="e.g., Partner Annual Report, Event Dashboard"
              className="form-input"
            />
          </div>
          
          <div className="form-group mb-4">
            <label className="form-label-block">Description</label>
            <textarea
              value={templateForm.description}
              onChange={(e) => setTemplateForm({ ...templateForm, description: e.target.value })}
              placeholder="Optional description of this template's purpose"
              className="form-input"
              rows={3}
            />
          </div>
          
          <div className="form-group mb-4">
            <label className="form-label-block">Template Type *</label>
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  name="templateType"
                  value="event"
                  checked={templateForm.type === 'event'}
                  onChange={(e) => setTemplateForm({ ...templateForm, type: e.target.value as 'event' | 'partner' | 'global' })}
                />
                <span>Event Report</span>
              </label>
              <label className="radio-label">
                <input
                  type="radio"
                  name="templateType"
                  value="partner"
                  checked={templateForm.type === 'partner'}
                  onChange={(e) => setTemplateForm({ ...templateForm, type: e.target.value as 'event' | 'partner' | 'global' })}
                />
                <span>Partner Report</span>
              </label>
              <label className="radio-label">
                <input
                  type="radio"
                  name="templateType"
                  value="global"
                  checked={templateForm.type === 'global'}
                  onChange={(e) => setTemplateForm({ ...templateForm, type: e.target.value as 'event' | 'partner' | 'global' })}
                />
                <span>Global Default</span>
              </label>
            </div>
          </div>
          
          <div className="form-group mb-4">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={templateForm.isDefault}
                onChange={(e) => setTemplateForm({ ...templateForm, isDefault: e.target.checked })}
              />
              <span>Set as default template</span>
            </label>
          </div>
        </div>
      </FormModal>
      
      {/* WHAT: Template Management Modal (Rename, Copy, Delete)
          WHY: Allow managing existing templates */}
      {selectedTemplateId && (() => {
        const selectedTemplate = templates.find(t => t._id === selectedTemplateId);
        if (!selectedTemplate) return null;
        
        return (
          <FormModal
            isOpen={showTemplateEditModal}
            onClose={() => {
              setShowTemplateEditModal(false);
              setTemplateEditName(selectedTemplate.name);
            }}
            onSubmit={async () => {
              // WHAT: FormModal requires onSubmit, but we handle actions via buttons
              // WHY: FormModal provides proper design system styling
              // HOW: onSubmit is a no-op, actions handled by individual buttons
            }}
            title={`📝 Manage Report Template: ${selectedTemplate.name}`}
            size="md"
            customFooter={
              <div 
                // eslint-disable-next-line react/forbid-dom-props
                style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--mm-space-3)' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowTemplateEditModal(false);
                    setTemplateEditName(selectedTemplate.name);
                  }}
                >
                  Close
                </button>
              </div>
            }
          >
            {/* Rename Section */}
            <div className="form-group mb-6">
              <label className="form-label-block">Rename Template</label>
              {/* eslint-disable-next-line react/forbid-dom-props */}
              <div style={{ display: 'flex', gap: 'var(--mm-space-3)', alignItems: 'flex-end' }}>
                {/* eslint-disable-next-line react/forbid-dom-props */}
                <div style={{ flex: 1 }}>
                  <input
                    type="text"
                    className="form-input"
                    value={templateEditName}
                    onChange={(e) => setTemplateEditName(e.target.value)}
                    placeholder="Enter template name..."
                  />
                </div>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleRenameTemplate}
                  disabled={!templateEditName.trim() || templateEditName.trim() === selectedTemplate.name}
                >
                  Save Name
                </button>
              </div>
            </div>
            
            {/* Copy Section */}
            {/* eslint-disable-next-line react/forbid-dom-props */}
            <div className="form-group mb-6" style={{ paddingBottom: 'var(--mm-space-6)', borderBottom: '1px solid var(--mm-gray-200)' }}>
              <label className="form-label-block">Copy Template</label>
              {/* eslint-disable-next-line react/forbid-dom-props */}
              <p className="form-hint" style={{ marginBottom: 'var(--mm-space-4)' }}>
                Create a duplicate of this template with all its blocks and settings.
              </p>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handleCopyTemplate}
              >
                <MaterialIcon name="content_copy" variant="outlined" style={{ fontSize: '1rem', marginRight: '0.5rem' }} />
                Copy Template
              </button>
            </div>
            
            {/* Delete Section */}
            <div className="form-group mb-4">
              <label className="form-label-block">Delete Template</label>
              {/* eslint-disable-next-line react/forbid-dom-props */}
              <p className="form-hint" style={{ marginBottom: 'var(--mm-space-4)' }}>
                {selectedTemplate.isDefault 
                  ? '⚠️ Cannot delete default template. Mark another template as default first.'
                  : 'Permanently delete this template. This action cannot be undone.'}
              </p>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => setShowDeleteConfirm(true)}
                disabled={selectedTemplate.isDefault}
              >
                <MaterialIcon name="delete" variant="outlined" style={{ fontSize: '1rem', marginRight: '0.5rem' }} />
                Delete Template
              </button>
            </div>
          </FormModal>
        );
      })()}
      
      {/* WHAT: Delete Confirmation Dialog
          WHY: Confirm destructive action before deleting template */}
      {selectedTemplateId && (() => {
        const selectedTemplate = templates.find(t => t._id === selectedTemplateId);
        if (!selectedTemplate) return null;
        
        return (
          <ConfirmDialog
            isOpen={showDeleteConfirm}
            onClose={() => setShowDeleteConfirm(false)}
            onConfirm={handleDeleteTemplate}
            title="Delete Report Template?"
            message={`Are you sure you want to delete "${selectedTemplate.name}"? This action cannot be undone.`}
            confirmText="Delete"
            cancelText="Cancel"
            variant="danger"
          />
        );
      })()}
      
      {!selectedTemplateId && (
        <ColoredCard accentColor="#f59e0b">
          <div className="info-box">
            <h4 className="info-box-title">⚠️ No Template Selected</h4>
            <p>Please select a report template above to configure its visualization blocks.</p>
          </div>
        </ColoredCard>
      )}

      {/* WHAT: HERO Block Settings Section
          WHY: Allow configuring report header elements at template level */}
      {selectedTemplateId && (
        <ColoredCard accentColor="#f59e0b" hoverable={false}>
          <h2 className="section-title mb-6">🏒 HERO Block Settings</h2>
          <p className="section-subtitle mb-6">
            Control which elements appear in the report header for all reports using this template
          </p>
          
          <div className="form-section">
            <div className="form-group mb-6">
              <h4 className={vizStyles.heroSectionHeader}>Header Element Visibility</h4>
              <div className={vizStyles.heroCheckboxGrid}>
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={heroSettings.showEmoji}
                    onChange={(e) => {
                      const newHeroSettings = { ...heroSettings, showEmoji: e.target.checked };
                      setHeroSettings(newHeroSettings);
                      saveHeroSettings(newHeroSettings, alignmentSettings);
                    }}
                  />
                  <span>Show Emoji (🏒)</span>
                </label>
                
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={heroSettings.showDateInfo}
                    onChange={(e) => {
                      const newHeroSettings = { ...heroSettings, showDateInfo: e.target.checked };
                      setHeroSettings(newHeroSettings);
                      saveHeroSettings(newHeroSettings, alignmentSettings);
                    }}
                  />
                  <span>Show Date Info (Created/Updated)</span>
                </label>
                
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={heroSettings.showExportOptions}
                    onChange={(e) => {
                      const newHeroSettings = { ...heroSettings, showExportOptions: e.target.checked };
                      setHeroSettings(newHeroSettings);
                      saveHeroSettings(newHeroSettings, alignmentSettings);
                    }}
                  />
                  <span>Show Export Options (PDF/Excel buttons)</span>
                </label>
              </div>
            </div>
            
            <div className="form-group mb-6">
              <h4 className={vizStyles.heroSectionHeader}>Block Element Alignment</h4>
              <div className={vizStyles.alignmentCheckboxGrid}>
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={alignmentSettings.alignTitles}
                    onChange={(e) => {
                      const newAlignmentSettings = { ...alignmentSettings, alignTitles: e.target.checked };
                      setAlignmentSettings(newAlignmentSettings);
                      saveHeroSettings(heroSettings, newAlignmentSettings);
                    }}
                  />
                  <span>Align Titles</span>
                </label>
                
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={alignmentSettings.alignDescriptions}
                    onChange={(e) => {
                      const newAlignmentSettings = { ...alignmentSettings, alignDescriptions: e.target.checked };
                      setAlignmentSettings(newAlignmentSettings);
                      saveHeroSettings(heroSettings, newAlignmentSettings);
                    }}
                  />
                  <span>Align Descriptions</span>
                </label>
                
                <label className={`checkbox-label ${vizStyles.flexCheckboxLabel}`}>
                  <input
                    type="checkbox"
                    checked={alignmentSettings.alignCharts}
                    onChange={(e) => {
                      const newAlignmentSettings = { ...alignmentSettings, alignCharts: e.target.checked };
                      setAlignmentSettings(newAlignmentSettings);
                      saveHeroSettings(heroSettings, newAlignmentSettings);
                    }}
                  />
                  <span>Align Charts</span>
                </label>
              </div>
              
              <div className="form-row mt-4">
                <label className="form-label">Minimum Element Height (px)</label>
                <input
                  type="number"
                  value={alignmentSettings.minElementHeight || ''}
                  onChange={(e) => {
                    const value = e.target.value ? parseInt(e.target.value) : undefined;
                    const newAlignmentSettings = { ...alignmentSettings, minElementHeight: value };
                    setAlignmentSettings(newAlignmentSettings);
                    saveHeroSettings(heroSettings, newAlignmentSettings);
                  }}
                  placeholder="Optional (e.g., 100)"
                  className={`form-input ${vizStyles.numberInputNarrow}`}
                />
              </div>
            </div>
            
            <div className="info-note mt-4">
              💡 <strong>Tip:</strong> These settings control what appears in report headers and how elements are aligned within blocks. 
              Changes are saved automatically and apply to all reports using this template.
            </div>
          </div>
        </ColoredCard>
      )}

      {/* WHAT: Data Visualization Blocks Section
          WHY: Only show when template is selected */}
      {selectedTemplateId && (
        <ColoredCard accentColor="#6366f1" hoverable={false}>
          <h2 className="section-title mb-6">Data Visualization Blocks</h2>
        
        {/* Responsive Grid Info */}
        <div className="info-box">
          <h4 className="info-box-title">
            📐 Responsive Grid System
          </h4>
          <div className="info-grid">
            <div className="info-grid-item">
              <span className="info-grid-emoji">📱</span>
              <div>
                <strong>Mobile:</strong><br />
                2 units per row
              </div>
            </div>
            <div className="info-grid-item">
              <span className="info-grid-emoji">📱</span>
              <div>
                <strong>Tablet:</strong><br />
                3 units per row
              </div>
            </div>
            <div className="info-grid-item">
              <span className="info-grid-emoji">💻</span>
              <div>
                <strong>Desktop (Stats Page):</strong><br />
                Up to 6 units per row (block-configurable)
              </div>
            </div>
          </div>
          <p className="info-note">
            Preview below uses the same responsive grid as stats pages. A unit size=2 chart spans two columns within the block; LayoutV2 blocks are capped at 4 units total.
          </p>
        </div>
        
        {/* Create New Block Button */}
        <div className="section-header">
          <h3 className="section-header-title">Current Blocks ({dataBlocks.length})</h3>
          <button
            onClick={() => {
              setShowCreateBlock(true);
              resetBlockForm();
            }}
            className="btn btn-small btn-primary"
          >
            ➕ New Block
          </button>
        </div>
        
        {/* Create Block Form */}
        {showCreateBlock && (
          <div className="success-box">
            <h4 className="success-box-title">➕ Create New Data Block</h4>
            
            <div className="form-section">
              <div className="form-row">
                <div>
                  <label className="form-label">Block Name</label>
                  <input
                    type="text"
                    value={blockForm.name}
                    onChange={(e) => setBlockForm({ ...blockForm, name: e.target.value })}
                    placeholder="e.g., Main Dashboard, Performance Metrics"
                    className="form-input"
                  />
                </div>
                
                <div>
                  <label className="form-label">Order</label>
                  <input
                    type="number"
                    value={blockForm.order}
                    onChange={(e) => {
                      // WHAT: Allow typing freely without immediate parsing
                      // WHY: User can delete "0" to enter new value smoothly
                      const val = e.target.value;
                      setBlockForm({ ...blockForm, order: val === '' ? '' as any : val as any });
                    }}
                    onBlur={() => {
                      // WHAT: Parse and validate only on blur
                      const parsed = Math.max(0, parseInt(String(blockForm.order)) || 0);
                      setBlockForm({ ...blockForm, order: parsed });
                    }}
                    className="form-input"
                  />
                </div>
              </div>
              
              <div className="flex-row">
                <button
                  onClick={handleCreateBlock}
                  className="btn btn-small btn-primary"
                >
                  Create Block
                </button>
                <button
                  onClick={() => {
                    setShowCreateBlock(false);
                    resetBlockForm();
                  }}
                  className="btn btn-small btn-secondary"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Existing Blocks with Full Management (Drag-and-Drop Reordering) */}
        {dataBlocks.length === 0 ? (
          <div className="empty-state">
            <h4 className="empty-state-title">📊 No Data Blocks Yet</h4>
            <p className="empty-state-text">
              Create your first data visualization block to organize and display your charts.
            </p>
          </div>
        ) : (
          <div className="content-grid"
            onDragOver={(e) => e.preventDefault()}
          >
            {dataBlocks
              .sort((a, b) => a.order - b.order)
              .map((block, idx) => (
              <div 
                key={block._id}
                className="block-item"
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData('text/plain', String(idx));
                }}
                onDrop={async (e) => {
                  e.preventDefault();
                  const fromIdx = parseInt(e.dataTransfer.getData('text/plain') || '-1', 10);
                  if (isNaN(fromIdx) || fromIdx === idx) return;
                  const ordered = [...dataBlocks].sort((a,b)=>a.order-b.order);
                  const [moved] = ordered.splice(fromIdx, 1);
                  ordered.splice(idx, 0, moved);
                  // Reassign sequential order
                  const reindexed = ordered.map((b, i) => ({ ...b, order: i }));
                  setDataBlocks(reindexed);
                  // Persist sequentially
                  for (const b of reindexed) {
                    await handleUpdateBlock(b);
                  }
                }}
                onMouseEnter={() => calculatePreviewForBlock(block)}
              >
                {/* Block Header */}
                <div className="block-header">
                  <div>
                    <h4 className="block-title">{block.name}</h4>
                    <div className="block-meta">
                      <span><strong>Charts:</strong> {block.charts?.length || 0}</span>
                      <span><strong>Order:</strong> {block.order}</span>
                    </div>
                  </div>
                  
                  {/* WHAT: Action buttons stacked vertically on right
                   * WHY: Consistent with hashtags, categories, variables, design pages */}
                  <div className="block-actions">
                    <div className={`status-badge ${block.isActive ? 'status-badge-active' : 'status-badge-inactive'}`}>
                      {block.isActive ? 'Active' : 'Inactive'}
                    </div>
                    
                    <div className="action-buttons-container">
                      <button
                        onClick={() => setEditingBlock(block)}
                        className="btn btn-small btn-primary action-button"
                      >
                        <MaterialIcon name="edit" variant="outlined" className={vizStyles.iconSpacing} />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeleteBlock(block._id!)}
                        className="btn btn-small btn-danger action-button"
                      >
                        <MaterialIcon name="delete" variant="outlined" className={vizStyles.iconSpacing} />
                        Delete
                      </button>
                      <span className="drag-handle" title="Drag to reorder">⮕️</span>
                    </div>
                  </div>
                </div>
                
                {/* Charts in this Block */}
                <div>
                  {!block.charts || block.charts.length === 0 ? (
                    <div className="empty-charts">
                      <p>No charts assigned to this block yet</p>
                      <p>Use &quot;Add Chart&quot; to assign charts from available options</p>
                    </div>
                  ) : (
                    <>
                      {/* Live Preview Grid - matches UnifiedDataVisualization */}
                      {/* WHAT: Apply CSS module base classes + dynamic grid ID for per-block responsive styling
                           WHY: Static styles use CSS modules; dynamic responsive grid uses inline <style> with block ID */}
                      <div className={`charts-grid charts-grid-${block._id || 'preview'} viz-preview-grid ${vizStyles.chartsGridBase}`}>
                        {block.charts
                          .sort((a, b) => a.order - b.order)
                          .map((chart) => {
                            const result = previewResults[chart.chartId];
                            const unitSize = normalizeUnitSize(chart.unitSize ?? chart.width);
                            if (!result) return null;
                            return (
                              <div key={`${block._id}-${chart.chartId}`} className={vizStyles.chartItem}>
                                <ReportChart 
                                  result={result} 
                                  width={unitSize}
                                  className={vizStyles.unifiedChartItem}
                                />
                              </div>
                            );
                          })
                          .filter(Boolean)
                        }
                      </div>

                      {/* WHAT: Dynamic responsive grid styling per block ID
                           WHY: Match UnifiedDataVisualization fr-based proportional grid system
                           HOW: Build fr units from chart widths (e.g., [2, 2, 3] → "2fr 2fr 3fr") */}
                      <style jsx>{`
                        /* Desktop: Auto-calculated fr units from chart widths (matches report pages) */
                        .charts-grid-${block._id || 'preview'} { 
                          grid-template-columns: ${block.charts
                            .sort((a, b) => a.order - b.order)
                            .map(c => `${normalizeUnitSize(c.unitSize ?? c.width)}fr`)
                            .join(' ')} !important;
                          justify-items: stretch !important;
                          align-items: start;
                        }
                        /* Tablet: Auto-wrap with 300px minimum width per chart */
                        @media (max-width: 1023px) {
                          .charts-grid-${block._id || 'preview'} { 
                            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)) !important; 
                          }
                        }
                        /* Mobile: Force single column */
                        @media (max-width: 767px) {
                          .charts-grid-${block._id || 'preview'} { 
                            grid-template-columns: 1fr !important; 
                          }
                        }
                        /* Chart container overrides */
                        .charts-grid-${block._id || 'preview'} :global(.chart-container) { 
                          min-width: 0 !important; 
                          max-width: none !important; 
                          width: 100% !important; 
                        }
                        .charts-grid-${block._id || 'preview'} :global(.chart-legend) { 
                          min-width: 0 !important; 
                          width: 100% !important; 
                          max-width: 100% !important; 
                          overflow: hidden; 
                        }
                      `}</style>
                    </>
                  )}
                  
                  {/* WHAT: Toggle button for show/hide editor settings */}
                  {/* WHY: Positioned between preview and editor for clear visual separation */}
                  <button
                    onClick={() => toggleBlockEditor(block._id!)}
                    className={vizStyles.toggleButton}
                    aria-expanded={expandedBlocks.has(block._id!)}
                    aria-controls={`editor-${block._id}`}
                  >
                    {expandedBlocks.has(block._id!) ? '⚙️ Hide Settings' : '⚙️ Show Settings'}
                  </button>
                  
                  {/* WHAT: Collapsible editor section containing chart controls + add buttons */}
                  {/* WHY: Hidden by default to reduce cognitive load, shown on demand */}
                  <div
                    id={`editor-${block._id}`}
                    className={`${vizStyles.editorSection} ${
                      expandedBlocks.has(block._id!) ? '' : vizStyles.editorSectionHidden
                    }`}
                  >
                    {/* Controls */}
                    <div className="chart-controls-grid">
                    {block.charts.map((chart, index) => {
                      const chartConfig = availableCharts.find(c => c.chartId === chart.chartId);
                      const chartType = resolveChartType(chart.chartId);
                      const normalizedChart = normalizeChartLayout(chart);
                      const unitSize = normalizedChart.unitSize ?? normalizeUnitSize(chart.unitSize ?? chart.width);
                      const aspectRatio = normalizedChart.aspectRatio ?? DEFAULT_ASPECT_RATIO[chartType];
                      const allowedUnits = LAYOUT_V2_ALLOWED_UNIT_SIZES[chartType] || [1];
                      const allowedAspects = LAYOUT_V2_ALLOWED_ASPECT_RATIOS[chartType] || ['1:1'];
                      return (
                        <div key={`${chart.chartId}-${index}`} className="chart-control-item">
                          <div className="chart-info">
                            <span className="chart-emoji">{chartConfig?.emoji || '📊'}</span>
                            <div>
                              <div className="chart-details">
                                {chartConfig?.title || chart.chartId}
                              </div>
                              <div className="chart-meta">
                                Unit size: {unitSize} unit{unitSize > 1 ? 's' : ''} • Aspect: {aspectRatio} • Order: {chart.order}
                                <br />
                                <span className="chart-sub-meta">
                                  Preview updates instantly to reflect unit size and aspect ratio
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="chart-controls">
                            {/* WHAT: Chart width selector (Spec v2.0 - simplified to 1 or 2 units)
                                WHY: Deterministic layout requires 1-unit (compact) or 2-unit (detailed) cells
                                HOW: Image aspect ratios drive row height, not unit counts
                                MIGRATION: Values >2 auto-clamped to 2 on save */}
                            <select
                              value={unitSize}
                              onChange={(e) => {
                                // WHAT: Parse immediately for dropdowns (not text input)
                                // WHY: Dropdown selections are intentional, no typing involved
                                updateChartWidth(block, index, parseFloat(e.target.value));
                              }}
                              className="chart-select"
                              disabled={allowedUnits.length === 1}
                            >
                              {allowedUnits.map(unit => (
                                <option key={unit} value={unit}>
                                  Unit size: {unit} unit{unit > 1 ? 's' : ''}
                                </option>
                              ))}
                            </select>

                            <select
                              value={aspectRatio}
                              onChange={(e) => updateChartAspectRatio(block, index, e.target.value as LayoutAspectRatio)}
                              className="chart-select"
                              disabled={allowedAspects.length === 1}
                            >
                              {allowedAspects.map(ratio => (
                                <option key={ratio} value={ratio}>
                                  Aspect: {ASPECT_RATIO_LABELS[ratio]}
                                </option>
                              ))}
                            </select>
                            
                            <button
                              onClick={() => removeChartFromBlock(block, index)}
                              className="btn btn-small btn-danger"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* WHAT: Block Aspect Ratio (A-UI-LAYOUT-02.1) – TEXT/TABLE-only blocks, 4:1 to 4:10 */}
                  {/* WHY: LayoutV2 allows variable block aspect ratio for text/table blocks */}
                  {/* HOW: Only show when block contains exclusively TEXT or exclusively TABLE charts; width=4 enforced by block capacity */}
                  {(() => {
                    const allText = block.charts.length > 0 && block.charts.every(chart => resolveChartType(chart.chartId) === 'text');
                    const allTable = block.charts.length > 0 && block.charts.every(chart => resolveChartType(chart.chartId) === 'table');
                    const totalUnits = block.charts.reduce((sum, c) => sum + (normalizeUnitSize(c.unitSize ?? c.width)), 0);
                    const canSetBlockAspectRatio = (allText || allTable) && totalUnits <= 4;
                    if (!canSetBlockAspectRatio) return null;
                    const BLOCK_ASPECT_OPTIONS = [
                      { value: '', label: 'Default (4:1)' },
                      ...([2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => ({ value: `4:${n}`, label: `4:${n}` })))
                    ];
                    return (
                      <div className={vizStyles.blockAspectRatioCard}>
                        <h4 className={vizStyles.blockAspectRatioTitle}>Block Aspect Ratio</h4>
                        <div className={vizStyles.blockAspectRatioControls}>
                          <label htmlFor={`block-aspect-${block._id}`} className={vizStyles.blockAspectRatioLabel}>
                            Aspect ratio (width:height):
                            <select
                              id={`block-aspect-${block._id}`}
                              value={block.blockAspectRatio ?? ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                const updatedBlock = {
                                  ...block,
                                  blockAspectRatio: val ? val : undefined
                                };
                                handleUpdateBlock(updatedBlock);
                              }}
                              className={vizStyles.blockAspectRatioSelect}
                            >
                              {BLOCK_ASPECT_OPTIONS.map(opt => (
                                <option key={opt.value || 'default'} value={opt.value}>{opt.label}</option>
                              ))}
                            </select>
                          </label>
                          <small className={vizStyles.blockAspectRatioHelper}>
                            Allowed only for TEXT-only or TABLE-only blocks. Range 4:1 to 4:10. For TABLE blocks, Table Height Multiplier (below) takes priority if set.
                          </small>
                        </div>
                      </div>
                    );
                  })()}

                  {/* WHAT: Table Height Multiplier Control (for TABLE-only blocks) */}
                  {/* WHY: Allow setting table height as multiplier of block width (height = blockWidth × multiplier) */}
                  {/* HOW: Only show for blocks containing exclusively TABLE charts */}
                  {(() => {
                    const allTables = block.charts.every(chart => {
                      const chartType = resolveChartType(chart.chartId);
                      return chartType === 'table';
                    });
                    
                    if (!allTables || block.charts.length === 0) return null;
                    
                    return (
                      <div className={vizStyles.tableHeightCard}>
                        <h4 className={vizStyles.tableHeightTitle}>Table Height Control</h4>
                        <div className={vizStyles.tableHeightControls}>
                          <label htmlFor={`table-height-multiplier-${block._id}`} className={vizStyles.tableHeightLabel}>
                            Height Multiplier:
                            <input
                              id={`table-height-multiplier-${block._id}`}
                              type="number"
                              min="0.1"
                              max="5.0"
                              step="0.1"
                              value={block.tableHeightMultiplier ?? 0.25}
                              onChange={(e) => {
                                const multiplier = parseFloat(e.target.value) || 0.25;
                                const updatedBlock = {
                                  ...block,
                                  tableHeightMultiplier: multiplier,
                                  // Clear blockAspectRatio if tableHeightMultiplier is set
                                  blockAspectRatio: multiplier !== 0.25 ? undefined : block.blockAspectRatio
                                };
                                handleUpdateBlock(updatedBlock);
                              }}
                              className={vizStyles.tableHeightInput}
                            />
                          </label>
                          <small className={vizStyles.tableHeightHelper}>
                            Height = Block Width × {block.tableHeightMultiplier ?? 0.25}
                            <br />
                            Example: 1200px width × 1.5 = 1800px height
                            <br />
                            Range: 0.1 to 5.0 (default: 0.25 = 4:1 aspect ratio)
                          </small>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Add Chart to Block */}
                  {/* WHAT: Separate regular charts, report images, and report texts for better UX */}
                  {/* WHY: Visual thumbnails for images and text previews make selection easier */}
                  {(() => {
                    const unassignedCharts = availableCharts.filter(chart => 
                      !block.charts.some(blockChart => blockChart.chartId === chart.chartId)
                    );
                    
                    // WHAT: Detect report content charts by chartId pattern OR title pattern
                    // WHY: Support both new auto-generated (report-image-N) and old manual ([stats.reportImageN])
                    // HOW: Add null safety checks for title field to prevent "undefined.includes" errors
                    const regularCharts = unassignedCharts.filter(c => 
                      !c.chartId.startsWith('report-image-') && 
                      !c.chartId.startsWith('report-text-') &&
                      !(c.title && c.title.includes('[stats.reportImage')) &&
                      !(c.title && c.title.includes('[stats.reportText'))
                    );
                    const reportImages = unassignedCharts.filter(c => 
                      c.chartId.startsWith('report-image-') || 
                      (c.title && c.title.includes('[stats.reportImage'))
                    );
                    const reportTexts = unassignedCharts.filter(c => 
                      c.chartId.startsWith('report-text-') || 
                      (c.title && c.title.includes('[stats.reportText'))
                    );
                    
                    return (
                      <>
                        {/* Regular Charts */}
                        {regularCharts.length > 0 && (
                          <div>
                            <h4 className={vizStyles.chartGroupHeader}>
                              Standard Charts
                            </h4>
                            <div className={`flex-row flex-wrap ${vizStyles.sectionSpacing}`}>
                              {regularCharts.map(chart => (
                                <button
                                  key={chart.chartId}
                                  onClick={() => addChartToBlock(block, chart.chartId)}
                                  className="btn btn-small btn-secondary"
                                >
                                  {chart.emoji || '📊'} {chart.title}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* Report Images with Thumbnails */}
                        {reportImages.length > 0 && (
                          <div>
                            <h4 className={vizStyles.chartGroupHeader}>
                              Report Images
                            </h4>
                            <div className={vizStyles.reportImageGrid}>
                              {reportImages.map(chart => {
                                // WHAT: Show placeholder thumbnail for report images
                                // WHY: Actual image URLs would require fetching project data
                                // HOW: Use chart icon and title for now (future: fetch sample project)
                                
                                return (
                                  <button
                                    key={chart.chartId}
                                    onClick={() => addChartToBlock(block, chart.chartId)}
                                    className={vizStyles.reportImageCard}
                                  >
                                    <div className={vizStyles.reportImagePlaceholder}>
                                      🖼️
                                    </div>
                                    <span className={vizStyles.reportImageTitle}>
                                      {chart.title}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}
                        
                        {/* Report Texts with Previews */}
                        {reportTexts.length > 0 && (
                          <div>
                            <h4 className={vizStyles.chartGroupHeader}>
                              Report Texts
                            </h4>
                            <div className={vizStyles.reportTextGrid}>
                              {reportTexts.map(chart => {
                                // WHAT: Show placeholder for report texts
                                // WHY: Actual text content would require fetching project data
                                // HOW: Show chart title and type info
                                
                                return (
                                  <button
                                    key={chart.chartId}
                                    onClick={() => addChartToBlock(block, chart.chartId)}
                                    className={vizStyles.reportTextCard}
                                  >
                                    <span className={vizStyles.reportTextTitle}>
                                      {chart.title}
                                    </span>
                                    <div className={vizStyles.reportTextContent}>
                                      📝 Text content block
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </>
                    );
                  })()}
                  
                  {availableCharts.filter(chart => !block.charts.some(blockChart => blockChart.chartId === chart.chartId)).length === 0 && (
                    <p className="info-note">
                      All available charts have been assigned to this block.
                    </p>
                  )}
                  </div>
                  {/* End of collapsible editor section */}
                </div>
              </div>
            ))}
          </div>
        )}
      </ColoredCard>
      )}

      {/* WHAT: Edit Block Modal migrated to unified FormModal
       * WHY: Consistent modal behavior across all admin pages */}
      {editingBlock && (
        <FormModal
          isOpen={!!editingBlock}
          onClose={() => setEditingBlock(null)}
          onSubmit={async () => {
            await handleUpdateBlock(editingBlock);
          }}
          title={`Edit Data Block: ${editingBlock.name}`}
          submitText="Update Block"
          size="lg"
          disableSubmit={liveBlockValidation != null && !liveBlockValidation.isValid}
          saveStatus={blockSaveStatus}
        >
            <div className="form-section">
              <div className="form-row">
                <div>
                  <label className="form-label">Block Name</label>
                  <input
                    type="text"
                    value={editingBlock.name}
                    onChange={(e) => setEditingBlock({ ...editingBlock, name: e.target.value })}
                    placeholder="e.g., Main Dashboard, Performance Metrics"
                    className="form-input"
                  />
                </div>
                
                <div>
                  <label className="form-label">Order</label>
                  <input
                    type="number"
                    value={editingBlock.order}
                    onChange={(e) => {
                      // WHAT: Allow typing freely without immediate parsing
                      // WHY: User can delete "0" to enter new value smoothly
                      const val = e.target.value;
                      setEditingBlock({ ...editingBlock, order: val === '' ? '' as any : val as any });
                    }}
                    onBlur={() => {
                      // WHAT: Parse and validate only on blur
                      const parsed = Math.max(0, parseInt(String(editingBlock.order)) || 0);
                      setEditingBlock({ ...editingBlock, order: parsed });
                    }}
                    className="form-input"
                  />
                </div>
                
              </div>
              <p className="info-note">
                💡 Grid columns auto-calculated from unit sizes (e.g., units 2+1+1 = &ldquo;2fr 1fr 1fr&rdquo; grid).<br/>
                Tablet: auto-wrap at 300px min-width | Mobile: single column
              </p>

              {/* OPS-LAYOUT-01: Real-time Layout Grammar validation (scrolling, truncation, clipping) */}
              {liveBlockValidation && (
                <div className={liveBlockValidation.isValid ? vizStyles.layoutCheckOk : vizStyles.layoutCheckError}>
                  <strong>Layout check:</strong>{' '}
                  {liveBlockValidation.isValid
                    ? '✓ OK – block can be saved'
                    : liveBlockValidation.errorMessage || 'Block has layout issues that must be fixed before save'}
                </div>
              )}
              
              <div>
                <label className="flex-row checkbox-label">
                  <input
                    type="checkbox"
                    checked={editingBlock.isActive}
                    onChange={(e) => setEditingBlock({ ...editingBlock, isActive: e.target.checked })}
                    className="checkbox-input"
                  />
                  <span className="form-label">Active</span>
                </label>
                <p className="info-note">
                  Inactive blocks will not be displayed on the frontend
                </p>
              </div>
              
              <div>
                <label className="flex-row checkbox-label">
                  <input
                    type="checkbox"
                    checked={editingBlock.showTitle !== false}
                    onChange={(e) => setEditingBlock({ ...editingBlock, showTitle: e.target.checked })}
                    className="checkbox-input"
                  />
                  <span className="form-label">Show Title</span>
                </label>
                <p className="info-note">
                  When unchecked, the block title will not be displayed on stat pages
                </p>
              </div>
            </div>
        </FormModal>
      )}
    </div>
  );
}
