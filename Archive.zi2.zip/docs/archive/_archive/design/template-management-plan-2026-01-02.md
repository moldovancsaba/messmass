# Report Template Management - Implementation Plan
Status: Archived
Last Updated: 2026-02-06T15:00:00Z
Canonical: No
Owner: Architecture

## Archive Note (2026-02-06)
This plan is archived to avoid maintaining a second backlog. If template management improvements are still desired, track them in `docs/operations/operations-roadmap.md` and/or `docs/operations/operations-action-plan.md`.

**Date:** 2026-01-02  
**Feature:** Add Rename, Copy, Delete operations to Report Template management  
**Location:** `app/admin/visualization/page.tsx` (Visualization Manager)

---

## Current State

**Template Selector UI:**
- Dropdown to select template
- "🎯 Edit Live Partner Reports" button
- "➕ New Template" button
- Template info display (blocks count, grid size)

**Existing API:**
- `GET /api/report-templates` - List templates
- `POST /api/report-templates` - Create template
- `PUT /api/report-templates?templateId=...` - Update template (supports name update)
- `DELETE /api/report-templates?templateId=...` - Delete template (with safety checks)

**Existing Modal System:**
- `FormModal` - For forms (create/edit)
- `ConfirmDialog` - For confirmations (delete)
- `BaseModal` - For custom layouts

---

## Implementation Plan

### 1. UI Changes

**Add "Edit Template" button:**
- Location: Next to template dropdown (after "New Template" button)
- Icon: Material Icon "edit" or "more_vert" (menu)
- Action: Opens template management modal

**Template Management Modal:**
- Title: "📝 Manage Report Template: [Template Name]"
- Size: `md` (medium)
- Three sections:
  1. **Rename Section**
     - Input field (pre-filled with current name)
     - "Save" button
     - Updates template name via PUT API
  2. **Copy Section**
     - "Copy Template" button
     - Creates duplicate with "Copy of [Name]" suffix
     - Uses POST API with all template data
     - Auto-selects new template after copy
  3. **Delete Section**
     - "Delete Template" button (danger style)
     - Opens ConfirmDialog for confirmation
     - Shows warning if template is in use
     - Uses DELETE API

### 2. Component Structure

**Modal Component:**
- Use `BaseModal` or `FormModal` (depending on layout needs)
- If using `FormModal`: Custom footer with 3 action buttons
- If using `BaseModal`: Custom layout with 3 sections

**State Management:**
```typescript
const [showTemplateEditModal, setShowTemplateEditModal] = useState(false);
const [templateEditName, setTemplateEditName] = useState('');
const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
```

**API Calls:**
- Rename: `apiPut('/api/report-templates?templateId=...', { name: newName })`
- Copy: `apiPost('/api/report-templates', { ...template, name: 'Copy of ' + template.name, isDefault: false })`
- Delete: `apiDelete('/api/report-templates?templateId=...')`

### 3. Implementation Details

**Rename Operation:**
1. User clicks "Edit Template" button
2. Modal opens with current template name in input
3. User edits name
4. User clicks "Save" button
5. PUT request to update name
6. Refresh templates list
7. Update selected template if it was renamed
8. Close modal

**Copy Operation:**
1. User clicks "Copy Template" button
2. POST request with template data (excluding _id, createdAt)
3. New template created with "Copy of [Name]" suffix
4. Refresh templates list
5. Auto-select new template
6. Show success message
7. Close modal

**Delete Operation:**
1. User clicks "Delete Template" button
2. Open ConfirmDialog with warning message
3. If confirmed, DELETE request
4. If template is in use, show error from API
5. Refresh templates list
6. Clear selection if deleted template was selected
7. Close modal

### 4. Safety Checks

**Delete Safety (from API):**
- Cannot delete default template
- Cannot delete template in use by partners/projects
- API returns error with details

**Copy Safety:**
- New template should not be marked as default
- Copy all dataBlocks, gridSettings, heroSettings, alignmentSettings
- Generate new _id (handled by API)

**Rename Safety:**
- Validate name is not empty
- Check for duplicate names (optional - can allow duplicates)

### 5. User Experience

**Modal Layout:**
```
┌─────────────────────────────────────┐
│ 📝 Manage Report Template: [Name]  │
├─────────────────────────────────────┤
│                                     │
│ Rename Template                     │
│ ┌─────────────────────────────┐   │
│ │ [Template Name Input]       │   │
│ └─────────────────────────────┘   │
│ [Save Name]                        │
│                                     │
│ Copy Template                       │
│ [Copy Template]                     │
│                                     │
│ Delete Template                     │
│ [Delete Template] (danger)         │
│                                     │
│ [Cancel]                            │
└─────────────────────────────────────┘
```

**Button Styles:**
- Rename "Save": `btn-primary`
- Copy: `btn-secondary`
- Delete: `btn-danger`
- Cancel: `btn-secondary` (in modal footer)

### 6. Files to Modify

1. **`app/admin/visualization/page.tsx`**
   - Add state for edit modal
   - Add "Edit Template" button
   - Add template management modal
   - Add handlers for rename/copy/delete
   - Use `apiPut`, `apiPost`, `apiDelete` from `apiClient.ts`

2. **`app/admin/visualization/Visualization.module.css`** (if needed)
   - Add styles for template management modal sections

### 7. Dependencies

**Existing Modules:**
- `FormModal` or `BaseModal` from `components/modals/`
- `ConfirmDialog` from `components/modals/`
- `apiPut`, `apiPost`, `apiDelete` from `lib/apiClient.ts`
- `MaterialIcon` from `components/MaterialIcon.tsx`

**No New Dependencies Required**

---

## Implementation Steps

1. ✅ Read existing code (done)
2. ⏳ Add state management for edit modal
3. ⏳ Add "Edit Template" button to UI
4. ⏳ Create template management modal component
5. ⏳ Implement rename handler
6. ⏳ Implement copy handler
7. ⏳ Implement delete handler with ConfirmDialog
8. ⏳ Add error handling and success messages
9. ⏳ Test all three operations
10. ⏳ Update documentation

---

## Acceptance Criteria

- "Edit Template" button visible next to template dropdown
- Clicking "Edit Template" opens modal with current template name
- Rename operation updates template name and refreshes list
- Copy operation creates new template with "Copy of [Name]" and auto-selects it
- Delete operation shows confirmation dialog and prevents deletion if in use
- All operations use existing modal system (FormModal/BaseModal/ConfirmDialog)
- All operations use existing API client (apiPut/apiPost/apiDelete)
- Error handling shows user-friendly messages
- Success messages confirm actions
- No hardcoded values, uses design system

---

*Plan created: 2026-01-02 | Tribeca*

---

## Appendix: Template Selection Persistence (2026-01-02)
Status: Archived

This appendix preserves the historical implementation note for template selection persistence.

## Overview

The Visualization Manager remembers the user's last selected report template across:
- Page reloads
- Browser sessions
- Different devices (per user account)

---

## Implementation Details

### 1. User Preferences API

**Endpoint:** `/api/user-preferences`

**GET** - Fetch user preferences:
- Returns `lastSelectedTemplateId` if set
- Keyed by user email (from authentication)

**PUT** - Update user preferences:
- Accepts `lastSelectedTemplateId` in request body
- Stores in MongoDB `user_preferences` collection
- Uses upsert to create or update

**Storage:**
- Collection: `user_preferences`
- Key: `userId` (user email)
- Field: `lastSelectedTemplateId` (string, optional)

### 2. Visualization Manager Flow

**On Page Load:**
1. Load all templates from `/api/report-templates`
2. Load user preferences from `/api/user-preferences`
3. If `lastSelectedTemplateId` exists and template still exists:
   - Select that template
4. Otherwise:
   - Select default template (if exists)
   - Or select first template

**On Template Change:**
1. User selects template from dropdown
2. `handleTemplateChange()` is called
3. Updates local state immediately
4. Saves preference to `/api/user-preferences` (fire-and-forget)
5. Preference persists for next visit

### 3. Code Locations

**Frontend:**
- `app/admin/visualization/page.tsx`
  - `loadUserPreferences()` - Lines 229-266
  - `handleTemplateChange()` - Lines 270-282
  - Initialization - Lines 138-147

**Backend:**
- `app/api/user-preferences/route.ts`
  - GET handler - Lines 20-46
  - PUT handler - Lines 52-92

### 4. Error Handling

**Load Preferences:**
- If API fails: Falls back to default template
- If template doesn't exist: Falls back to default template
- Errors are logged but don't block UI

**Save Preferences:**
- Uses fire-and-forget pattern
- Errors are silently ignored (doesn't block template selection)
- Uses `apiPut()` for CSRF protection

### 5. User Experience

**First Visit:**
- No preference stored
- Selects default template (or first template)

**Subsequent Visits:**
- Automatically selects last used template
- User can still change selection manually
- New selection is remembered for next visit

**Template Deleted:**
- If saved template is deleted, falls back to default
- User can select a new template, which is then remembered

---

## Technical Notes

**CSRF Protection:**
- Uses `apiPut()` from `apiClient.ts` for preference updates
- Automatically includes CSRF token in request headers

**Race Condition Prevention:**
- Templates are loaded before preferences are checked
- Ensures template exists before selecting it

**Persistence Scope:**
- Per-user (based on email)
- Cross-browser (same user account)
- Cross-device (same user account)
- Not shared between different users

---

## Testing

**Manual Test:**
1. Select a template in Visualization Manager
2. Reload the page
3. Verify same template is selected
4. Change template
5. Reload again
6. Verify new template is selected

**Edge Cases:**
- Template deleted after being saved as preference → Falls back to default
- No templates available → No selection (handled gracefully)
- User not authenticated → Falls back to default (no error)

---

## Future Enhancements

**Potential Improvements:**
- Add preference for other settings (grid units, collapsed blocks, etc.)
- Add UI indicator showing "Last used template"
- Add option to clear saved preference
- Add preference sync across devices (if needed)

---

**Signed-off-by:** Tribeca  
**Last Updated: 2026-01-11T22:28:38.000Z
