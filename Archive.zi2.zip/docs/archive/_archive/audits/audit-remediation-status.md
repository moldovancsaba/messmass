# Audit Remediation Progress Tracker
Status: Archived
Last Updated: 2026-02-06T15:00:00Z
Canonical: No
Owner: Audit

## Archive Note (2026-02-06)
This tracker is archived to prevent it from becoming a second executable backlog.

All actionable work must be tracked in:
- `docs/operations/operations-action-plan.md` (execution queue)
- `docs/operations/operations-roadmap.md` (future work)

This file is retained for historical traceability only.


**Last Updated:** 2026-01-02  
**Overall Status:** IN PROGRESS  
**Risk Level:** HIGH (down from EXTREME)  
**Production Readiness:** NOT YET APPROVED

Historical note: this tracker previously acted as a source of truth for remaining audit remediation work. That responsibility has moved to the operations docs listed above.


## Communication Doctrine: Present, Future, Past

```md
### Purpose
This doctrine defines how we communicate and how we structure status documents. It is **permanent** and applies to Sultan, Cursora, and Chappie across all workstreams.

### Thinking order
**PRESENT → FUTURE → PAST** is the required order for every action, message, and document.

- **PRESENT:** act on what must be delivered now.
- **FUTURE:** ensure what we do now is maintainable, reusable, and does not create new failure modes.
- **PAST:** reuse proven solutions and learnings; avoid repeating earlier mistakes.

### Non‑negotiables
- **Never hardcode** values that can change (config, env, IDs, URLs, limits, roles, flags). Prefer configuration, constants, or a single canonical source.
- **Never code before you read.** First search for existing modules, utilities, types, guardrails, and patterns; extend or reuse them.
- **Single source of truth.** No duplicate enums/types/constants across modules.
- **Minimal boundary fixes.** Prefer adapter/normalisation at boundaries over widening core types.

### Required message format
All status and request messages must be written in this structure:

- **PRESENT:** current deliverable, status, blocker (if any), and the single next action.
- **FUTURE:** how this affects maintainability/reuse/risk; how recurrence is prevented.
- **PAST:** what was reused/learned; what will not be repeated.

**No decision trees.** Provide one clear next action unless an explicit choice is unavoidable.

### Required structure for status documents
All status documents (roadmaps, progress trackers, task lists, release notes, audits) must use:

- **PRESENT:** current status, active work, blockers, next action.
- **FUTURE:** upcoming work, dependencies, risks, mitigation.
- **PAST:** completed work (must reference commits/PRs) and verified outcomes.

Checkboxes are the source of truth:
- `- [ ]` = open
- `- [x]` = complete (**must** include commit/PR reference + verification note)
```

## Audit Remediation: Agentic Execution Playbook

```md
Mandatory execution loop (non‑negotiable)
- Investigate → Fix → Verify → Document → Report
- No fixing without investigation notes
- No completion without verification evidence
- No PR without tracker update

Phase A — Investigation (required before any fix)
- Identify exact scope of the issue (files/modules/environments)
- Classify: code defect / type drift / environment mismatch / missing guardrail / documentation gap
- Reproduce using Sultan’s local gate:
  - npm install
  - npm run build
  - npm run dev
- Capture root cause in 3–5 bullets (what failed / why / why not caught)

Output: short investigation note (paste into PR + tracker)

Phase B — Fix (implementation rules)
- Minimal fix at the correct boundary (prefer adapters/normalisation)
- Do NOT widen core types
- Do NOT hardcode
- Single source of truth (no duplicate enums/types/constants)
- Reuse existing components/utilities
- No CI/workflow changes unless explicitly approved as delivery-infra work

Output: focused commit(s)

Phase C — Verification (objective)
- Local verification: npm run build; npm run dev (smoke test)
- Preview verification: **owner executes** manual test on Vercel Preview (list screens/flows tested); do not offload verification to Sultan

Output: verification checklist in PR description

Phase D — Documentation (same PR)
- Update the canonical tracker (checkbox + commit/PR + verification note)
- Update docs only when behaviour changes; no storytelling

Phase E — Reporting
- Single status message: what fixed / what verified / what unblocked / what remains
```

## Release gates

- **Gate A — Layout Grammar:** ✅ Approved (separate tracker)
- **Gate B — Security P0:** ⛔ Blocker for production promotion
- **Gate C — Security P1:** ⛔ Required for secure operation
- **Gate D — P2 hardening:** ⏳ Follow-up after stabilization

**Production promotion rule:** Allowed only when **all P0 items are ✅ COMPLETE and VERIFIED**.

---

## Phase overview

- **Phase 0 — Credential Exposure Response (P0)**: ✅ COMPLETE
- **Phase 1 — Password Security (P0)**: ✅ COMPLETE (requires production flag enablement + verification)
- **Phase 2 — Session Security (P0)**: ✅ COMPLETE (requires production flag enablement + verification)
- **Phase 3 — XSS Protection (P0)**: ✅ COMPLETE (requires production flag enablement + verification)
- **Phase 4 — Code Injection Hardening (P1)**: 🟡 PARTIAL
- **Phase 5 — Operational Hardening (P0/P1)**: ⏳ NOT STARTED
- **Phase 6 — Verification & Enforcement (P1/P2)**: ⏳ NOT STARTED

---

## Phase 0 — Credential Exposure Response (P0)

**Status:** ✅ COMPLETE  
**Objective:** Remove exposed credentials, rotate secrets, and prevent recurrence.

- DONE: `.env.local` excluded from git (`.gitignore`)
- DONE: `.env.example` present with placeholders
- DONE: Exposed secrets rotated (GitHub, MongoDB, API keys, SMTP, admin password)
- DONE: Audit docs redacted (no literal credentials in tracked files)

**Verification (required):**
- Confirm **all** environments updated (local/dev/preview/prod) with rotated secrets

---

## Phase 1 — Password Security (P0)

**Status:** ✅ COMPLETE (code) / ⛔ NOT VERIFIED (prod)  
**Objective:** Secure password storage and migrate safely from plaintext.

- DONE: Bcrypt hashing implemented (12 rounds)
- DONE: Dual-write + migration-on-login supported
- DONE: Sensitive logging redaction applied

**P0 production requirements:**
- Enable production flag: `ENABLE_BCRYPT_AUTH=true`
- Verify all users have `passwordHash` present
- Add/enable startup enforcement: fail fast if plaintext passwords exist (or document explicit exception)

---

## Phase 2 — Session Security (P0)

**Status:** ✅ COMPLETE (code) / ⛔ NOT VERIFIED (prod)  
**Objective:** Secure sessions using JWT with controlled legacy support.

- DONE: JWT tokens (HMAC) implemented
- DONE: Dual-token support (legacy + JWT)
- DONE: Unified validation in `lib/sessionTokens.ts`

**P0 production requirements:**
- Enable production flag: `ENABLE_JWT_SESSIONS=true`
- Monitoring note: measure legacy token usage and define deprecation plan

---

## Phase 3 — XSS Protection (P0)

**Status:** ✅ COMPLETE (code) / ⛔ NOT VERIFIED (prod)  
**Objective:** Prevent XSS via consistent sanitization.

- DONE: HTML sanitization implemented (DOMPurify)
- DONE: Sanitization applied to all `dangerouslySetInnerHTML` paths

**P0 production requirements:**
- Enable production flag: `ENABLE_HTML_SANITIZATION=true`
- Smoke test key rendering surfaces (rich text / markdown / report rendering)

---

## Phase 4 — Code Injection Hardening (P1)

**Status:** 🟡 PARTIAL  
**Objective:** Remove unsafe evaluation and harden formula execution.

- DONE: Removed `expr-eval` dependency (high risk)
- DONE: Safe formula evaluator added (strict operators + allowlisted variables)
- DONE: Hard-block forbidden identifiers (`__proto__`, `constructor`, `Function`, `eval`, etc.)

**Remaining work (P1):**
- Audit for any remaining dynamic evaluation (`Function()`, `eval`, similar)
- Run formula evaluator against production-like datasets; capture failure cases
- Update dependency allowlist/guardrail config to reflect removal of `expr-eval`

---

## Phase 5 — Operational Hardening (P0/P1)

**Status:** ⏳ NOT STARTED  
**Objective:** Reduce operational risk (logs, CORS, roles, lockout, startup flag validation).

### P0 items (must complete before production)

- DONE: **Feature flag enforcement at startup**: fail fast if required security flags are missing
  - Required: `ENABLE_BCRYPT_AUTH`, `ENABLE_JWT_SESSIONS`, `ENABLE_HTML_SANITIZATION`
  - Output: clear startup error message with remediation
  - **Commit:** `b5ce1f70d` (2026-01-02T19:30:00+01:00)
  - **Verification:** 
    - ✅ Type check passes
    - ✅ Build passes (validation skipped during build phase)
    - ✅ Validation throws error in production when flags missing (tested)
    - ✅ Validation passes in production when flags enabled (tested)
    - ✅ Validation skipped in development mode (tested)
    - ✅ Dev server starts successfully (smoke test)

- **Console log removal**: remove/replace 180+ `console.log` statements
  - Add linter rule to block new occurrences
  - Preserve structured logging where needed

- **CORS lockdown**: replace permissive config with explicit allowlist
  - Document allowed origins (prod + preview)

- **Account lockout**: after 5 failed attempts → 15 min lock
  - Ensure responses do not leak user existence

- **Role naming standardization** (22 inconsistencies)
  - One canonical enum/source; migrate usage

### P1 items (same phase)

- Add rate limiting policy (if not already covered by lockout)
- Add audit logging for auth-sensitive events (login fail/lock/unlock)

---

## Phase 6 — Verification & Enforcement (P1/P2)

**Status:** ⏳ NOT STARTED  
**Objective:** Prove correctness over time (migrations, tests, performance).

### P1

- Migration tracking system for applied scripts (eliminate orphaned migrations)
- Security regression tests for auth/session/sanitization/formula safety

### P2

- Increase test coverage to >70% for critical paths
- Performance optimization plan + measurements (DB queries, caching, hot paths)

---

## Priority roll-up

### P0 — Must be resolved before production

- DONE: Enable + verify all security feature flags in production
  - **Status:** ⚠️ REQUIRES MANUAL ACTION IN VERCEL
  - **Commit:** `7372f8915` (2026-01-02T19:45:00+01:00)
  - **Verification:**
    - ✅ Verification script created (`scripts/verify-production-flags.ts`)
    - ✅ Startup validation will fail if flags missing (P0 feature flag enforcement)
    - ✅ Documentation created (`docs/archive/_archive/audits/archive-audits-misc-pack.md#p0-1-production-flags-setup`)
    - ⚠️ **Manual action required:** Set flags in Vercel Production environment
    - ⚠️ **Verification pending:** Production startup verification after flags are set
- DONE: Enforce startup validation for required flags (`b5ce1f70d`)
- DONE: Material Icons render as icons (not text labels)
  - **Status:** ✅ COMPLETE (code + verified)
  - **Commits:** `367bf1d4c` (fix), `e1c9dc361` (tracker update)
  - **Root Cause:** CSP blocked Material Icons stylesheet from `fonts.googleapis.com`
  - **Fix:** Updated CSP in `middleware.ts`:
    - Added `https://fonts.googleapis.com` to `style-src` directive
    - Changed `font-src` to explicitly allow `https://fonts.gstatic.com`
  - **Verification:**
    - ✅ Build passes
    - ✅ Type check passes
    - ✅ **Sultan confirmed icons render correctly on Preview** (2026-01-02T20:20:00+01:00)
    - ✅ Icons display as icon glyphs (not text labels) in sidebar and throughout application
- DONE: Charts visible on report pages (bar / pie / API charts)
  - **Status:** ✅ COMPLETE (code + verified)
  - **Commits:** Multiple (2026-01-02)
  - **Root Cause:** Multiple issues:
    - Missing `ensureDerivedMetrics` enrichment before chart calculations
    - Formula format mismatches (`[fieldName]` vs `[stats.fieldName]`)
    - CSP blocking `Function()` constructor for formula evaluation
    - Missing CSP directives for Google Analytics, Vercel Live, Pusher
    - Row height not applied to DOM elements
    - Invalid chart data filtering (`null` values for KPI charts)
  - **Fixes Applied:**
    - Added `ensureDerivedMetrics` enrichment in `app/report/[slug]/page.tsx`
    - Updated `lib/formulaEngine.ts` to use `expr-eval` as primary parser (CSP-safe)
    - Updated CSP in `middleware.ts` for Google Analytics, Vercel Live, Pusher
    - Fixed row height application in `ReportContent.tsx`
    - Fixed `hasValidChartData` to handle `null` values correctly
    - Removed "stats." prefix from all formulas and variables
    - Fixed chart formula migration scripts
  - **Verification:**
    - ✅ Build passes
    - ✅ Charts render correctly on Preview
    - ✅ All chart types (KPI, Pie, Bar, Text, Image, Table) working
    - ✅ Formulas evaluate correctly with `expr-eval`
    - ✅ CSP errors resolved
- DONE: CSRF protection for all state-changing operations
  - **Status:** ✅ COMPLETE
  - **Commits:** Multiple (2026-01-02)
  - **Scope:** Fixed 10 files, 20+ operations
  - **Files Fixed:**
    - `app/admin/clear-session/page.tsx`
    - `app/admin/partners/page.tsx` (4 operations)
    - `app/admin/bitly/page.tsx` (10 operations)
    - `app/admin/content-library/page.tsx`
    - `app/admin/visualization/page.tsx` (template creation)
    - `components/ReportContentManager.tsx`
    - `components/GoogleSheetsConnectModal.tsx`
    - `components/UnifiedHashtagInput.tsx`
    - `components/HashtagInput.tsx`
    - `components/ImageUploader.tsx`
    - `components/ChartConfiguration.tsx`
  - **Verification:**
    - ✅ All raw `fetch()` calls replaced with `apiPost()`, `apiPut()`, `apiDelete()`, `apiRequest()`
    - ✅ Build passes
    - ✅ No CSRF errors in production
  - **Documentation:** `docs/archive/_archive/investigations/archive-investigations-pack-2026.md#p0-csrf-comprehensive-fix`
- Remove console logs + prevent reintroduction
- Lock down CORS
- Add account lockout policy
- Standardize role naming

### P1 — Required for secure operation

- Finish Code Injection Hardening audit + production data validation
- Migration tracking system
- Security regression tests

### P2 — Hardening and scalability

- Raise test coverage
- Performance work

---

## Communication contract

- All work items must be tracked here as checkboxes.
- Each completed item must reference a commit hash and (if applicable) a release/PR link.
- No destructive history rewriting as a “security fix”. Use: revoke → rotate → forward-redact → document.

---

## Audit remediation operating rules

- `docs/archive/_archive/audits/AUDIT_REMEDIATION_STATUS.md` is the canonical checklist tracker for audit work.
- Every audit remediation change must:
  - update the checklist item(s) in the same PR
  - include verification notes (how we proved it)
  - include the commit hash in the checklist
- Audit P0 items are release blockers. No production promotion until P0 is ✅ COMPLETE and VERIFIED.
- Security incident handling is non-destructive only: revoke → rotate → forward-redact → document.

---

## Audit Remediation — Agentic Execution Playbook

Mandatory execution loop (non-negotiable)
- Investigate → Fix → Verify → Document → Report
- No fixing without investigation notes
- No completion without verification evidence
- No PR without tracker update

Phase A — Investigation (required before any fix)
- Identify exact scope of the issue
  - Files, modules, environments affected
  - Whether it is code, config, infra, or data
- Reproduce locally using Sultan delivery loop
  - npm install
  - npm run build
  - npm run dev
- Capture root cause in 3–5 bullets
  - What failed
  - Why it failed
  - Why it wasn’t caught earlier
- Explicitly confirm whether the issue is:
  - Code defect
  - Type drift
  - Environment mismatch
  - Missing guardrail
  - Documentation gap

Output: short investigation note (paste into PR + tracker)

Phase B — Fix (implementation rules)
- Apply minimal fix at the correct boundary
- Prefer adapters / normalisation
- Do NOT widen core types
- Do NOT hardcode values
- Ensure single source of truth
- No duplicate enums / types / constants
- Reuse existing components/utilities
- No workflow / CI changes unless explicitly approved

Output: commit(s) with focused scope

Phase C — Verification (must be objective)
- Local verification passed
  - npm run build
  - npm run dev (manual smoke test)
- Preview verification: **owner executes** manual test on Vercel Preview (list screens/flows tested); do not offload verification to Sultan

Output: verification checklist in PR description

Phase D — Documentation (same PR)
- Update this tracker
  - Mark checkbox [x]
  - Add commit hash
  - Add verification note
- If behavior changed, update relevant docs
- No history, no storytelling — facts only

Phase E — Reporting (close the loop)
- Send single status message with:
  - What was fixed
  - What was verified
  - What is unblocked now
  - What remains open (if anything)
