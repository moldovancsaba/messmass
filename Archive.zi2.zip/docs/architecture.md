# {messmass} Architecture Documentation
Status: Active
Last Updated: 2026-02-05T19:29:57.000Z
Canonical: No
Owner: Architecture

Version: 11.55.1

**Recent Update (2026-01-16):** 
- **Partner Links**: Partner edit/report buttons now use `partner._id` (ObjectId) instead of `viewSlug` for reliable access. This fixes "Invalid partner ID format" errors when `viewSlug` is human-readable.
- **Clicker Manager UX**: Chart algorithm selection replaced text input with searchable dropdown showing all available charts. Users can now discover and select algorithms like "gender-distribution", "szerencse-gender", etc. without manual typing.

**Previous Update (2026-01-21):** Clicker Manager now treats `clickerSetId` as a required, stringified identifier end-to-end. All variable group CRUD calls must pass `clickerSetId` at the request root; APIs accept both string and legacy ObjectId values for backward compatibility but persist strings to prevent cross-set leakage.

## 🔍 MANDATORY: Implementation Standards

**Before implementing ANY feature or component:**

### Rule 1: Search Existing Implementations

**NEVER create custom implementations without checking existing patterns first.**

**Reference Files:**
- **Modals**: `components/modals/FormModal.tsx` (lines 1-148)
- **Cards**: `components/ColoredCard.tsx` (lines 1-89)
- **Forms**: `app/admin/projects/ProjectsPageClient.tsx` (lines 916-960)
- **Hashtags**: `components/UnifiedHashtagInput.tsx` (lines 1-298)
- **Partners**: `components/PartnerSelector.tsx` (lines 1-234)
- **Admin Layout**: `components/AdminHero.tsx` (lines 1-98)

### Rule 2: Use Design Tokens Exclusively

**ALL styling MUST use CSS variables from `app/styles/theme.css`**

```css
/* ✅ CORRECT */
.myComponent {
  color: var(--mm-gray-900);
  padding: var(--mm-space-4);
  border-radius: var(--mm-radius-lg);
}

/* ❌ FORBIDDEN */
.badComponent {
  color: #1f2937;      /* ❌ */
  padding: 16px;       /* ❌ */
  border-radius: 8px;  /* ❌ */
}
```

### Rule 3: Match Existing Structure Exactly

**Example - Modal Pattern:**
```tsx
// ✅ CORRECT: Use FormModal
import FormModal from '@/components/modals/FormModal';

<FormModal
  isOpen={isOpen}
  onClose={onClose}
  onSubmit={handleSubmit}
  title="Your Title"
  size="lg"
>
  {/* Content */}
</FormModal>
```

**Real Implementation:** See `app/admin/partners/page.tsx` lines 298-387 for complete example.

### Rule 4: Consequences of Non-Compliance

| Violation | Result |
|-----------|--------|
| Custom modal instead of FormModal | ❌ Rejection |
| Hardcoded colors/spacing | ❌ Rejection |
| Not using ColoredCard | ❌ Rejection |
| Not searching codebase first | ❌ Rejection |

**See:** `CODING_STANDARDS.md` for complete rules and enforcement.

---

## 🏗️ Centralized Module Architecture

### Module Management Philosophy

**{messmass} operates on a centralized module architecture where ALL reusable components, utilities, and styling systems are maintained as single-source-of-truth implementations.**

**Core Principle**: One implementation, many consumers.

### Module Inventory & Catalog

**Complete Reference**: `REUSABLE_COMPONENTS_INVENTORY.md`

**Module Categories** (210+ total modules):

| Category | Count | Location | Examples |
|----------|-------|----------|----------|
| **UI Components** | 60+ | `components/` | FormModal, ColoredCard, UnifiedHashtagInput |
| **Design Tokens** | 200+ | `app/styles/theme.css` | `--mm-color-primary-500`, `--mm-space-4` |
| **Utility Functions** | 50+ | `lib/` | `formulaEngine`, `chartCalculator`, `analytics*` |
| **Utility CSS** | 100+ | `app/styles/utilities.css` | `.flex-center`, `.text-bold`, `.p-4` |
| **Hooks** | 10+ | `hooks/`, `lib/shareables/` | `usePageStyle`, `useHashtags`, `useAuth` |
| **Type Definitions** | 20+ | `lib/types/` | API types, hashtag types, chart types |

### Module Dependency Map

**Critical Dependencies** (update with care):

```
FormModal (components/modals/FormModal.tsx)
├── Used by: 12 admin pages
├── Depends on: BaseModal, design tokens
├── CSS: FormModal.module.css
└── Impact: High (core admin functionality)

ColoredCard (components/ColoredCard.tsx)
├── Used by: 25+ pages/components
├── Depends on: design tokens
├── CSS: ColoredCard.module.css
└── Impact: Critical (universal card component)

theme.css (app/styles/theme.css)
├── Used by: ALL styled components (100+)
├── Tokens: 200+ CSS variables
├── Scope: Global (:root)
└── Impact: System-wide (changes affect entire app)

formulaEngine (lib/formulaEngine.ts)
├── Used by: Chart system, analytics, KYC
├── Depends on: Variable metadata, stats schema
├── Functions: 12+ formula evaluation functions
└── Impact: High (core calculation engine)
```

### Centralized Update Strategy

**When ANY module needs updating:**

#### Step 1: Impact Assessment
```bash
# Find all usages
grep -r "import.*FormModal" app/ components/
grep -r "from '@/components/modals/FormModal'" app/ components/

# Count affected files
grep -r "FormModal" app/ components/ --include="*.tsx" | wc -l
```

#### Step 2: Document Affected Modules
**MANDATORY in task planning:**

```markdown
## Task: Add Loading State to FormModal

### Affected Modules:
- **Primary**: `components/modals/FormModal.tsx`
- **Dependent**: 12 admin pages
  - app/admin/partners/page.tsx
  - app/admin/variables/page.tsx
  - app/admin/kyc/page.tsx
  - app/admin/categories/page.tsx
  - app/admin/hashtags/page.tsx
  - [... 7 more]

### Impact Level: HIGH
- Core component used system-wide
- Requires testing across all admin workflows
- CSS changes may affect modal height calculations
```

#### Step 3: Single-Point Update
**Update ONLY the canonical implementation:**

```tsx
// components/modals/FormModal.tsx
// ✅ Update here ONCE

export interface FormModalProps {
  // ... existing props
  isLoading?: boolean; // ✅ New prop added centrally
}
```

**DO NOT update individual consumers unless necessary.**

#### Step 4: Propagation Testing
**Test ALL affected pages:**

```bash
# Start dev server
npm run dev

# Test matrix (example for FormModal update):
# ☐ Partners page - Create/Edit modal
# ☐ Variables page - Create/Edit modal
# ☐ KYC page - Create/Edit modal
# ☐ Categories page - Create/Edit modal
# ... (all 12 pages)

# Verify:
# - Modal opens/closes correctly
# - Form submission works
# - Loading states display properly
# - Mobile responsiveness maintained
```

#### Step 5: Version & Document
**Update version and document changes:**

```
Version: 9.1.0 → 9.2.0 (MINOR - new prop)
Module: FormModal
Change: Added `isLoading` prop for async operations
Affected: 12 admin pages
Tested: All admin workflows verified
Released: 2025-11-01T16:00:00.000Z
```

### Module Security Implications

**Centralized modules = centralized security:**

**Vulnerabilities**:
- SQL/NoSQL injection in `formulaEngine.ts` affects ALL charts
- XSS in `FormModal.tsx` affects ALL admin forms
- CSRF bypass in `csrf.ts` affects ALL state-changing operations

**Mitigation Strategy**:
1. **Regular Audits**: Quarterly security review of top 20 modules
2. **Dependency Scanning**: `npm audit` + Snyk integration
3. **Input Sanitization**: Centralized in utility functions
4. **Output Encoding**: Enforced in shared components
5. **Version Pinning**: Lock critical dependencies

**Audit Schedule**:
- **Monthly**: Design tokens, core components (FormModal, ColoredCard)
- **Quarterly**: Utility functions, analytics engines
- **Annual**: Complete module inventory review

### Module Deprecation Protocol

**If a centralized module must be replaced:**

1. **Create Replacement**: New canonical implementation
2. **Deprecation Notice**: Add `@deprecated` JSDoc tag
3. **Migration Guide**: Document step-by-step migration
4. **Grace Period**: Minimum 2 versions (e.g., 9.1.0 → 9.3.0)
5. **Automated Migration**: Provide codemod script if possible
6. **Final Removal**: Delete after grace period + verification

**Example Deprecation:**
```tsx
/**
 * @deprecated Use FormModal from @/components/modals/FormModal instead.
 * This component will be removed in v10.0.0.
 * Migration guide: See MODAL_SYSTEM.md#migration
 */
export function LegacyModal() { ... }
```

---

## Project Overview

{messmass} is an enterprise-grade event analytics platform built with Next.js 15, TypeScript, and MongoDB Atlas, designed for sports organizations, venues, brands, and event managers. The platform provides comprehensive real-time statistics tracking, intelligent partner management, automated event creation workflows (Sports Match Builder), advanced Bitly link analytics with many-to-many event associations, parameterized KPI dashboards with marketing multipliers, Bitly enrichment charts, and a unified hashtag system with category-aware organization.

## Version History

- **Version 7.0.1** — 🚀 **DATABASE-FIRST VARIABLE SYSTEM**: Complete migration to MongoDB-driven variables with Single Reference System (`stats.` prefix)
- **Version 6.42.0** — Page Styles System: Complete custom theming engine with admin UI and live preview
- **Version 6.10.0** — Chart System Enhancement Phase B (Parameterization, Bitly Charts, Manual Tokens)
- **Version 6.9.2** — Real-Time Formula Validator in Admin Charts
- **Version 6.9.0** — Chart System P0 Hardening (production)
- **Version 6.8.0** — KYC creation flow and boolean/date types
- **Version 6.7.0** — KYC export and advanced filters (source/tags/flags)
- **Version 6.6.0** — KYC Variables page and Clicker Manager split
- **Version 6.5.0** — Analytics Insights: In-page Help and Usage Guide
- **Version 6.4.0** — Bitly Search UX Enhancement (Loading State Separation)
- **Version 6.0.0** — Partners Management System + Sports Match Builder + Comprehensive Documentation
- **Version 5.57.0** — PartnerSelector Component with Predictive Search
- **Version 5.56.0-5.56.3** — Partners CRUD System with Pagination and Search
- **Version 5.54.0-5.54.12** — Bitly Integration Enhancements (Many-to-Many, Notification Grouping)
- **Version 5.52.0** — Admin Variables & Metrics Management System
- **Version 5.49.3** — Admin Layout & Navigation System
- **Version 5.48.0** — Multi-User Notification System
- **Version 4.2.0** — Admin HERO Standardization and Content Surface
- **Version 2.2.0** — Hashtag Categories System ✅ **COMPLETED**

---

## Partners Management System (Version 6.0.0 / v10.7.0 Enhanced)

### Overview

The Partners Management System provides comprehensive infrastructure for managing organizational entities (clubs, federations, venues, brands) that participate in or host events. Partners serve as the foundation for rapid event creation via the Sports Match Builder and maintain associations with Bitly tracking links for attribution.

**Status**: Production-Ready (Fully migrated to UnifiedAdminPage system in v10.7.0)  
**Key Enhancement**: Partner report pages with shareable public URLs

### Key Features

- **Partner Database**: Comprehensive directory of organizations with metadata
- **Partner Profiles**: Emoji identifiers, hashtags, Bitly link associations
- **Searchable Directory**: Pagination, sorting, and predictive search
- **Reusable Components**: PartnerSelector with chip-based selection pattern
- **Event Integration**: Automatic hashtag and link inheritance in Sports Match Builder
- **Bitly Attribution**: Partners associated with tracking links for analytics

### Architecture Components

#### 1. Data Model

**Partners Collection** (`partners`)
```typescript
interface Partner {
  _id: ObjectId;
  name: string;                    // Partner name (e.g., "FC Barcelona")
  emoji: string;                   // Visual identifier (e.g., "⚽")
  viewSlug?: string;               // URL-safe slug for partner report pages (v10.7.0)
  hashtags?: string[];             // Traditional hashtags
  categorizedHashtags?: {          // Category-specific hashtags
    [categoryName: string]: string[];
  };
  bitlyLinkIds?: ObjectId[];       // Associated Bitly links (references to bitly_links)
  createdAt: Date;                 // ISO 8601 with milliseconds
  updatedAt: Date;                 // ISO 8601 with milliseconds
}
```

**Example Partner Document**:
```json
{
  "_id": ObjectId("..."),
  "name": "Ferencvárosi TC",
  "emoji": "⚽",
  "viewSlug": "fradi-ferencvarosi-tc-abc123",
  "hashtags": ["football", "greenwhite"],
  "categorizedHashtags": {
    "location": ["budapest", "hungary"],
    "sport": ["football"]
  },
  "bitlyLinkIds": [ObjectId("..."), ObjectId("...")],
  "createdAt": "2025-01-15T10:30:00.000Z",
  "updatedAt": "2025-01-20T14:22:00.000Z"
}
```

#### 2. API Endpoints

**Partner Management**
- `GET /api/partners` - List partners with pagination, search, and sorting
  - Query params:
    - `limit` (number, default 20)
    - `offset` (number, default 0)
    - `search` (string, searches name field)
    - `sortField` (name | createdAt | updatedAt)
    - `sortOrder` (asc | desc)
  - Response:
    ```json
    {
      "success": true,
      "partners": [...],
      "pagination": {
        "totalMatched": 150,
        "limit": 20,
        "offset": 0,
        "nextOffset": 20
      }
    }
    ```

- `POST /api/partners` - Create new partner
  - Body: `{ name, emoji, hashtags?, categorizedHashtags?, bitlyLinkIds? }`
  - Requires authentication
  - Returns created partner with `_id`

- `PUT /api/partners` - Update existing partner
  - Query param: `partnerId` (ObjectId)
  - Body: Partial partner data to update
  - Requires authentication
  - Updates `updatedAt` timestamp automatically

- `DELETE /api/partners` - Delete partner
  - Query param: `partnerId` (ObjectId)
  - Requires authentication
  - Returns `{ success: true, deletedCount: 1 }`

**Bitly Links Populated**: When fetching partners, Bitly links are populated from the `bitly_links` collection to provide full link details (bitlink, title, long_url) in the response.

#### 3. UI Components

**PartnerSelector Component** (`components/PartnerSelector.tsx`)
- **Pattern**: Chip-based selector with predictive search (follows ProjectSelector pattern)
- **Features**:
  - Predictive search filtering by partner name
  - Dropdown with emoji + name display
  - Transforms to chip when partner selected
  - Keyboard navigation (arrow keys, enter, escape)
  - Click-outside handling to close dropdown
  - Remove button (X) to clear selection
  - Full accessibility (ARIA labels, focus management)

**Usage Example**:
```typescript
import PartnerSelector from '@/components/PartnerSelector';

<PartnerSelector
  selectedPartnerId={partner1Id}
  partners={partners}
  onChange={(id) => setPartner1Id(id || '')}
  placeholder="Search home team..."
  disabled={loadingPartners}
/>
```

**Partner Admin Page** (`app/admin/partners/page.tsx`)
- **Layout**: AdminHero + table + modals (matches /admin/projects and /admin/bitly patterns)
- **Features**:
  - Searchable partner table with pagination (20 per page)
  - Sortable columns (name, created date)
  - Add/Edit modals with full CRUD operations
  - Hashtag integration via UnifiedHashtagInput
  - Bitly link association via BitlyLinksSelector
  - Delete confirmation with safety checks

**Design System Compliance**:
- Uses `AdminHero` for page header
- Modal patterns consistent with project/Bitly pages
- Table styling matches admin design system
- Chip-based components use success color scheme (green)
- All spacing and typography use design tokens (`--mm-*`)

**Unified Admin System Integration** (v10.7.0):
- Partners page fully migrated to UnifiedAdminPage component
- Reduced codebase from 1,431 lines (hardcoded HTML table) to 621 lines
- Uses `partnersAdapter` from `lib/adapters/partnersAdapter.tsx`
- Server-side search, sort, pagination (matches projects page pattern)
- Card/list view toggle with localStorage persistence
- All CRUD operations work through adapter handlers
- Report button available in both list and card views

#### 4. Sports Match Builder Integration

**Quick Add Page** (`app/admin/quick-add/page.tsx`)
- **Purpose**: Rapid event creation from partner selection
- **Features**:
  - Tabbed interface: "From Sheet" | "Sports Match"
  - Partner 1 (Home Team) selector
  - Partner 2 (Away Team) selector
  - Match date picker
  - Event preview with merged data
  - One-click event creation

**Event Generation Logic**:

1. **Event Name**: `{Partner1.emoji} {Partner1.name} x {Partner2.name}`
   - Example: "⚽ Ferencvárosi TC x Újpest FC"

2. **Hashtag Merging**:
   - Partner 1: ALL hashtags (traditional + categorized)
   - Partner 2: All hashtags EXCEPT location category
   - Deduplication: Remove duplicate hashtags across both partners
   - Result: Home team location + both teams' hashtags

3. **Bitly Link Inheritance**:
   - Only Partner 1 (Home Team) Bitly links are inherited
   - Rationale: Home team's tracking links used for event attribution

4. **Event Date**: User-selected date from date picker

**Example Preview**:
```json
{
  "eventName": "⚽ Ferencvárosi TC x Újpest FC",
  "eventDate": "2025-02-15",
  "hashtags": ["football", "greenwhite", "purple"],
  "categorizedHashtags": {
    "location": ["budapest"],
    "sport": ["football"]
  },
  "bitlyLinks": [ObjectId("...")]
}
```

#### 5. Partner Report Pages (v10.7.0)

**Purpose**: Shareable public reporting pages for partners showing profile and related events

**Route**: `/partner-report/[slug]/page.tsx`

**Features**:
- **Hero Block**: Partner emoji, name, logo, hashtags, timestamps (created/updated)
- **Export Actions**: CSV and PDF export buttons
- **Totals Summary**: Aggregate statistics across all partner events (total events, images, fans, attendees)
- **Related Events List**: 3-column card grid with event stats (images, fans, merch, attendees)
- **Password Protection**: Uses PagePasswordLogin component for access control
- **Responsive Design**: Desktop 3-column grid, mobile single column

**API Endpoint**:
- `GET /api/partners/report/[slug]` - Fetches partner by viewSlug with related events
  - Returns: Partner object + events array sorted by eventDate descending
  - Next.js 15 compatible (async params)
  - Authorization: Password-protected (same as project stats pages)

**viewSlug Auto-Generation** (v10.7.0):
- New partners automatically get `viewSlug` on creation (POST /api/partners)
- Existing partners get `viewSlug` on first edit/update (PUT /api/partners)
- Uses UUID-based slug generation (`generateUniqueViewSlug()` from `lib/slugUtils`)
- Checks uniqueness across all partner viewSlugs to avoid collisions
- Backward compatibility: Old partners created before feature will auto-populate on next edit

**Report Button Integration**:
- Available in partners page row actions (list view)
- Available in partners page card actions (card view)
- Opens `/partner-report/[viewSlug]` in new tab
- Shows alert if partner missing viewSlug (prompts user to edit and save)

**Example Report URL**: `https://messmass.app/partner-report/abc-123-partner-name`

**Files**:
- `app/partner-report/[slug]/page.tsx` (294 lines) - Report page component
- `app/styles/report-page.module.css` - Shared report page styles
- `app/api/partners/report/[slug]/route.ts` (88 lines) - Report API endpoint
- `lib/adapters/partnersAdapter.tsx` - Report button definition (lines 155-169, 239-250)

#### 6. Database Integration

**Collections Involved**:
- `partners` - Partner entities
- `projects` - Events created from partners
- `bitly_links` - Tracking links associated with partners
- `bitly_project_links` - Many-to-many junction for link-event associations

**Relationships**:
```
partners (1) ----< (N) bitlyLinkIds
partners (1) ----< (N) projects (via Sports Match Builder)
bitly_links (N) ----< (N) projects (via bitly_project_links junction)
```

### Benefits

1. **Rapid Event Creation**: Sports Match Builder reduces event creation time from minutes to seconds
2. **Data Consistency**: Partner profiles ensure consistent hashtags and naming across events
3. **Attribution**: Bitly link associations enable accurate traffic attribution to partners
4. **Scalability**: Partner directory grows with organization, reusable across all events
5. **Searchability**: Predictive search makes finding partners fast even with large directories
6. **Flexibility**: Partners support multiple types (clubs, federations, venues, brands)

### Performance Considerations

1. **Pagination**: 20 partners per page prevents overloading UI
2. **Search Optimization**: Case-insensitive regex search on indexed `name` field
3. **Lazy Loading**: Bitly links fetched only when needed (modal open)
4. **Cached Partners**: Partner list cached during Sports Match Builder session
5. **Indexed Fields**: MongoDB indexes on `name` and `createdAt` for fast queries

### Future Enhancements

- **Partner Types**: Add explicit type field (club, federation, venue, brand)
- **Partner Logos**: Upload and display partner logos
- **Partner Statistics**: Aggregate event stats per partner
- **Partner Relationships**: Parent-child relationships (federation > clubs)
- **Bulk Import**: CSV/Excel import for large partner datasets
- **Partner API Keys**: Allow partners to access their own event data

---

## Template System Architecture (v11.29.0)

### Overview

The Template System provides hierarchical report visualization management across the {messmass} platform. It enables customization of how data is displayed in event reports, partner reports, and global dashboards through a database-driven template and data block architecture.

### Key Features

- **Hierarchical Template Resolution**: Entity-specific → Partner → Default → Hardcoded fallback
- **Visual Block Management**: Drag-and-drop interface for organizing chart blocks
- **Responsive Grid System**: Configurable layouts for desktop, tablet, and mobile
- **Real-time Preview**: Live chart previews with sample data
- **Template Inheritance**: Partners and projects can inherit or override templates

### Architecture Components

#### 1. Template Resolution Hierarchy

**Resolution order varies by entity type:**

**For Event Reports (projects):**
```typescript
1. Project-Specific Template (project.reportTemplateId)
2. Partner Template via project.partner1 (partner.reportTemplateId)
3. Special Case: __default_event__ identifier forces default event template
4. Default Template (isDefault: true, ANY type - no type filter)
5. Hardcoded Fallback (emergency system template from lib/reportTemplateTypes.ts)
```

**For Partner Reports (partners):**
```typescript
1. Partner-Specific Template (partner.reportTemplateId)
2. Default Template (isDefault: true, ANY type - no type filter)
3. Hardcoded Fallback (emergency system template)
```

**Key Implementation Details:**
- Default template lookup does NOT filter by type (code: `findOne({ isDefault: true })`)
- Partner template resolution follows project.partner1 reference automatically
- Special `__default_event__` identifier used by partner report system for card layouts
- Hardcoded fallback defined in `HARDCODED_DEFAULT_TEMPLATE` constant
- All resolution handled by `/api/report-config/[identifier]?type=project|partner`

#### 2. Data Model

**Report Templates Collection** (`report_templates`)
```typescript
interface ReportTemplate {
  _id: ObjectId;
  name: string;
  type: 'event' | 'partner' | 'global';
  isDefault: boolean;
  dataBlocks: Array<{
    blockId: string;
    order: number;
  }>;
  gridSettings: {
    desktopUnits: number;
    tabletUnits: number;
    mobileUnits: number;
  };
  createdAt: Date;
  updatedAt: Date;
}
```

#### 3. API Endpoints

**Template Management**
- `GET /api/report-templates` - List all templates with optional associations
- `POST /api/report-templates` - Create new template
- `PUT /api/report-templates?templateId=X` - Update template configuration

**Template Resolution**
- `GET /api/report-config/{identifier}?type=partner` - Resolve template for partner reports
- `GET /api/report-config/{identifier}?type=project` - Resolve template for event reports

#### 4. UI Components

**Visualization Admin** (`app/admin/visualization/page.tsx`)
- Template selector with clear usage indicators
- Data block management interface
- Chart configuration and preview
- Real-time chart preview with sample data

### Recent Fixes & Troubleshooting (v11.29.0)

#### Template Dropdown Race Condition Fix

**Problem** (discovered 2025-12-16):
- Template dropdown in Visualization Admin loaded before authentication check completed
- Race condition caused "Forbidden" errors when accessing `/api/report-templates`
- dropdown showed "No templates found" despite templates existing in database

**Root Cause**:
```typescript
// Bad pattern - templates fetched immediately on mount
useEffect(() => {
  loadTemplates(); // Race: may run before auth complete
}, []);
```

**Solution**:
```typescript
// Good pattern - wait for authenticated user
useEffect(() => {
  if (user) {
    loadTemplates(); // Only fetch when auth confirmed
  }
}, [user]);
```

**Files Modified**:
- `app/admin/visualization/page.tsx` - Added user dependency to template loading
- Authentication state now gates all API calls

#### Partner Template Connection Fix

**Problem** (discovered 2025-12-15):
- Partner-level content (reportImage/reportText variables) not visible on partner reports
- Content uploaded via partner edit page disappeared when viewing `/partner-report/[slug]`
- Event cards within partner report used wrong template

**Root Cause**:
1. **Content Visibility**: Partner report page only checked project-specific content, ignored partner-level content
2. **Template Selection**: Event cards forced project template instead of respecting partner fallback
3. **API Query**: Missing partner ID filter when fetching content from projects

**Solution**:
```typescript
// 1. Fetch partner-owned content separately
const partnerContent = await db.collection('projects').findOne({
  partnerId: partner._id,  // Filter by partner owner
  'stats.reportImage1': { $exists: true }
});

// 2. Use special __default_event__ identifier for event cards
const cardTemplateResponse = await fetch(
  `/api/report-config/__default_event__?type=project`
);

// 3. Merge partner content with event content
const allContent = [...partnerContent, ...eventContent];
```

**Files Modified**:
- `app/partner-report/[slug]/page.tsx` - Added partner content fetching logic
- `app/api/report-config/[identifier]/route.ts` - Added `__default_event__` special case
- Partner reports now show both partner-level AND event-level content

#### TextChart Vertical Centering Fix

**Problem** (commit cb867f5):
- TEXT chart content not vertically centered in grid cells
- Different aspect ratios caused misalignment
- Chart looked "floated" to top of container

**Solution**:
```css
/* Added to TextChart component */
.textChartContainer {
  display: flex;
  align-items: center;     /* Vertical center */
  justify-content: center; /* Horizontal center */
  min-height: 100%;
  aspect-ratio: var(--chart-aspect-ratio); /* Respect template settings */
}
```

**Files Modified**:
- `components/charts/TextChart.tsx` - Added flex centering
- `components/charts/TextChart.module.css` - Updated layout styles

#### Report Image Variables Fix

**Problem** (commit 880e439):
- Chart configurations referenced wrong variable names for report images
- `reportImage` vs `reportImage1` naming inconsistency
- Broken image display in reports

**Solution**:
- Standardized ALL report variables to numbered format: `reportImage1`, `reportImage2`, ... `reportImage10`
- Updated chart configurations to match: `stats.reportImage3` (not `stats.reportImage`)
- Migrated existing data to new naming convention

**Files Modified**:
- `scripts/fix-report-image-variables.ts` - Database migration script
- Updated 30+ chart configurations in database
- `lib/variablesConfig.ts` - Variable naming registry

### Template System Best Practices

#### When to Create New Template vs Reuse

**Create New Template If**:
- Different grid layout needed (3-column vs 4-column)
- Different block order required
- Partner/client has unique branding requirements
- Specific chart combinations not available in existing templates

**Reuse Existing Template If**:
- Grid layout matches needs
- Block order is acceptable (can customize per-project)
- No special branding required
- Standard report structure works

#### Template Assignment Workflow

1. **Global Default**: Set one template as `isDefault: true` for new projects
2. **Partner Level**: Assign template to partner → all partner events inherit
3. **Project Override**: Assign template to specific project → overrides partner template
4. **Testing**: Use Builder Mode (`/edit/[slug]`) to preview template before publishing

#### Debugging Template Issues

**Template Not Loading:**
```bash
# Check API response
curl "http://localhost:3000/api/report-config/PROJECT_SLUG?type=project"

# Expected response:
{
  "success": true,
  "template": { ... },
  "resolvedFrom": "project" | "partner" | "default" | "hardcoded",
  "source": "template_name_or_entity"
}
```

**Chart Not Displaying:**
1. Verify chart exists: Check `/api/chart-config` for chartId
2. Check formula: Ensure variables exist in `stats` object
3. Validate data: Run formula evaluation with real project data
4. Check visibility: Ensure `isActive: true` on data block

**Partner Template Not Applying:**
1. Verify `partner.reportTemplateId` field exists in database
2. Check `project.partner1` references correct partner ObjectId
3. Test resolution: Query `/api/report-config/[projectSlug]?type=project`
4. Check logs: Server console shows resolution path

### Performance Considerations

**Template Loading**:
- Templates cached in memory after first load (<100ms subsequent loads)
- Data blocks populated via single database query
- Chart configurations loaded separately (lazy loaded)

**Report Rendering**:
- Builder Mode: <500ms for 10-20 blocks
- Public Stats Page: <800ms full render with all charts
- Partner Report: <1200ms (includes multiple event cards)

**Optimization Tips**:
1. Limit template to 20 blocks maximum (UX + performance)
2. Use derived variables instead of complex formulas
3. Enable chart result caching for expensive calculations
4. Lazy load images (use loading="lazy" attribute)

---

## Styling Architecture (4.2.0)

### Overview
- Introduced a design-managed content surface to unify the main content block across admin and public pages.
- Centralized theming via CSS variables to eliminate hard-coded per-page styles.
- Enforced board-level card width consistency: boards use equal-width columns (repeat(N, 1fr)); avoid per-card width overrides.

### CSS Variables
- `--page-bg`: Page background gradient/color (fallback: `var(--gradient-primary)`).
- `--header-bg`: Header/Hero surface background (fallback: `rgba(255, 255, 255, 0.95)`).
- `--content-bg`: Main content surface background (new in 4.2.0), controlled by Design Manager (pageStyle.contentBackgroundColor).

### Core Components
- `<ColoredCard>`: Card component with optional colored left accent border (see CARD_SYSTEM.md)
- `<AdminLayout>`: Admin page wrapper with Sidebar + TopHeader (see ADMIN_LAYOUT_SYSTEM.md)

### Design System
- All design tokens documented in [DESIGN_SYSTEM.md](docs/design/design-system.md)
- TailAdmin V2 flat design (no glass-morphism)
- **ALL CSS card classes REMOVED**: `.glass-card`, `.content-surface`, `.section-card`, `.admin-card`
- **ONLY USE**: `<ColoredCard>` component for all card UI
- Current components: `ColoredCard`, `AdminLayout`, `Sidebar`, `TopHeader`
- All card styling uses `<ColoredCard>` component ONLY (component-based architecture)
- Admin: `app/admin/layout.tsx` provides AdminLayout wrapper with sidebar navigation
- Public: `components/PagePasswordLogin.tsx` resolves page style via `/api/page-config`

## Configuration Loader (4.2.x)

### Admin Filter Search & Paging (v5.0.0)
- Hashtags API now supports server-side search + pagination for efficient selection in /admin/filter
- Endpoint: GET /api/hashtags
  - Query params: `search?`, `offset` (number), `limit` (default 20)
  - Response: `{ success, hashtags: Array<{hashtag:string,count:number}>, pagination: { mode: 'aggregation', limit, offset, nextOffset, totalMatched } }`
- Rationale: Reduce page load and improve operator workflow by fetching only visible hashtag pages; consistent with Admin → Projects pagination approach

### Overview
A centralized configuration module lives at `lib/config.ts`. It provides a single, typed source of truth for server and client configuration values and prevents hard-coded settings scattered across the codebase.

### Keys (minimum set)
- Server-only:
  - MONGODB_URI
  - MONGODB_DB
  - ADMIN_PASSWORD
  - SSO_BASE_URL
  - APP_BASE_URL
  - API_BASE_URL
- Client-exposed (browser):
  - NEXT_PUBLIC_APP_URL
  - NEXT_PUBLIC_WS_URL

### Resolution order and precedence
1) Environment variables (authoritative for secrets)
2) Optional Atlas “settings” overlay (non-secrets only, behind a feature flag)
- Precedence: env > DB (environment values always win when both exist)
- No baked defaults for secrets; required secrets must be present or fail fast

### Client/server boundary rules
- Only NEXT_PUBLIC_* keys are exposed to the client. All other keys are server-only.
- If a UI needs a value that isn’t prefixed NEXT_PUBLIC_*, inject it via server-rendered props or server APIs — do not access server-only keys on the client.

### Example usage patterns
Server (API route or server module):
```ts path=null start=null
import config from '@/lib/config';

// MongoDB connection
const uri = config.mongodbUri; // from MONGODB_URI
const dbName = config.dbName;  // from MONGODB_DB (defaulting strategy removed in Step 4)

// Service bases
const apiBase = process.env.API_BASE_URL; // or expose via config.get('API_BASE_URL') once helpers are added
```

Client (browser code):
```ts path=null start=null
// Only NEXT_PUBLIC_* keys are safe on the client
declare const process: { env: { NEXT_PUBLIC_APP_URL?: string; NEXT_PUBLIC_WS_URL?: string } };
const appUrl = process.env.NEXT_PUBLIC_APP_URL;
const wsUrl = process.env.NEXT_PUBLIC_WS_URL;
```

### Optional Atlas overlay (non-secrets only)
- Collection shape (proposed in Step 3): { project, env, key, value, updated_at, comment }
- Purpose: centralize non-sensitive toggles and base URLs; never secrets
- Caching: in-process TTL (e.g., 300000 ms) with manual bust method
- Reference: see LEARNINGS.md entry “2025-09-24T11:07:46.000Z — Atlas settings collection plan”

### Migration plan (Step 4)
- Replace direct `process.env.*` usages with the config module
- Remove baked defaults for secrets
- Remove hard-coded service base URLs (replace with APP_BASE_URL, API_BASE_URL, SSO_BASE_URL, NEXT_PUBLIC_APP_URL, NEXT_PUBLIC_WS_URL)

---

## Hashtag Categories System (Version 2.2.0)

### Overview

The hashtag categories system allows users to organize hashtags into categories and filter projects using both traditional hashtags and category-prefixed hashtags (e.g., "country:hungary", "period:summer"). This enables better organization and more precise filtering capabilities.

### Key Features

- **Category-Prefixed Hashtags**: Support for hashtags in the format "category:hashtag"
- **Dual Format Support**: Hashtags work both as plain hashtags and category-prefixed hashtags
- **Visual Category Indicators**: UI components display category colors and prefixes
- **Advanced Filtering**: Search supports both traditional and categorized hashtag filtering
- **Backward Compatibility**: Existing plain hashtags continue to work without changes

### Architecture Components

#### 1. Data Model

**Hashtag Categories Collection** (`hashtag_categories`)
```typescript
interface HashtagCategory {
  _id: ObjectId;
  name: string;        // Category name (e.g., "country", "period")
  color: string;       // Hex color code for visual distinction
  createdAt: Date;
  updatedAt: Date;
}
```

**Projects Collection Extension**
```typescript
interface Project {
  // ... existing fields
  hashtags: string[];  // Traditional hashtags
  categorizedHashtags: {
    [categoryName: string]: string[];  // Category-specific hashtags
  };
}
```

**Hashtags Collection Enhancement**
```typescript
interface HashtagDoc {
  _id: string;         // Hashtag text (e.g., "summer" or "period:summer")
  count: number;       // Usage count across all projects
  projects: ObjectId[]; // Projects using this hashtag
}
```

#### 2. Utility Functions (`lib/hashtagCategoryUtils.ts`)

**Core Functions:**

- `expandHashtagsWithCategories()`: Converts categorized hashtags to "category:hashtag" format
- `parseHashtagQuery()`: Parses "category:hashtag" into category and hashtag components
- `matchHashtagInProject()`: Checks if a hashtag exists in traditional or categorized fields

**Example Usage:**
```typescript
// Expand categorized hashtags for display
const expandedTags = expandHashtagsWithCategories(
  ["summer", "travel"], 
  { country: ["hungary"], period: ["summer"] }
);
// Returns: ["summer", "travel", "country:hungary", "period:summer"]

// Parse category-prefixed hashtag
const parsed = parseHashtagQuery("country:hungary");
// Returns: { category: "country", hashtag: "hungary" }
```

#### 3. API Endpoints

**Hashtag Categories Management**
- `GET /api/admin/hashtag-categories` - List all categories
- `POST /api/admin/hashtag-categories` - Create new category
- `PUT /api/admin/hashtag-categories/[id]` - Update category
- `DELETE /api/admin/hashtag-categories/[id]` - Delete category

**Enhanced Project APIs**
- `POST /api/projects` - Create project with categorized hashtags
- `PUT /api/projects/[id]` - Update project with categorized hashtags
- Both endpoints automatically store both plain and category-prefixed versions

**Enhanced Filtering API**
- `POST /api/hashtags/filter` - Filter projects by hashtags (admin)
- `GET /api/hashtags/filter-by-slug/[slug]` - Public filter endpoint supporting both filter slugs and direct hashtag queries
- `GET /api/hashtags/slugs` - Get available hashtags for filtering
- Supports mixed queries: `["summer", "country:hungary"]`
- Uses MongoDB `$or` queries to search both traditional and categorized hashtags
- **Note**: Individual hashtag statistics pages (`/hashtag/[hashtag]`) have been consolidated into the filter system

#### 4. UI Components

**ColoredHashtagBubble Component**
- Displays hashtags with category colors
- Shows category prefixes visually (e.g., "period:" in lighter text)
- Includes tooltips with full category context

**UnifiedHashtagInput Component**
- Enhanced to support category-prefixed hashtag input
- Visual distinction between plain and categorized hashtags
- Autocomplete supports both formats

**Project Forms**
- Category-specific hashtag input sections
- Proper loading and display of categorized hashtags during editing
- Validation to prevent hashtag duplication across categories

#### 5. Filtering Logic

The system supports sophisticated filtering with both traditional and categorized hashtags:

**Query Types:**
1. **Plain hashtag**: "summer" - searches in all categories + traditional hashtags
2. **Category-prefixed**: "period:summer" - searches only in specified category
3. **Mixed queries**: `["summer", "country:hungary"]` - combines both approaches

**MongoDB Query Structure:**
```javascript
{
  $and: [
    {
      $or: [
        { hashtags: { $in: ["summer"] } },
        { "categorizedHashtags.country": { $in: ["summer"] } },
        { "categorizedHashtags.period": { $in: ["summer"] } }
        // ... other categories
      ]
    },
    {
      $or: [
        { "categorizedHashtags.country": { $in: ["hungary"] } }
      ]
    }
  ]
}
```

### Implementation Details

#### Database Strategy

1. **Dual Storage**: Both plain and category-prefixed hashtags are stored in the hashtags collection for efficient filtering
2. **Backward Compatibility**: Existing projects continue to work with traditional hashtags
3. **Incremental Migration**: New projects automatically adopt the dual format

#### Performance Considerations

1. **Indexed Queries**: MongoDB indexes on both `hashtags` and `categorizedHashtags` fields
2. **Efficient Filtering**: Single query handles both traditional and categorized hashtag searches
3. **Client-Side Optimization**: Utility functions minimize redundant processing

#### UI/UX Design

1. **Visual Hierarchy**: Category prefixes are displayed in lighter/smaller text
2. **Color Coding**: Each category has a distinct color for easy identification
3. **Consistent Experience**: Same hashtag works in both traditional and categorized contexts

### Benefits

1. **Enhanced Organization**: Users can organize hashtags by meaningful categories
2. **Precise Filtering**: Category-prefixed searches provide exact matches
3. **Flexible Usage**: Same hashtag can exist in multiple categories without conflict
4. **Backward Compatibility**: No disruption to existing workflows
5. **Future-Proof**: Extensible architecture for additional categorization features

### Migration and Compatibility

- **Zero-Downtime Migration**: Existing projects continue working without changes
- **Gradual Adoption**: Users can adopt categorized hashtags at their own pace
- **Data Integrity**: Validation prevents duplicate hashtags within the same category
- **API Compatibility**: All existing API endpoints maintain backward compatibility

---

## URL Structure and Routing

### Public Pages
- `/stats/[slug]` - Individual project statistics (password protected)
- `/edit/[slug]` - Project editing interface (password protected)
- `/filter/[slug]` - Hashtag filtering and statistics (supports both filter slugs and direct hashtag names)
- `/hashtag/[hashtag]` - Aggregated statistics for a single hashtag (resurfaced; leverages the same style system)
- `/partner-report/[slug]` - **Partner report page (v10.7.0)** (password protected, shows profile + related events)

### Admin Pages
- `/admin` - Admin dashboard with navigation cards
- `/admin/projects` - **Project management (v10.1.0 - Unified)** (CRUD, card/list toggle, server-side search, CSV export, partner support)
- `/admin/partners` - **Partner management (v6.0.0)** (CRUD, pagination, search)
- `/admin/quick-add` - **Sports Match Builder + Sheet Import (v6.0.0)**
- `/admin/bitly` - Bitly link management and sync
- `/admin/hashtags` - Hashtag color management
- `/admin/categories` - **Hashtag category management (v9.3.0 - Unified)** (Card/list toggle, modal CRUD)
- `/admin/users` - **User management (v9.3.0 - Unified)** (Card/list toggle, modal CRUD)
- `/admin/filter` - Advanced hashtag filtering tool
- `/admin/variables` - Variable & metrics configuration
- `/admin/charts` - Chart configuration management
- `/admin/design` - UI design customization
- `/admin/visualization` - Data visualization settings

### API Endpoints

**Projects** (v10.1.0 - Enhanced Search)
- `GET /api/projects` - List projects with pagination, search, and sorting
  - Default mode: cursor pagination by updatedAt desc (nextCursor)
  - Sort/Search mode: offset pagination with totalMatched/nextOffset
  - Search: Searches eventName, viewSlug, editSlug, hashtags, categorizedHashtags
  - **Fixed v10.1.0**: MongoDB regex bug ($regex object + $options conflict)
  - sortField: eventName | eventDate | images | fans | attendees
  - sortOrder: asc | desc
  - Includes partner data population (partner1, partner2 with logos/emojis)
- `POST /api/projects` - Create new project
- `PUT /api/projects` - Update existing project
- `DELETE /api/projects` - Delete project

**Partners** (v6.0.0 / v10.7.0 Enhanced)
- `GET /api/partners` - List partners with pagination, search, and sorting
- `POST /api/partners` - Create new partner (auto-generates viewSlug in v10.7.0)
- `PUT /api/partners` - Update existing partner (auto-generates viewSlug if missing in v10.7.0)
- `DELETE /api/partners` - Delete partner
- `GET /api/partners/report/[slug]` - **Fetch partner report data (v10.7.0)** (by viewSlug, includes related events)

**Bitly Integration**
- `GET /api/bitly/links` - List Bitly links with pagination and search
- `POST /api/bitly/links` - Create or associate Bitly link
- `PUT /api/bitly/links` - Update Bitly link metadata
- `DELETE /api/bitly/links` - Delete Bitly link
- `POST /api/bitly/pull` - Bulk import links from Bitly account
- `POST /api/bitly/sync` - Sync analytics data for all links
- `POST /api/bitly/sync/[linkId]` - Sync analytics for specific link
- `GET /api/bitly/associations` - Get link-project associations
- `POST /api/bitly/associations` - Create link-project association
- `DELETE /api/bitly/associations` - Remove link-project association

**Hashtags & Filtering**
- `GET /api/hashtags` - List hashtags with counts (supports search + pagination)
- `POST /api/hashtags/filter` - Admin hashtag filtering
- `GET /api/hashtags/filter-by-slug/[slug]` - Public filtering (slugs or direct queries)
- `GET /api/hashtags/slugs` - Available hashtag listing
- `GET /api/hashtags/[hashtag]` - Aggregated stats for single hashtag

**Hashtag Categories**
- `GET /api/admin/hashtag-categories` - List categories
- `POST /api/admin/hashtag-categories` - Create category
- `PUT /api/admin/hashtag-categories/[id]` - Update category
- `DELETE /api/admin/hashtag-categories/[id]` - Delete category

**Variables & Metrics**
- `GET /api/variables-config` - Fetch all variables with flags and ordering
- `POST /api/variables-config` - Create/update variable metadata and flags
- `DELETE /api/variables-config` - Delete custom variable
- `GET /api/variables-groups` - Fetch variable groups
- `POST /api/variables-groups` - Create/update group or seed defaults
- `DELETE /api/variables-groups` - Delete all groups

**Notifications**
- `GET /api/notifications` - Fetch notifications for current user
- `POST /api/notifications` - Create notification (internal)
- `PUT /api/notifications/mark-read` - Mark as read or archive

**Configuration**
- `GET /api/page-config` - Page styling configuration
- `GET /api/chart-config` - Chart configuration
- `GET /api/hashtag-colors` - Hashtag color management

### URL Notes (v2.6.0 → v2.10.0)
- v2.6.0: Hashtag pages were deprecated in favor of the unified filter system
- v2.10.0: `/hashtag/[hashtag]` is available for single-hashtag aggregated stats (shares styling and components with filter/stats pages)
- Redirect behavior may exist for legacy routes, but the hashtag page is supported and styled

---

## 📊 Reporting System v12 Architecture (v11.37.0+)

**Last Updated: 2026-01-16T11:30:00.000Z
**Status:** Production (v12.0.0 migration in progress)  
**Technical Audit:** See `TECH_AUDIT_REPORTING_SYSTEM.md` for comprehensive analysis

### Overview

The Reporting System v12 represents a complete architectural migration to a unified, type-safe chart rendering system. The system provides dynamic report generation with formula-based calculations, responsive grid layouts, PDF export, and visual editing through Builder Mode.

**Key Capabilities:**
- **Dynamic Reports**: Formula-driven charts with real-time calculation
- **6 Chart Types**: KPI, PIE, BAR, TEXT, IMAGE, VALUE (composite)
- **Responsive Grid**: CSS Grid with aspect ratio preservation
- **PDF Export**: Smart pagination with hero repetition
- **Visual Editor**: Builder Mode for inline report editing
- **Template System**: Project → Partner → Default hierarchy

### Architecture Components

#### 1. Chart Rendering Pipeline

**Data Flow:**
```
Project Stats (MongoDB)
  ↓
ReportCalculator (lib/report-calculator.ts)
  ↓ Evaluates formulas using formulaEngine
  ↓ Returns ChartResult objects
ReportContent (app/report/[slug]/ReportContent.tsx)
  ↓ Layouts blocks with CSS Grid
  ↓ Manages responsive breakpoints
ReportChart (app/report/[slug]/ReportChart.tsx)
  ↓ Renders individual chart types
  ↓ Handles no-data states
Chart Type Components (components/charts/*)
  ↓ KPICard, PieChart, VerticalBarChart, etc.
  ↓ Final render with styling
```

#### 2. Core Components

**Primary Renderer:**
- **`app/report/[slug]/ReportChart.tsx`** - Unified v12 chart renderer (400 lines)
  - Supports all 6 chart types
  - Atomic component design
  - Type-safe props interface
  - No-data state handling

**Layout Management:**
- **`app/report/[slug]/ReportContent.tsx`** - Grid layout & block rendering (350 lines)
  - Responsive row system
  - Width measurement with ResizeObserver
  - Height calculation via blockHeightCalculator
  - Aspect ratio awareness

**Calculation Engine:**
- **`lib/report-calculator.ts`** - Formula evaluation orchestrator
  - Batch formula processing
  - Result caching
  - Error handling
  - Type conversion

**Formula Engine:**
- **`lib/formulaEngine.ts`** - Formula parsing & evaluation (735 lines)
  - Stats variable resolution
  - SEYU token support
  - PARAM token support (marketing multipliers)
  - MANUAL token support (aggregated data)
  - Arithmetic operations

#### 3. Chart Types System

| Type | Purpose | Elements | Grid Units | Component |
|------|---------|----------|------------|----------|
| **KPI** | Large metric display | 1 | 1 | components/charts/KPICard.tsx |
| **PIE** | Circular percentage | 2 | 2 | components/charts/PieChart.tsx |
| **BAR** | Horizontal bars | 5 | 3 | components/charts/VerticalBarChart.tsx |
| **TEXT** | Formatted text | 1 | 2 | components/charts/TextChart.tsx |
| **IMAGE** | Aspect ratio images | 1 | 1-3* | components/charts/ImageChart.tsx |
| **VALUE** | Composite (KPI+BAR) | Variable | 2 | Fragment with 2 grid items |

*IMAGE width determined by aspect ratio:
- **9:16** (Portrait) → 1 unit
- **1:1** (Square) → 2 units
- **16:9** (Landscape) → 3 units

**Aspect Ratio Utilities:**
- **`lib/aspectRatioUtils.ts`** - Centralized aspect ratio calculations (243 lines)
  - `calculateImageWidth()` - Grid unit conversion
  - `calculatePixelHeight()` - PDF export dimensions
  - `getAspectRatioConfig()` - Full configuration
  - 10 utility functions total

#### 4. Builder Mode (v11.10.0)

**Component:** `components/BuilderMode.tsx` (226 lines)

**Purpose:** Visual report template editor with inline inputs

**Architecture:**
```
BuilderMode
├── Template Fetching
│   ├── /api/report-config/[projectId]?type=project
│   └── Hierarchy: project → partner → default → hardcoded
├── Chart Configuration
│   ├── /api/chart-config/public
│   └── All chart definitions loaded
├── Chart Builders (Type-Specific)
│   ├── ChartBuilderKPI.tsx (92 lines) - 1 numeric input
│   ├── ChartBuilderBar.tsx (125 lines) - 5 inputs with colors
│   ├── ChartBuilderPie.tsx (163 lines) - 2 inputs with percentages
│   ├── ChartBuilderImage.tsx (57 lines) - Image uploader
│   └── ChartBuilderText.tsx (57 lines) - Textarea editor
└── Save Mechanism
    └── Parent EditorDashboard.saveProject()
```

**Features:**
- Auto-save on blur for all inputs
- Manual save button in header
- Loading states for template fetch
- Error recovery with fallbacks
- VALUE charts read-only (shows warning)

**Template Resolution:**
1. Project-level template (if assigned)
2. Partner-level template (if project has partner)
3. Default global template
4. Hardcoded fallback (empty state)

#### 5. Report Content Manager (v11.9.0)

**Component:** `components/ReportContentManager.tsx` (350 lines)

**Purpose:** Manage reportImageN and reportTextN slots (1-500)

**Features:**
- **Bulk Upload**: Multiple images → ImgBB → reportImageN slots
- **Auto-Generation**: Chart blocks created automatically via `/api/auto-generate-chart-block`
- **Slot Management**: Replace, clear, swap, compact operations
- **Usage Tracking**: Shows occupied slots

**Auto-Generation (v11.9.0 Innovation):**
```typescript
// WHAT: Automatically create chart algorithms when uploading content
// WHY: Streamline workflow - upload in Clicker → immediately available in Visualization
// HOW: API creates both chart_algorithms and data_blocks documents

// On image upload to reportImage3:
// 1. Stats updated: { reportImage3: "https://i.ibb.co/..." }
// 2. Chart created: chart_algorithms { chartId: "report-image-3", type: "image", formula: "stats.reportImage3" }
// 3. Block created: data_blocks { chartId: "report-image-3", width: 3, order: ... }
// Result: Image immediately appears in Visualization editor for drag-and-drop
```

**Slot Structure:**
- `reportImage1` through `reportImage500` - ImgBB URLs
- `reportText1` through `reportText500` - Text content
- All stored in `project.stats` (Single Reference System)

#### 6. PDF Export System

**Implementation:** `lib/export/pdf.ts` (456 lines)

**Strategy:**
- **html2canvas**: DOM to canvas conversion
- **jsPDF**: PDF generation with multi-page support
- **Smart Pagination**: Prevents chart splitting across pages
- **Hero Repetition**: Hero appears on every page

**Export Flow:**
```
1. Hide UI elements (badges, export buttons)
2. Capture hero separately
3. Find all blocks with data-pdf-block="true"
4. Set desktop width (1200px) for consistent capture
5. Capture each block as canvas
6. Calculate page layout (hero + available space)
7. Place blocks intelligently:
   - If block fits on current page → place it
   - If block doesn't fit → new page + hero + block
8. Generate PDF with all pages
9. Trigger browser download
```

**Image Handling (v9.3.0):**
- IMAGE charts use `background-image` CSS natively
- No runtime DOM manipulation needed
- Aspect ratios preserved automatically
- Legacy object-fit workaround kept for backward compatibility

**Performance:**
- 10 blocks: ~5-8 seconds
- 3-column desktop layout preserved
- Aspect ratio maintenance
- File size: ~2-5MB for typical report

#### 7. Chart Configuration System

**Collections:**
- **`chart_algorithms`** - Chart definitions (formulas, types, elements)
- **`data_blocks`** - Layout configuration (width, order, visibility)
- **`report_templates`** - Complete report structures

**Chart Algorithm Schema:**
```typescript
interface ChartAlgorithm {
  chartId: string;              // Unique identifier
  title: string;                // Display title
  subtitle?: string;            // Optional subtitle
  type: ChartType;              // kpi | pie | bar | text | image | value
  icon: string;                 // Material Icon name
  iconVariant?: IconVariant;    // outlined | filled | rounded
  order: number;                // Display order
  showTitle?: boolean;          // Show title in chart (default: true)
  aspectRatio?: AspectRatio;    // For IMAGE charts (16:9 | 9:16 | 1:1)
  elements: ChartElement[];     // Chart-specific data
  formatting?: FormattingOptions; // Prefix, suffix, decimals
}
```

**Report Template Schema:**
```typescript
interface ReportTemplate {
  _id: ObjectId;
  name: string;
  type: 'global' | 'partner' | 'project';
  assignedTo?: ObjectId;        // Partner or Project ID
  gridSettings: {
    desktopUnits: number;       // 3-4 columns typical
    tabletUnits: number;        // 2 columns typical
    mobileUnits: number;        // 1 column
  };
  dataBlocks: DataBlock[];      // Ordered list of blocks
  createdAt: string;
  updatedAt: string;
}
```

### Migration Status

#### v11.37.0 → v12.0.0 Transition

**Deprecated Components:**
- ❌ **`components/DynamicChart.tsx`** - Legacy renderer
  - Status: DEPRECATED (v11.37.0)
  - Removal: v12.0.0 (June 2025)
  - Remaining Usage: 2 files
  - Migration: See `DYNAMICCHART_MIGRATION_PLAN.md`

- ⚠️ **`components/UnifiedDataVisualization.tsx`** - Old visualization system
  - Status: DEPRECATED (line 2 marker)
  - Replacement: ReportChart + ReportContent

**Current Architecture (v12):**
- ✅ **`app/report/[slug]/ReportChart.tsx`** - Primary renderer
- ✅ **`app/report/[slug]/ReportContent.tsx`** - Layout manager
- ✅ All v12 reports use new system
- ✅ ESLint warns about DynamicChart imports

**Migration Effort:**
- 2 files to migrate (visualization page + UnifiedDataVisualization)
- Props mapping documented
- Testing checklist provided
- Timeline: 2 weeks (Phase 1 of technical audit)

### Performance Characteristics

**Rendering:**
- Report load time: <500ms (cached calculations)
- Builder mode load: ~1-2 seconds (template + chart config fetch)
- Chart rendering: <100ms per chart
- Grid layout: Instant (CSS Grid native)

**PDF Export:**
- 10 blocks: 5-8 seconds
- 20 blocks: 10-15 seconds
- Bottleneck: html2canvas capture
- Optimization: Desktop width cached, single capture per block

**Formula Evaluation:**
- Simple formula: <1ms
- Complex formula (5+ operations): <5ms
- Batch evaluation (20 charts): <100ms
- Caching: Results cached per render cycle

### Error Handling

**Chart Level:**
- Formula evaluation errors → "NA" display
- Missing data → No-data placeholder
- Invalid chart type → Error message in card

**Template Level:**
- Missing template → Fallback to default
- API failures → Error state with retry
- Invalid configuration → Validation warnings

**Export Level:**
- Canvas capture failure → Error alert with helpful message
- Missing blocks → Warning in console
- Large reports → Progress indicator

### Related Documentation

- **Technical Audit:** `TECH_AUDIT_REPORTING_SYSTEM.md` (982 lines)
- **Migration Plan:** `DYNAMICCHART_MIGRATION_PLAN.md` (253 lines)
- **User Guide:** `WARP.md` Chart System & Visualization section
- **Aspect Ratios:** `lib/aspectRatioUtils.ts` JSDoc comments
- **Coding Standards:** `CODING_STANDARDS.md` Component patterns

### Core vs Partner Resolution (2026-03-10)

Report template, style, and clicker set are resolved in a **project → partner → default** order. Partner-level assignment is supported; event-level overrides take precedence.

| Surface | Template | Style | Clicker set |
|---------|----------|-------|-------------|
| Event report | project → partner → default | project → partner → template | N/A (view) |
| Partner report | partner → default | partner → template | N/A (view) |
| Event edit | project → partner → default | project → partner → template | partner.clickerSetId → default |
| Partner edit | partner → default | partner.styleId | N/A (content only) |

**Implementation:** `/api/report-config/[identifier]` (project/partner type); style in same resolution; variable groups via `clickerSetId` from partner. **Audit and full classification:** [docs/2026-03-09_AUDIT_CORE_VS_PARTNER_FUNCTIONS.md](2026-03-09_AUDIT_CORE_VS_PARTNER_FUNCTIONS.md) (Sections 5A, 5B, 5C).

---

## Visualization Grid System (Stats/Admin Parity)

- Shared Component: components/UnifiedDataVisualization.tsx is the single source of truth for rendering blocks and charts across Admin Visualization, /stats, /filter, and /hashtag pages.
- Desktop Layout: Each chart defines its width in grid columns (1-N). Charts automatically wrap when their combined widths exceed the block's total available units.
- Tablet/Mobile Layout: Uses global tabletUnits and mobileUnits from page-config grid settings. Chart spans are clamped at each breakpoint to available units.
- CSS Grid System: Uses explicit `fr` units calculated from chart widths, with responsive wrapping via media queries.
- Aspect Ratio Handling: Image charts use CSS `aspect-ratio` property to maintain correct height within their allocated width.
- Data Flow: gridSettings are served by /api/page-config and passed to pages, then forwarded to UnifiedDataVisualization as gridUnits.
---

## Multi-User Notification System (Version 5.48.0+)

### Overview

The multi-user notification system tracks and displays project-related activities (creation, edits, statistics updates) to all users while maintaining independent read and archive states per user. This ensures team-wide visibility with personal notification management.

### Key Features

- **Multi-User Awareness**: All users see the same notifications
- **Independent State Management**: Each user can mark notifications as read or archived independently
- **Real-Time Updates**: Badge counts update automatically via polling
- **Activity Tracking**: Captures project creation, edits, and statistics updates
- **New Event Indicator**: Animated pulse on badge when new notifications arrive
- **Archive Functionality**: Users can hide notifications without affecting other users

### Architecture Components

#### 1. Data Model

**Notifications Collection** (`notifications`)
```typescript
interface Notification {
  _id: ObjectId;
  type: 'project-created' | 'project-edited' | 'stats-updated';
  message: string;          // Human-readable notification text
  projectId: string;        // Related project ID
  projectSlug: string;      // Project slug for linking
  eventName: string;        // Project event name
  userName?: string;        // User who triggered the action (optional)
  readBy: string[];         // Array of user IDs who marked as read
  archivedBy: string[];     // Array of user IDs who archived
  createdAt: string;        // ISO 8601 timestamp with milliseconds
}
```

#### 2. API Endpoints

**Notification Management**
- `GET /api/notifications` - Fetch notifications for current user
  - Filters out archived notifications for the current user
  - Returns unread count and notification list
  - Requires authentication
- `POST /api/notifications` - Create new notification (internal use)
  - Called automatically by project operations
  - Initializes with empty readBy and archivedBy arrays
- `PUT /api/notifications/mark-read` - Mark notification as read or archive
  - Query params: `notificationId`, `action` (read | archive)
  - Adds current user ID to appropriate array
  - Requires authentication

**Diagnostic Endpoint**
- `GET /api/debug/notifications` - Production troubleshooting
  - Shows authentication status
  - Displays notification counts and recent notifications
  - Provides troubleshooting guidance

#### 3. UI Components

**NotificationPanel Component** (`components/NotificationPanel.tsx`)
- Bell icon with badge count in top header
- Dropdown panel showing notification list
- Mark as read functionality (checkmark button)
- Archive functionality (X button)
- New event indicator (animated pulse)
- Links to related projects
- Empty state messaging

**Integration Points**
- Integrated into `TopHeader` component
- Polls every 30 seconds for updates
- Updates badge count automatically
- Handles authentication and error states

#### 4. Notification Triggers

Notifications are automatically created when:

1. **Project Creation** (`POST /api/projects`)
   - Type: `project-created`
   - Message: "📊 New project created: {eventName}"

2. **Project Edit** (`PUT /api/projects`)
   - Type: `project-edited`
   - Message: "✏️ Project updated: {eventName}"

3. **Statistics Update** (Real-time via WebSocket or API)
   - Type: `stats-updated`
   - Message: "📈 Statistics updated for: {eventName}"

### Implementation Details

#### Multi-User State Management

1. **Array-Based Tracking**: Uses `readBy` and `archivedBy` arrays containing user IDs
2. **Independent Actions**: Each user's actions only affect their own arrays
3. **Visibility Logic**: 
   - Notification visible if user ID NOT in `archivedBy`
   - Badge count includes notifications where user ID NOT in `readBy`

#### Performance Considerations

1. **Polling Strategy**: 30-second interval for badge updates (configurable)
2. **Efficient Queries**: MongoDB queries filter archived notifications server-side
3. **Index Recommendations**: Index on `createdAt` for sorting, compound index on `archivedBy` for filtering

#### Authentication Integration

1. **Session-Based**: Uses existing admin authentication system
2. **User ID Resolution**: Extracts user ID from session (email as identifier)
3. **Protection**: All endpoints require authentication via middleware

### Usage Examples

#### Fetching Notifications (Client)
```typescript
const response = await fetch('/api/notifications');
const data = await response.json();
// Returns: { success: true, notifications: [...], unreadCount: 5 }
```

#### Marking as Read
```typescript
await fetch(`/api/notifications/mark-read?notificationId=${id}&action=read`, {
  method: 'PUT'
});
```

#### Archiving Notification
```typescript
await fetch(`/api/notifications/mark-read?notificationId=${id}&action=archive`, {
  method: 'PUT'
});
```

### Benefits

1. **Team Coordination**: All users stay informed of project activities
2. **Personal Control**: Each user manages their own notification state
3. **Non-Intrusive**: Archive function removes clutter without deleting for others
4. **Audit Trail**: Complete history of project activities preserved
5. **Extensible**: Easy to add new notification types and triggers

### Future Enhancements

- **WebSocket Integration**: Real-time push notifications without polling
- **Notification Preferences**: User-configurable notification types
- **Digest Mode**: Daily/weekly notification summaries
- **Notification History**: Separate view for archived notifications
- **Rich Notifications**: Include change details and diffs
- **User Mentions**: @mention functionality in project notes

### Troubleshooting

For production issues:
1. Use diagnostic endpoint: `/api/debug/notifications`
2. Check authentication status
3. Verify MongoDB connection
4. Review notification counts and recent entries
5. See detailed troubleshooting guide in [MULTI_USER_NOTIFICATIONS.md](docs/features/features-multi-user-notifications.md)

---

## Unified Admin System (Version 9.3.0+ / v10.1.0 Enhanced)

### Overview

The Unified Admin System provides a consistent, reusable architecture for admin pages with card/list toggle, server-side search, modal CRUD operations, and responsive design. It eliminates code duplication across admin pages while maintaining flexibility for page-specific features.

**Status**: Production-Ready  
**Migrated Pages**: Categories (v9.3.0), Users (v9.3.0), Projects (v10.1.0)  
**Key Achievement**: Server-side search with zero client-side filtering

### Core Components

#### 1. UnifiedAdminPage (`components/UnifiedAdminPage.tsx`)
**Role**: Master wrapper orchestrating hero, search, view toggle, and data display  
**Features**:
- Auto-detects client-side vs server-side search mode
- Manages view mode persistence (localStorage)
- Handles search debouncing (300ms)
- Renders UnifiedListView or UnifiedCardView based on toggle

**Props**:
```typescript
interface UnifiedAdminPageProps<T> {
  adapter: AdminPageAdapter<T>;           // Page-specific configuration
  items: T[];                             // Data to display
  isLoading?: boolean;                    // Loading state
  title: string;                          // Page title
  subtitle?: string;                      // Optional subtitle
  backLink?: string;                      // Optional back button
  actionButtons?: ActionButton[];         // Header action buttons
  enableSearch?: boolean;                 // Client-side search (default: true)
  enableSort?: boolean;                   // Client-side sort (default: true)
  externalSearchValue?: string;           // Server-side search value
  onExternalSearchChange?: (v: string) => void; // Server-side search handler
  searchPlaceholder?: string;             // Search input placeholder
  totalMatched?: number;                  // Total count for pagination stats
  showPaginationStats?: boolean;          // Show "X of Y items"
}
```

**Search Mode Detection**:
```typescript
const isServerSideSearch = externalSearchValue !== undefined && onExternalSearchChange !== undefined;
// If server-side: skip internal debouncing, pass search through immediately
// If client-side: apply debouncing and filter items locally
```

#### 2. Adapters (`lib/adapters/*.tsx`)
**Role**: Page-specific configuration defining list/card structure and actions  
**Pattern**: Single adapter per admin page

**Example** (`lib/adapters/projectsAdapter.tsx`):
```typescript
export const projectsAdapter: AdminPageAdapter<ProjectDTO> = {
  pageName: 'projects',
  defaultView: 'list',
  listConfig: {
    columns: [ /* column definitions */ ],
    rowActions: [ /* CSV, View Stats, Edit, Delete */ ]
  },
  cardConfig: {
    primaryField: 'eventName',
    secondaryField: (project) => new Date(project.eventDate).toLocaleDateString(),
    metaFields: [ /* images, fans, merch, attendees */ ],
    cardActions: [ /* CSV, Edit */ ]
  },
  searchFields: ['eventName', 'hashtags', 'categorizedHashtags'],
  emptyStateMessage: 'No projects found.',
  emptyStateIcon: '🍿'
};
```

#### 3. UnifiedListView (`components/UnifiedListView.tsx`)
**Role**: Table-based data display with sortable columns  
**Features**:
- Responsive table layout
- Sortable columns (visual indicators)
- Action buttons per row
- Empty state handling

#### 4. UnifiedCardView (`components/UnifiedCardView.tsx`)
**Role**: Grid-based card display  
**Features**:
- Responsive grid (1-4 columns based on screen size)
- Colored accent borders
- Meta fields with icons
- Action buttons per card

#### 5. UnifiedAdminHeroWithSearch (`components/UnifiedAdminHeroWithSearch.tsx`)
**Role**: Header with title, search, view toggle, action buttons  
**Features**:
- Integrated search input
- Card/list view toggle
- Primary action button ("Add New")
- Optional back button

### Server-Side Search Pattern (v10.1.0)

**Problem**: Projects page needed database search, not client-side filtering

**Solution**:
1. Parent component manages search state with `useDebouncedValue(searchQuery, 300)`
2. Parent passes debounced value to UnifiedAdminPage via `externalSearchValue`
3. UnifiedAdminPage detects server mode, skips internal debouncing
4. Parent's useEffect triggers API call when debounced value changes
5. API returns filtered results, parent updates items

**Code Pattern**:
```typescript
const [searchQuery, setSearchQuery] = useState('');
const debouncedSearchQuery = useDebouncedValue(searchQuery, 300);

useEffect(() => {
  if (user) {
    loadProjects(true); // Fetch with debouncedSearchQuery
  }
}, [debouncedSearchQuery, sortField, sortOrder, user]);

return (
  <UnifiedAdminPage
    adapter={projectsAdapter}
    items={projects}
    enableSearch={true}
    externalSearchValue={searchQuery}
    onExternalSearchChange={setSearchQuery}
    showPaginationStats={true}
    totalMatched={totalMatched}
  />
);
```

### Key Learnings

**1. Conflicting useEffects Are Silent Killers**
- Problem: Initial load effect depended on `[user, loadProjects]`, search effect on `[debouncedSearchQuery]`
- When search changed, `loadProjects` recreated, initial load fired again
- Solution: Initial load only depends on `[user]`, search effect owns all data loading

**2. Double Debouncing = Broken Search**
- Problem: Parent debounced (300ms) + UnifiedAdminPage debounced (300ms) = 600ms + search never fired
- Solution: Server-side mode skips component debouncing

**3. MongoDB Regex: Object vs String**
```typescript
// ❌ WRONG: Can't mix RegExp object + $options
{ $regex: new RegExp(query, 'i'), $options: 'i' }

// ✅ CORRECT: RegExp already has flags
{ $regex: new RegExp(query, 'i') }
```

### Migration Status

| Page | Status | Version | Features |
|------|--------|---------|----------|
| Categories | ✅ Migrated | v9.3.0 | Card/list, modal CRUD, client search |
| Users | ✅ Migrated | v9.3.0 | Card/list, modal CRUD, client search |
| Projects | ✅ Migrated | v10.1.0 | Card/list, modal CRUD, **server search**, partner logos, CSV export |
| Partners | ✅ Migrated | v10.7.0 | Card/list, modal CRUD, **server search**, Report button, 810 lines removed |
| Hashtags | 🔄 Pending | - | Custom implementation (to be migrated) |

### Files

**Core Components**:
- `components/UnifiedAdminPage.tsx` - Master wrapper
- `components/UnifiedAdminHeroWithSearch.tsx` - Header with search
- `components/UnifiedListView.tsx` - Table view
- `components/UnifiedCardView.tsx` - Grid view
- `components/UnifiedAdminViewToggle.tsx` - Card/list switcher

**Adapters**:
- `lib/adapters/categoriesAdapter.tsx`
- `lib/adapters/usersAdapter.tsx`
- `lib/adapters/projectsAdapter.tsx`
- `lib/adapters/partnersAdapter.tsx` - **Added v10.7.0** (includes Report button)
- `lib/adapters/index.ts` - Central exports

**Types**:
- `lib/adminDataAdapters.ts` - Adapter type definitions
- `lib/adminViewState.ts` - View persistence
- `lib/types/api.ts` - DTO interfaces

### Performance

- **Search**: <200ms response (MongoDB aggregation pipeline)
- **View Toggle**: <50ms (localStorage read/write)
- **Pagination**: Cursor-based (default) or offset-based (search/sort)
- **Debouncing**: 300ms to reduce API calls

---

## Admin Layout & Navigation System (Version 5.49.3+)

### Overview

The Admin Layout & Navigation System provides a comprehensive, responsive layout framework for all {messmass} admin pages. It features a collapsible sidebar navigation, top header with user info and notifications, and adaptive behavior across desktop, tablet, and mobile devices.

**Status**: Stable, Production-Ready  
**Documentation**: See [ADMIN_LAYOUT_SYSTEM (archived)](archive/_archive/deprecated-guides-2025/archive-legacy-guides-pack.md#legacy-admin_layout_system) for complete documentation  
**Code Review (Archived)**: See [admin-layout-code-review-findings-2026-02-05.md](archive/_archive/admin/admin-layout-code-review-findings-2026-02-05.md)

### Key Components

#### 1. SidebarContext (`contexts/SidebarContext.tsx`)
- **Role**: Centralized state management for sidebar behavior
- **State**: `isCollapsed` (desktop/tablet) and `isMobileOpen` (mobile overlay)
- **SSR-Safe**: Pure React state, no localStorage (avoids hydration mismatches)
- **Integration**: Provider wraps entire admin layout in `app/admin/layout.tsx`

#### 2. Sidebar (`components/Sidebar.tsx`)
- **Role**: Navigation menu with responsive behavior
- **Navigation Sections**: Content, Configuration, Settings, Help
- **Active Detection**: Uses `usePathname()` with `startsWith()` logic
- **Accessibility**: `role="navigation"`, ARIA attributes, keyboard navigation
- **Mobile**: Hamburger toggle, backdrop click/Escape to close, body scroll lock

#### 3. AdminLayout (`components/AdminLayout.tsx`)
- **Role**: Layout wrapper providing structure for all admin pages
- **Composition**: Fixed sidebar + main wrapper (header + content)
- **Dynamic Margins**: Content margin adjusts based on sidebar state
- **Max-width**: Content limited to 1600px for readability

#### 4. TopHeader (`components/TopHeader.tsx`)
- **Role**: Top navigation bar with user info, notifications, and logout
- **Features**: Welcome message, notification bell (integrated with NotificationPanel), user avatar, logout button
- **Policy**: No breadcrumbs (per WARP.md policy)
- **Integration**: Notification system uses 30-second polling

### Component Relationships & Data Flow

```
app/admin/layout.tsx (Server Component)
  ├─> Fetches admin user + style settings
  └─> SidebarProvider (Context)
      └─> AdminLayout (Client Component)
          ├─> Sidebar (consumes SidebarContext)
          └─> mainWrapper
              ├─> TopHeader (user, notifications)
              └─> main content (children pages)
```

### Responsive Behavior

| Breakpoint | Sidebar Width | Behavior | State Variable |
|------------|---------------|----------|----------------|
| Desktop (≥1280px) | 280px expanded / 80px collapsed | User toggles with button | `isCollapsed` |
| Tablet (768-1279px) | 80px (auto-collapsed rail) | Icons only, labels hidden | `isCollapsed` (CSS) |
| Mobile (<768px) | Overlay (off-canvas) | Hamburger menu opens drawer | `isMobileOpen` |

**Main Content Margins**:
- Desktop expanded: `margin-left: 280px`
- Desktop/tablet collapsed: `margin-left: 80px`
- Mobile: `margin-left: 0` (sidebar is overlay)

### Design System Integration

**CSS Modules**: All components use scoped CSS Modules  
**Theme Tokens**: Leverages `app/styles/theme.css` for colors, spacing, typography  
**Tokens Used**: `--mm-space-*`, `--mm-gray-*`, `--mm-color-primary-*`, `--mm-shadow-*`, `--z-*`

**Tech Debt** (documented in CODE_REVIEW_FINDINGS):
- Hard-coded widths (280px, 80px) should be tokenized
- Hard-coded breakpoints (768px, 1280px) should be tokenized
- Missing tooltips on collapsed sidebar icons
- Missing skip-to-content link (WCAG 2.4.1)

### Accessibility

**Compliance**: WCAG 2.1 Level AA Compliant
- ✅ Keyboard navigation (Tab, Enter, Escape)
- ✅ ARIA attributes (`role`, `aria-label`, `aria-expanded`, `aria-controls`)
- ✅ Color contrast meets 4.5:1 minimum
- ✅ Touch targets ≥44x44px
- ✅ Focus-visible styles

### Usage Pattern

All admin pages automatically inherit the layout via `app/admin/layout.tsx`. No explicit imports required:

```tsx
// app/admin/my-feature/page.tsx
export default function MyFeaturePage() {
  return (
    <div>
      <h1>My Feature</h1>
      {/* Sidebar, header, and layout applied automatically */}
    </div>
  );
}
```

To access sidebar state in child components:
```typescript
import { useSidebar } from '@/contexts/SidebarContext';
const { isCollapsed, setIsCollapsed } = useSidebar();
```

### Performance

- ✅ Zero unnecessary re-renders
- ✅ Static navigation data (no fetch required)
- ✅ Optimized conditional rendering
- ✅ CSS Modules tree-shakable
- ✅ No heavy dependencies

### Future Enhancements

See ROADMAP.md for planned improvements:
1. Tokenize sidebar widths and breakpoints (High priority)
2. Add tooltips for collapsed sidebar (Medium priority)
3. Add skip-to-content link (Medium priority)
4. Persist sidebar state with localStorage (Low priority)
5. Implement focus trap in mobile overlay (Low priority)

For complete documentation, usage examples, troubleshooting, and technical details, see [ADMIN_LAYOUT_SYSTEM (archived)](archive/_archive/deprecated-guides-2025/archive-legacy-guides-pack.md#legacy-admin_layout_system).

---

## Page Styles System — Custom Theming Engine (Version 6.42.0)

### Overview

The Page Styles System is a complete custom theming engine that allows administrators to create, manage, and apply visual themes to projects dynamically. It provides full control over backgrounds (solid/gradient), typography, and color schemes for public project pages, enabling white-label deployments, per-client branding, and dark mode support.

**Status**: Production-Ready  
**Documentation**: Complete implementation with 5 default themes included  
**Complexity**: 2,887 lines of production code across 11 files

### Key Features

- **Visual Theme Editor**: Tabbed modal interface with live preview
- **Background Customization**: Solid colors or CSS gradients for page, hero, and content boxes
- **Typography Control**: Font family, size, color, and weight configuration
- **Color Schemes**: Primary, secondary, accent, success, warning, error palettes
- **Global Default Theme**: System-wide fallback when no project-specific style assigned
- **Project Assignment**: Many-to-many relationship (one style → multiple projects)
- **Dynamic CSS Injection**: Client-side style application without page reload
- **5 Professional Themes**: Clean Light, Dark Mode, Sports Blue, Vibrant Gradient, Minimal Gray

### Architecture Components

#### 1. Data Model

**Page Styles Collection** (`page_styles_enhanced`)
```typescript
interface PageStyleEnhanced {
  _id: ObjectId;
  name: string;                          // Style name (e.g., "Dark Mode")
  description?: string;                  // Optional description
  isGlobalDefault: boolean;              // Only one can be true
  pageBackground: BackgroundStyle;       // Page-level background
  heroBackground: BackgroundStyle;       // Hero section background
  contentBoxBackground: ContentBoxBackground; // Content boxes
  typography: Typography;                // Font settings
  colorScheme: ColorScheme;              // Color palette
  createdAt: Date;                       // ISO 8601 with milliseconds
  updatedAt: Date;                       // ISO 8601 with milliseconds
  createdBy?: string;                    // Admin user email
  projectIds?: string[];                 // Assigned project ObjectIds
}

interface BackgroundStyle {
  type: 'solid' | 'gradient';
  color?: string;                        // Hex color for solid
  gradient?: string;                     // CSS gradient for gradient type
}

interface ContentBoxBackground {
  backgroundColor: string;
  borderColor?: string;
  borderWidth?: string;
  borderRadius?: string;
}

interface Typography {
  fontFamily: string;                    // 'Inter' | 'Roboto' | 'Poppins'
  fontSize: string;
  headingColor: string;
  textColor: string;
  fontWeight?: string;
}

interface ColorScheme {
  primary: string;
  secondary: string;
  accent: string;
  success: string;
  warning: string;
  error: string;
}
```

**MongoDB Indexes**:
1. `{ name: 1 }` - Unique index for style names
2. `{ isGlobalDefault: 1 }` - Fast lookup for global default
3. `{ projectIds: 1 }` - Efficient project-to-style queries

**Example Style Document**:
```json
{
  "_id": ObjectId("..."),
  "name": "Dark Mode",
  "description": "Modern dark theme with vibrant accents",
  "isGlobalDefault": false,
  "pageBackground": {
    "type": "solid",
    "color": "#1a1a1a"
  },
  "heroBackground": {
    "type": "gradient",
    "gradient": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
  },
  "contentBoxBackground": {
    "backgroundColor": "#2a2a2a",
    "borderColor": "#3a3a3a",
    "borderWidth": "1px",
    "borderRadius": "8px"
  },
  "typography": {
    "fontFamily": "Inter",
    "fontSize": "16px",
    "headingColor": "#ffffff",
    "textColor": "#e0e0e0",
    "fontWeight": "400"
  },
  "colorScheme": {
    "primary": "#667eea",
    "secondary": "#764ba2",
    "accent": "#f093fb",
    "success": "#4ade80",
    "warning": "#fbbf24",
    "error": "#f87171"
  },
  "createdAt": "2025-01-22T19:00:00.000Z",
  "updatedAt": "2025-01-22T19:00:00.000Z",
  "projectIds": ["65a1b2c3d4e5f6789abc0001", "65a1b2c3d4e5f6789abc0002"]
}
```

#### 2. API Endpoints

**Style Management**
- `GET /api/page-styles-enhanced` - List all styles (admin auth required)
  - Response: `{ success: true, styles: [...] }`
  
- `POST /api/page-styles-enhanced` - Create new style
  - Body: Complete `PageStyleEnhanced` object (without `_id`)
  - Validation: Name uniqueness, only one global default
  - Returns: Created style with `_id`
  
- `PUT /api/page-styles-enhanced?styleId=X` - Update existing style
  - Body: Partial `PageStyleEnhanced` object
  - Updates `updatedAt` timestamp automatically
  - Prevents duplicate global defaults
  
- `DELETE /api/page-styles-enhanced?styleId=X` - Delete style
  - Removes style from all assigned projects
  - Returns: `{ success: true, deletedCount: 1 }`
  
**Migration Note** (v6.44.0):
- **Database Field**: Projects use `styleIdEnhanced` field (migrated from deprecated `styleId`)
- **API Parameter**: Endpoints still accept `styleId` param for backward compatibility
- **Internal Conversion**: Backend converts `styleId` → `styleIdEnhanced` before database operations

**Global Default Management**
- `POST /api/page-styles-enhanced/set-global` - Set style as global default
  - Body: `{ styleId: ObjectId }`
  - Atomically unsets previous global default
  - Only one global default allowed at any time

**Project Assignment**
- `POST /api/page-styles-enhanced/assign-project` - Assign style to project
  - Body: `{ styleId: ObjectId, projectId: ObjectId }`
  - Bidirectional linking: Updates both collections
  - Updates: `style.projectIds[]` and `project.styleIdEnhanced` (database field name)
  
- `DELETE /api/page-styles-enhanced/assign-project` - Remove assignment
  - Body: `{ styleId: ObjectId, projectId: ObjectId }`
  - Cleans up both collections

**Public Endpoint**
- `GET /api/page-style?projectId=X` - Fetch style for public page (no auth)
  - Logic: `project.styleIdEnhanced` → global default → hardcoded fallback
  - Returns: Complete `PageStyleEnhanced` object
  - Performance: <200ms response time
  - **Note**: Uses `styleIdEnhanced` field from projects collection

#### 3. Admin UI Components

**Page Styles Tab** (`/admin/design` 6th tab)
- **Layout**: Grid of style cards with Add button
- **Cards Display**: Style name, description, preview swatches, action buttons
- **Actions per Card**:
  - Edit: Opens PageStyleEditor modal
  - Delete: Confirmation dialog with safety check (removes project assignments)
  - Set as Global Default: Button to designate system-wide default

**PageStyleEditor Component** (`components/PageStyleEditor.tsx`, 556 lines)
- **Pattern**: Modal overlay with split-screen layout (1400px width)
- **Layout**: Form (left) + Live Preview (right) on desktop; stacks on mobile
- **Sections** (4 tabs):
  1. **General**: Name, description, global default checkbox
  2. **Backgrounds**: Page, hero, content box (solid/gradient toggle)
  3. **Typography**: Font family, size, colors, weight
  4. **Colors**: Primary, secondary, accent, success, warning, error
- **Features**:
  - Native HTML5 color pickers with hex text inputs
  - Background type toggle (solid ↔ gradient)
  - Form validation (name required, colors hex format)
  - Live preview updates on every change
  - Save/Cancel actions

**StylePreview Component** (`components/StylePreview.tsx`, 187 lines)
- **Purpose**: Real-time visual feedback while editing
- **Content**: Mini page mockup with hero section, content boxes, text samples
- **Updates**: Instant (<50ms) when form changes
- **Rendering**: Applies all style properties to preview elements
- **Elements Shown**: Hero header, body text, buttons, cards, color swatches

**Design System Integration**:
- Uses CSS Modules for scoped styling
- Modal follows admin panel patterns (consistent with Projects, Bitly pages)
- Color pickers use native `<input type="color">` for OS integration
- Responsive breakpoints: Desktop (≥1024px), Tablet (≥768px), Mobile (<768px)

#### 4. Style Application System

**usePageStyle Hook** (`hooks/usePageStyle.ts`, 170 lines)
- **Purpose**: Fetch and apply page style dynamically on public pages
- **Usage**: 
  ```typescript
  // In app/stats/[slug]/page.tsx
  usePageStyle({ projectId: slug });
  ```
- **Flow**:
  1. Fetches style via `/api/page-style?projectId=X`
  2. Generates CSS from style object
  3. Injects `<style id="page-style-enhanced">` into document head
  4. Cleans up on component unmount
- **CSS Targets**:
  - `body` - Page background
  - `.stats-hero` - Hero section background
  - `.stats-content-box` - Content boxes styling
  - `h1, h2, h3, h4, h5, h6` - Typography
  - `.primary`, `.secondary`, `.accent`, `.success`, `.warning`, `.error` - Semantic color classes
- **Performance**: CSS injection <10ms, style fetch <200ms

**CSS Generation Strategy**:
- Converts JSON style object to CSS rules
- Supports both solid colors and gradients
- Applies typography with fallback fonts
- Injects semantic color CSS variables
- Handles border, border-radius, shadows

#### 5. Default Themes (Seed Script)

**Script**: `scripts/seedPageStyles.ts` (260 lines)  
**Command**: `npm run seed:page-styles`

**Included Themes**:

1. **Clean Light** (Global Default)
   - Page: White (#ffffff)
   - Hero: Subtle gradient (blue to indigo)
   - Content: Light gray boxes
   - Font: Inter, 16px
   - Use case: Professional, corporate events

2. **Dark Mode**
   - Page: Dark gray (#1a1a1a)
   - Hero: Vibrant purple gradient
   - Content: Charcoal boxes with accent borders
   - Font: Inter, 16px
   - Use case: Night events, esports

3. **Sports Blue**
   - Page: Light blue gradient
   - Hero: Bold blue-to-cyan gradient
   - Content: White boxes with blue borders
   - Font: Poppins, 16px
   - Use case: Sports teams, stadiums

4. **Vibrant Gradient**
   - Page: Yellow-to-pink gradient
   - Hero: Neon gradient (pink-orange-yellow)
   - Content: White boxes, strong shadows
   - Font: Poppins, 17px
   - Use case: Festivals, youth events

5. **Minimal Gray**
   - Page: Pure white
   - Hero: Grayscale gradient
   - Content: Light gray boxes, minimal borders
   - Font: Roboto, 15px
   - Use case: Minimalist brands, art galleries

**Seeding Process**:
1. Checks if styles already exist (by name)
2. Inserts only missing themes
3. Sets "Clean Light" as global default
4. Logs created styles with `_id`
5. Safe to run multiple times (idempotent)

### Integration Guide

#### Step 1: Seed Default Themes (One-time)
```bash
npm run seed:page-styles
```

#### Step 2: Manage Themes in Admin UI
1. Navigate to `/admin/design`
2. Click "Page Styles" tab
3. Create/edit/delete themes as needed
4. Set global default theme

#### Step 3: Assign Theme to Project

**Via API**:
```typescript
await fetch('/api/page-styles-enhanced/assign-project', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    styleId: '65a1b2c3d4e5f6789abc0000',
    projectId: '65a1b2c3d4e5f6789abc0001'
  })
});
```

**Via Admin UI** (future enhancement):
- Project edit modal will include style dropdown selector

#### Step 4: Apply Styles to Public Pages

**Add one line to stats pages**:
```typescript
// app/stats/[slug]/page.tsx
import { usePageStyle } from '@/hooks/usePageStyle';

export default function StatsPage({ params }: { params: { slug: string } }) {
  usePageStyle({ projectId: params.slug }); // Add this line
  
  // Rest of component code...
}
```

**Result**: Page automatically loads project-specific style or global default

### Style Resolution Logic

```
1. Fetch project by ID
2. If project.styleIdEnhanced exists:
   → Load that specific style
3. Else:
   → Load style where isGlobalDefault === true
4. Else:
   → Use hardcoded system default (Clean Light equivalent)
```

**Fallback Hierarchy**: Project Style → Global Default → System Hardcoded

### Performance Characteristics

- **Admin UI Load**: <100ms (style list fetch + render)
- **Modal Open**: <50ms (no API call, form initialization)
- **Live Preview**: <50ms per change (instant React re-render)
- **Style Fetch (Public)**: <200ms (MongoDB query + response)
- **CSS Injection**: <10ms (DOM manipulation)
- **Total Public Page Load Impact**: <210ms added latency

### File Structure

```
messmass/
├── components/
│   ├── PageStyleEditor.tsx              (556 lines) - Modal form
│   ├── PageStyleEditor.module.css       (389 lines) - Modal styles
│   ├── StylePreview.tsx                 (187 lines) - Live preview
│   └── StylePreview.module.css          (195 lines) - Preview styles
├── app/api/
│   ├── page-styles-enhanced/
│   │   ├── route.ts                     (257 lines) - CRUD operations
│   │   ├── set-global/route.ts          (67 lines)  - Global default
│   │   └── assign-project/route.ts      (167 lines) - Project linking
│   └── page-style/route.ts              (113 lines) - Public endpoint
├── hooks/
│   └── usePageStyle.ts                  (170 lines) - Style application
├── lib/
│   └── pageStyleTypesEnhanced.ts        (266 lines) - TypeScript types
└── scripts/
    └── seedPageStyles.ts                (260 lines) - Default themes
```

**Total**: 11 files, 2,887 lines of production code

### Benefits

1. **White-Label Deployments**: Different visual identities per client without code changes
2. **Brand Consistency**: Match partner/client brand guidelines automatically
3. **Dark Mode Support**: Built-in theme switching (e.g., night events)
4. **No Code Changes**: Admins create themes via UI, no developer involvement
5. **Real-Time Preview**: See changes instantly before saving
6. **Flexible**: Supports gradients, custom fonts, complete color palettes
7. **Performance**: Minimal impact on page load (<210ms)
8. **Maintainable**: Centralized theming system with type safety

### Future Enhancements

See ROADMAP.md for planned improvements:
1. **Enhanced Color Picker**: Gradient builder UI (vs. manual CSS input)
2. **Theme Import/Export**: JSON export for sharing themes across instances
3. **Theme Preview URL**: Shareable preview link before applying to production
4. **Animation Controls**: Transition timing, hover effects
5. **Responsive Typography**: Different font sizes per breakpoint
6. **Admin UI Assignment**: Dropdown in project edit modal to assign styles
7. **Theme Categories**: Organize themes by industry/use case
8. **Font Upload**: Custom font file support (vs. pre-defined fonts)
9. **CSS Variables Export**: Generate CSS custom properties for external use
10. **A/B Testing**: Compare multiple themes on same project

### Usage Examples

**Creating a Custom Theme via API**:
```typescript
const newStyle = await fetch('/api/page-styles-enhanced', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Corporate Red',
    description: 'Red-themed corporate branding',
    isGlobalDefault: false,
    pageBackground: { type: 'solid', color: '#f8f8f8' },
    heroBackground: { type: 'gradient', gradient: 'linear-gradient(to right, #dc2626, #b91c1c)' },
    contentBoxBackground: {
      backgroundColor: '#ffffff',
      borderColor: '#dc2626',
      borderWidth: '2px',
      borderRadius: '8px'
    },
    typography: {
      fontFamily: 'Poppins',
      fontSize: '16px',
      headingColor: '#111827',
      textColor: '#374151',
      fontWeight: '500'
    },
    colorScheme: {
      primary: '#dc2626',
      secondary: '#b91c1c',
      accent: '#f59e0b',
      success: '#10b981',
      warning: '#f59e0b',
      error: '#ef4444'
    }
  })
});
```

**Fetching All Styles**:
```typescript
const response = await fetch('/api/page-styles-enhanced');
const { styles } = await response.json();
// Returns array of PageStyleEnhanced objects
```

**Setting Global Default**:
```typescript
await fetch('/api/page-styles-enhanced/set-global', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ styleId: '65a1b2c3d4e5f6789abc0000' })
});
// Atomically unsets previous default and sets new one
```

### Troubleshooting

**Style Not Applying**:
1. Verify `usePageStyle({ projectId })` called in component
2. Check project has `styleIdEnhanced` field or global default exists
3. Inspect browser console for fetch errors
4. Check network tab: `/api/page-style?projectId=X` should return 200

**CSS Not Visible**:
1. Inspect DOM: Look for `<style id="page-style-enhanced">` in `<head>`
2. Verify CSS rules target correct classes (`.stats-hero`, `.stats-content-box`)
3. Check CSS specificity (inline styles may override)
4. Disable browser extensions that modify CSS

**Admin UI Not Loading**:
1. Verify authentication (must be logged in as admin)
2. Check MongoDB connection
3. Run seed script: `npm run seed:page-styles` to ensure collection exists
4. Check browser console for API errors

**Multiple Global Defaults**:
1. Should never happen (API prevents this)
2. If corrupted data: Manually set `isGlobalDefault: false` for all but one style
3. Run: `db.page_styles_enhanced.updateMany({ isGlobalDefault: true }, { $set: { isGlobalDefault: false } })`
4. Then set desired default via API

---

## Security Enhancements — API Protection & Observability (Version 6.22.3)

### Overview

The Security Enhancements system provides comprehensive API protection through rate limiting, CSRF protection, and centralized logging. These layers work together to protect against abuse, ensure request authenticity, and provide operational visibility.

**Status**: Production-Ready  
**Documentation**: See [security-enhancements.md](security/security-enhancements.md) and [security-migration-guide.md](security/security-migration-guide.md)

### Key Components

#### 1. Rate Limiting Module (`lib/rateLimit.ts`)
- **Algorithm**: Token bucket with configurable limits per endpoint type
- **Endpoint Types**:
  - Authentication: 5 requests/minute (login, auth checks)
  - Write Operations: 30 requests/minute (POST/PUT/DELETE)
  - Read Operations: 100 requests/minute (GET)
  - Public Pages: 100 requests/minute (stats, filter pages)
- **Storage**: In-memory with automatic cleanup (suitable for single-instance deployment)
- **Response Headers**: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
- **Cooldown**: 5-minute cooldown after rate limit exceeded

**Features**:
- Per-IP tracking (supports `X-Forwarded-For` for proxied environments)
- Token refill based on elapsed time since last request
- Automatic bucket cleanup (removes inactive buckets after 1 hour)
- Production-ready logging integration

**Configuration**:
```typescript
const RATE_LIMITS = {
  authentication: { tokens: 5, windowMs: 60000 },
  write: { tokens: 30, windowMs: 60000 },
  read: { tokens: 100, windowMs: 60000 },
  public: { tokens: 100, windowMs: 60000 },
};
```

#### 2. CSRF Protection Module (`lib/csrf.ts`)
- **Pattern**: Double-submit cookie (secure, HttpOnly, SameSite=Lax)
- **Token Generation**: Cryptographically secure random tokens (32 bytes, hex-encoded)
- **Validation**: Compares cookie token with request header token
- **Protected Methods**: POST, PUT, DELETE, PATCH
- **Excluded Paths**: GET, HEAD, OPTIONS, and public endpoints

**Integration Points**:
- Middleware sets CSRF cookie on first request
- `/api/csrf-token` endpoint for AJAX token retrieval
- `apiClient` wrapper automatically includes token in headers

**Security Features**:
- HttpOnly cookies prevent XSS token theft
- SameSite=Lax prevents CSRF attacks
- Constant-time comparison prevents timing attacks
- Token rotation on validation failure

#### 3. Centralized Logging System (`lib/logger.ts`)
- **Output**: Structured JSON (production) or human-readable (development)
- **Log Levels**: DEBUG, INFO, WARN, ERROR
- **Sensitive Data Redaction**: Passwords, tokens, cookies automatically redacted
- **Integration**: Winston-compatible (ready for CloudWatch, Datadog)

**Log Types**:
- Request lifecycle (start, end, error)
- Security events (rate limit exceeded, CSRF violation)
- Application errors with stack traces
- Performance metrics (request duration)

**Usage Example**:
```typescript
import { logRequestStart, logRequestEnd, logRequestError } from '@/lib/logger';

const startTime = logRequestStart({ method: 'GET', pathname: '/api/projects', ip: '127.0.0.1' });
// ... handle request
logRequestEnd(startTime, { method: 'GET', pathname: '/api/projects' }, 200);
```

#### 4. Client API Wrapper (`lib/apiClient.ts`)
- **Purpose**: Transparent CSRF token management for client-side requests
- **Features**:
  - Automatic CSRF token fetching and caching
  - Token injection in request headers
  - Unified error handling (rate limits, CSRF violations)
  - TypeScript-safe JSON handling

**Exported Functions**:
```typescript
export async function apiGet<T>(url: string): Promise<T>
export async function apiPost<T>(url: string, data: any): Promise<T>
export async function apiPut<T>(url: string, data: any): Promise<T>
export async function apiDelete<T>(url: string): Promise<T>
export async function apiRequest<T>(url: string, options: RequestInit): Promise<T>
```

**Migration Path**: Replace raw `fetch()` calls with `apiClient` functions

#### 5. Security Middleware (`middleware.ts`)
- **Integration**: Next.js middleware pipeline
- **Applied To**: All API routes, admin pages, public stats pages
- **Excluded**: Static assets (/_next/*, /favicon.ico, etc.)

**Execution Order**:
1. Rate limiting check
2. CSRF token validation (for state-changing requests)
3. Request logging (start)
4. Route handler execution
5. Request logging (end)

**Response Modifications**:
- Sets CSRF cookie if missing
- Adds rate limit headers
- Logs security violations

### Security Benefits

1. **DDoS Protection**: Rate limiting prevents API abuse and resource exhaustion
2. **CSRF Prevention**: Double-submit cookie pattern blocks cross-site request forgery
3. **Audit Trail**: Centralized logging provides complete request history
4. **Attack Detection**: Security violations logged for monitoring
5. **Performance Monitoring**: Request duration tracking identifies bottlenecks

### Performance Impact

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| **Request Latency** | 50ms | 52ms | +2ms (negligible) |
| **First Request** | 50ms | 150ms | +100ms (CSRF token fetch, one-time) |
| **Memory Usage** | 100MB | 101MB | +1MB (rate limit store) |
| **Client Bundle** | 500KB | 502KB | +2KB (apiClient) |

**Conclusion**: Minimal performance impact with significant security gains.

### Production Scaling Plan

**Current Architecture**:
- In-memory rate limiting (suitable for single-instance)
- No external dependencies

**Future Scaling**:
- Redis adapter for distributed rate limiting
- External logging service integration (Datadog, CloudWatch)
- Configurable limits per user/tier
- IP whitelist/blacklist support

### Troubleshooting

**Common Issues**:

1. **"CSRF token invalid" error**:
   - Cause: Missing or expired token
   - Solution: Use `apiClient` instead of raw `fetch`, clear cookies

2. **Rate limit exceeded**:
   - Cause: Too many requests in short time
   - Solution: Implement exponential backoff, increase limits if legitimate

3. **Missing CSRF token cookie**:
   - Cause: First request hasn't set cookie yet
   - Solution: `apiClient` auto-fetches token via `/api/csrf-token`

### Migration Guide

See [security-migration-guide.md](security/security-migration-guide.md) for step-by-step migration instructions, including:
- Replacing `fetch()` calls with `apiClient`
- Adding logging to API routes
- Testing security features
- Performance validation

---

## Admin Variables & Metrics Management System (Version 7.0.0)

### Overview

**🚀 MAJOR ARCHITECTURE CHANGE**: The Variable System has been completely migrated to a **database-first architecture** with **Single Reference System** using full database paths.

**Key Changes**:
- ✅ ALL variables stored in MongoDB `variables_metadata` collection
- ✅ Full database paths used everywhere: `stats.female`, `stats.remoteImages`
- ✅ No code changes needed to add variables - fully dynamic via admin UI
- ✅ UI aliases for display names (e.g., "Women" for `stats.female`)
- ✅ System variables (schema fields) protected from deletion
- ✅ In-memory caching for performance (5-minute TTL)

**Status**: Production-Ready  
**Documentation**: See [VARIABLES_DATABASE_SCHEMA.md (archived)](archive/_archive/legacy-variable-system/archive-variables-database-schema.md) and [ADMIN_VARIABLES_SYSTEM.md (archived)](archive/_archive/legacy-variable-system/archive-admin-variables-system.md)

### Core Principles

#### Single Reference System

**WHAT**: Use full MongoDB document paths as canonical reference everywhere  
**WHY**: Zero translation layer = zero confusion, one source of truth  
**HOW**: Database path `stats.female` = Formula token `[stats.female]` = Code reference `stats.female`

**Rules**:
- ✅ **Code/Formulas**: Always use full path `stats.female`
- ✅ **Database**: Store as `{ stats: { female: 120 } }`
- ✅ **UI Display**: Show alias "Women" OR full path "stats.female" (user choice in KYC)
- ❌ **Never**: Use short aliases in code or formulas

### Architecture Components

#### 1. Variables Metadata Collection (`variables_metadata`)

**Role**: Single source of truth for ALL variables (system + custom)

**Schema**:
```typescript
interface VariableMetadata {
  _id: ObjectId;
  name: string;                    // Full DB path: "stats.female", "stats.remoteImages"
  label: string;                   // Display name: "Female", "Remote Images"
  type: 'count' | 'percentage' | 'currency' | 'numeric' | 'text' | 'boolean' | 'date';
  category: string;                // "Images", "Demographics", etc.
  description?: string;
  unit?: string;                   // "€", "%", "clicks"
  derived: boolean;                // True for computed variables
  formula?: string;                // Formula using full paths: "stats.female + stats.male"
  flags: {
    visibleInClicker: boolean;     // Show in Editor clicker buttons
    editableInManual: boolean;     // Allow manual editing
  };
  isSystem: boolean;               // True = cannot delete (schema fields)
  order: number;                   // Sort order within category
  alias?: string;                  // User-defined display alias (UI only)
  createdAt: string;               // ISO 8601 with milliseconds (UTC)
  updatedAt: string;
  createdBy?: string;              // "system" or user ID
  updatedBy?: string;
}
```

**System vs Custom Variables**:
- **System** (`isSystem: true`): Schema fields, cannot delete, can edit metadata
- **Custom** (`isSystem: false`): User-created, full CRUD control

#### 2. Variables Configuration API (`/api/variables-config`)

**Endpoint**: `GET /POST /api/variables-config`

**GET Response**:
```json
{
  "success": true,
  "variables": [
    {
      "name": "stats.female",
      "label": "Female",
      "type": "count",
      "category": "Demographics",
      "derived": false,
      "flags": {
        "visibleInClicker": true,
        "editableInManual": true
      },
      "isSystem": true,
      "order": 0
    }
  ],
  "count": 92,
  "cached": true
}
```

**Features**:
- In-memory cache (5-minute TTL)
- Cache invalidation on variable mutations
- Sorted by category → order → label

#### 3. Variable Seeding System

**Command**: `npm run seed:variables`

**Purpose**: Migrate all base/derived variables from code registry to MongoDB

**Process**:
1. Read `lib/variablesRegistry.ts` (BASE_STATS_VARIABLES + DERIVED_VARIABLES)
2. Upsert each to `variables_metadata` with `isSystem: true`
3. Create performance indexes
4. Verify seeding success

**Idempotency**: Can run multiple times safely (uses upsert)

#### 4. KYC Variables Admin (`/app/admin/kyc/page.tsx`)

**Features**:
- View all variables (system + custom) with metadata
- Search and filter by source (manual/system/derived/text), flags, categories
- Edit variable metadata (label, category, description)
- Create custom variables via modal
- Export to CSV/JSON
- **Alias Management**: Set user-friendly display names

**UI Display**:
- Shows full database path: `stats.female` in `<code>` block
- Shows display label: "Female"
- Shows alias if set: "Women" (badge)
- Lock icon for system variables (cannot delete)

#### 5. Clicker Variables Manager (`/app/admin/variables/page.tsx`)

**Purpose**: Control which variables appear in Editor clicker and their button order

**Features**:
- Drag-and-drop button reordering within categories
- Toggle visibleInClicker / editableInManual flags
- Group management for Editor layout
- Integration with KPI charts

### Data Model

**Variable Definition (Registry)**
```typescript
interface VariableDefinition {
  name: string;           // camelCase identifier
  label: string;          // Display name
  type: 'count' | 'percentage' | 'currency' | 'numeric' | 'text';
  category: string;       // Grouping (Images, Fans, Demographics, etc.)
  description?: string;
  derived?: boolean;      // True for computed variables
  formula?: string;       // Formula string for derived variables
  aliases?: string[];     // Alternative names
}
```

**Variable Config (Database)**
```typescript
interface VariableConfigDoc {
  _id: string;            // Equals name for easy upsert
  name: string;
  label?: string;         // Override registry label
  type?: string;          // Override registry type
  category?: string;      // Override registry category
  derived?: boolean;
  formula?: string;
  isCustom?: boolean;     // True for user-defined variables
  flags: {
    visibleInClicker: boolean;    // Show in Editor Clicker UI
    editableInManual: boolean;    // Allow manual editing
  };
  clickerOrder?: number;  // Button position in Clicker
  manualOrder?: number;   // Field position in Manual mode
  createdAt: string;      // ISO 8601 with milliseconds
  updatedAt: string;      // ISO 8601 with milliseconds
}
```

**Variable Group (Database)**
```typescript
interface VariableGroup {
  _id?: string;
  groupOrder: number;         // Display sequence
  chartId?: string;           // KPI chart to show above variables
  titleOverride?: string;     // Custom section title
  variables: string[];        // Ordered array of variable names
}
```

### Visibility & Editability Flags

**Default Flags by Category**:
- **Images, Fans, Demographics, Merchandise**: `{ visibleInClicker: true, editableInManual: true }`
- **Moderation, Visits, Event**: `{ visibleInClicker: false, editableInManual: true }`
- **Derived/Text**: `{ visibleInClicker: false, editableInManual: false }`

**Rationale**:
- Clicker designed for high-frequency live event metrics
- Manual mode for post-event data entry (all base stats)
- Derived/text variables are computed or non-numeric

### SEYU Token Examples

| Variable Name | Registry Label | SEYU Token | Normalization Rule |
|---------------|---------------|------------|--------------------|
| `allImages` | Total Images | `[SEYUTOTALIMAGES]` | ALL → TOTAL |
| `visitShortUrl` | Short URL Visits | `[SEYUSHORTURLVISIT]` | VISIT* → *VISIT |
| `eventValuePropositionVisited` | Value Prop Visited | `[SEYUPROPOSITIONVISIT]` | VISITED → VISIT |
| `stadium` | Location | `[SEYUSTADIUMFANS]` | Add FANS suffix |
| `merched` | People with Merch | `[SEYUMERCHEDFANS]` | Explicit mapping |
| `jersey` | Jerseys | `[SEYUMERCHERSEY]` | MERCH prefix |

### Variable Groups Manager

**Purpose**: Controls Editor dashboard layout by organizing variables into themed sections with optional KPI charts.

**Default Groups** (initialized via "Initialize default groups"):
1. **Images** (order 1) — remoteImages, hostessImages, selfies + `all-images-taken` chart
2. **Location** (order 2) — remoteFans, stadium + `total-fans` chart
3. **Demographics** (order 3) — female, male, genAlpha, genYZ, genX, boomer
4. **Merchandise** (order 4) — merched, jersey, scarf, flags, baseballCap, other

**API**: `/api/variables-groups` (GET/POST/DELETE)

### Custom Variables

**Purpose**: Allows admins to define project-specific metrics beyond base registry (e.g., `vipGuests`, `pressAttendees`).

**Creation Flow**:
1. Click "New Variable" in Admin Variables page
2. Fill form: name (camelCase), label, type, category, flags
3. Variable persisted with `isCustom: true` in MongoDB
4. Values stored in `project.stats` alongside base variables

**Deletion**: Custom variables deletable via "🗑️ Delete" button (admin has full CRUD control).

### Integration with Editor

**Editor Dashboard Consumption** (`/app/edit/[slug]/page.tsx`):
1. Fetches `/api/variables-config` on mount
2. Filters for Clicker: `visibleInClicker === true`

---

## Formula Validation System (Version 6.9.2)

### Overview

The Formula Validation System provides real-time validation for chart formulas in the Admin Charts interface, preventing invalid formulas from entering the system and guiding admins toward consistent token usage.

**Status**: Production-Ready  
**Components**: FormulaEditor component, validation functions, Validate All feature

### Key Components

#### 1. FormulaEditor Component (`components/FormulaEditor.tsx`)
- **Role**: Reusable formula input with live validation feedback
- **Features**:
  - 300ms debounced validation as user types
  - Variable picker dropdown with search and category filtering
  - Real-time error/warning/success status display
  - Syntax highlighting for variable tokens
  - Deprecation warnings for non-SEYU tokens
  - Division-by-zero detection
  - Click-outside handling for variable picker
  - Keyboard navigation support

**Usage Example**:
```typescript
import FormulaEditor from '@/components/FormulaEditor';

<FormulaEditor
  formula={element.formula}
  onChange={(newFormula) => updateElement(index, 'formula', newFormula)}
  onValidate={(result) => handleValidation(index, result)}
  placeholder="Enter formula..."
/>
```

#### 2. Validation Functions (`lib/formulaEngine.ts`)

**Exported Functions**:
```typescript
// Validates formula syntax and variables
export function validateFormula(formula: string): FormulaValidationResult

// Extracts all variable tokens from formula
export function extractVariablesFromFormula(formula: string): string[]
```

**Validation Result Interface**:
```typescript
interface FormulaValidationResult {
  isValid: boolean;
  error?: string;
  usedVariables: string[];
  evaluatedResult?: number | 'NA';
}
```

**Validation Rules**:
- ❌ **Error**: Unknown variables (not in VARIABLE_MAPPINGS or computed set)
- ❌ **Error**: Unbalanced parentheses
- ⚠️ **Warning**: Non-SEYU tokens (deprecated format)
- ⚠️ **Warning**: Division by zero risk (regex: `/\/ *0(?!\d)/`)
- ✅ **Success**: Valid formula with test evaluation result

#### 3. Validate All Feature (ChartAlgorithmManager)

**Location**: Admin Charts page header  
**Button**: "✓ Validate All"  

**Functionality**:
- Validates all formulas across all chart configurations
- Counts: total formulas, valid, errors, warnings
- Lists specific error messages by chart and element
- Displays summary alert with results

**Implementation**:
```typescript
const validateAllFormulas = () => {
  configurations.forEach(config => {
    config.elements.forEach((element, idx) => {
      const result = validateFormula(element.formula);
      // Count errors, warnings, check for deprecated tokens
    });
  });
  // Display summary alert
};
```

### Validation Process

**Step 1: Token Extraction**
```typescript
const variableRegex = /\[([A-Z_]+)\]/g;
const variables = extractVariablesFromFormula(formula);
// Example: "[SEYUFEMALE] + [SEYUMALE]" → ["SEYUFEMALE", "SEYUMALE"]
```

**Step 2: Variable Validation**
- Normalize tokens (strip SEYU prefix, remove underscores)
- Check against VARIABLE_MAPPINGS and computed set
- Flag unknown variables as errors

**Step 3: Syntax Validation**
- Check balanced parentheses (track open/close count)
- Detect unclosed or premature closing parentheses

**Step 4: Deprecation Check**
- Identify tokens without SEYU prefix (e.g., `[FEMALE]` vs `[SEYUFEMALE]`)
- Emit warnings to guide migration

**Step 5: Division-by-Zero Check**
- Regex match: `/\/ *0(?!\d)/` (literal division by zero)
- Emit warning (formula will evaluate to NA at runtime)

**Step 6: Test Evaluation**
- Substitute variables with sample values (all = 1)
- Evaluate formula safely via `Function` constructor
- Return numeric result or 'NA'

### Variable Picker UI

**Design**: Dropdown overlay with search and category filter

**Features**:
- **Search**: Live filter by variable name, display name, or description
- **Category Filter**: Dropdown to filter by Images, Fans, Demographics, etc.
- **Variable Cards**: Display name, SEYU token, description, example usage
- **Click to Insert**: Inserts `[TOKEN]` at cursor position
- **Keyboard Support**: Escape to close, arrow navigation

**Categories Available**:
- All (no filter)
- Images
- Location
- Demographics
- Merchandise
- Moderation
- Engagement
- Social Media
- Event
- Merchandise Pricing

### Error Messages

**Common Errors**:
- `"Invalid variables: [INVALIDTOKEN]"` — Unknown variable token
- `"Unbalanced parentheses: closing parenthesis without opening"` — Syntax error
- `"Unbalanced parentheses: unclosed opening parenthesis"` — Missing close paren

**Common Warnings**:
- `"Variable [FEMALE] uses deprecated format. Consider using SEYU-prefixed tokens."` — Migration guidance
- `"Potential division by zero detected. Formula will return NA if denominator is 0."` — Safety warning

### Integration Points

**ChartAlgorithmManager** (`components/ChartAlgorithmManager.tsx`):
- Validates formulas on element edit
- Blocks save if any formula has errors
- Shows validation status per element

**Future Integration** (planned for parameterization):
- Support `[PARAM:parameterName]` tokens
- Support `[MANUAL:key]` tokens for aggregated data
- Extended validation for new token types

### Performance

**Debouncing**: 300ms delay prevents validation on every keystroke  
**Caching**: Validation results stored in component state  
**Efficiency**: Single-pass regex for token extraction

### Accessibility

- ✅ Keyboard navigation (Tab, Enter, Escape)
- ✅ ARIA labels for validation status
- ✅ Color + icon + text for error states (WCAG compliant)
- ✅ Focus management (auto-focus search, return focus after insert)

### Future Enhancements

- Add inline formula autocomplete (as-you-type suggestions)
- Syntax highlighting with color-coded tokens
- Formula templates library (common patterns)
- Semantic validation (e.g., warn if mixing counts with percentages)
- Historical formula validation (check all existing charts on DB schema change)

---

## Chart System Enhancement Phase B (Version 6.10.0)

### Overview

Chart System Enhancement Phase B transforms the Chart Algorithm Manager from hardcoded formulas to a fully flexible, data-driven system with parameterized values, Bitly enrichment charts, and support for aggregated analytics.

**Status**: Production-Ready  
**Release**: v6.10.0 (2025-01-16)  
**Components**: Formula engine extensions, 3 Bitly charts, parameter migration

### Phase B.1: Parameterized Marketing Multipliers

#### Overview

Enables marketing teams to tune CPM values and multipliers without code changes by introducing `[PARAM:key]` tokens in formulas.

**Before** (Hardcoded):
```typescript
formula: "([SEYUREMOTEIMAGES] + [SEYUHOSTESSIMAGES] + [SEYUSELFIES]) * 4.87"
```

**After** (Parameterized):
```typescript
formula: "([SEYUREMOTEIMAGES] + [SEYUHOSTESSIMAGES] + [SEYUSELFIES]) * [PARAM:cpmEmailOptin]",
parameters: {
  cpmEmailOptin: {
    value: 4.87,
    label: "Email Opt-in CPM",
    unit: "EUR",
    description: "€4.87 avg market cost per email opt-in in Europe, 2025"
  }
}
```

#### Implementation

**Formula Engine Extension** (`lib/formulaEngine.ts`):
```typescript
// Updated signature to accept parameters
export function evaluateFormula(
  formula: string, 
  stats: ProjectStats, 
  parameters?: Record<string, number>,
  manualData?: Record<string, number>
): number | 'NA'

// PARAM token substitution
if (parameters) {
  processedFormula = processedFormula.replace(
    /\[PARAM:([a-zA-Z0-9_]+)\]/g, 
    (_match, paramKey) => {
      const value = parameters[paramKey];
      return value !== undefined ? String(value) : '0';
    }
  );
}
```

**ChartElement Type Extension** (`lib/chartConfigTypes.ts`):
```typescript
interface ChartElement {
  id: string;
  label: string;
  formula: string;
  color: string;
  description?: string;
  
  parameters?: {
    [key: string]: {
      value: number;
      label: string;
      description: string;
      unit?: string; // "EUR", "%", "count", "multiplier"
    }
  };
}
```

**Value Chart Migration** (`scripts/parameterize-value-chart.js`):
- Migrated 5 Value chart elements to use `[PARAM:x]` tokens
- Parameters: `cpmEmailOptin`, `cpmEmailAddon`, `cpmStadiumAd`, `exposureRatio`, `premiumContactValue`, `sharedImages`, `avgViews`, `cpmSocialOrganic`
- All parameters documented with EUR values and descriptions

#### Benefits

1. **Marketing Flexibility**: Update CPM values via MongoDB without code deployment
2. **Regional Adaptation**: Different parameter sets per region or partner
3. **A/B Testing**: Test different multiplier values without formula changes
4. **Audit Trail**: Parameters stored with metadata (source, date, rationale)

### Phase B.2: Bitly Enrichment Charts

#### Overview

Three new charts visualize Bitly clickstream data (device types, traffic sources, geographic reach) when Bitly integration is active.

#### New Charts Created

**1. Bitly Device Split** (Pie Chart, Order 35)
```typescript
{
  chartId: 'bitly-device-split',
  title: 'Bitly Device Split',
  type: 'pie',
  emoji: '📱',
  elements: [
    { label: 'Mobile', formula: '[SEYUBITLYMOBILECLICKS]', color: '#3b82f6' },
    { label: 'Desktop + Tablet', formula: '[SEYUBITLYDESKTOPCLICKS] + [SEYUBITLYTABLETCLICKS]', color: '#8b5cf6' }
  ]
}
```

**2. Bitly Referrers** (Bar Chart, Order 36)
```typescript
{
  chartId: 'bitly-referrers',
  title: 'Bitly Referrers',
  type: 'bar',
  elements: [
    { label: 'QR Code', formula: '[SEYUBITLYQRCODECLICKS]', color: '#10b981' },
    { label: 'Instagram', formula: '[SEYUBITLYINSTAGRAMMOBILECLICKS] + [SEYUBITLYINSTAGRAMWEBCLICKS]', color: '#ec4899' },
    { label: 'Facebook', formula: '[SEYUBITLYFACEBOOKMOBILECLICKS] + [SEYUBITLYFACEBOOKMESSENGERCLICKS]', color: '#3b82f6' },
    { label: 'Other Social', formula: '[SEYUBITLYSOCIALCLICKS]', color: '#8b5cf6' },
    { label: 'Direct', formula: '[SEYUBITLYDIRECTCLICKS]', color: '#6b7280' }
  ]
}
```

**3. Bitly Geographic Reach** (KPI Chart, Order 37)
```typescript
{
  chartId: 'bitly-geographic-reach',
  title: 'Bitly Geographic Reach',
  type: 'kpi',
  emoji: '🌍',
  elements: [
    { label: 'Countries Reached', formula: '[SEYUBITLYCOUNTRYCOUNT]', color: '#3b82f6' }
  ]
}
```

#### Bitly Variables Added (25 total)

**Core Metrics**:
- `bitlyTotalClicks`, `bitlyUniqueClicks`

**Geographic**:
- `bitlyClicksByCountry`, `bitlyTopCountry`, `bitlyCountryCount`

**Traffic Sources (Platform-level)**:
- `bitlyDirectClicks`, `bitlySocialClicks`, `bitlyTopReferrer`, `bitlyReferrerCount`

**Referring Domains (Granular)**:
- `bitlyTopDomain`, `bitlyDomainCount`, `bitlyQrCodeClicks`, `bitlyInstagramMobileClicks`, `bitlyInstagramWebClicks`, `bitlyFacebookMobileClicks`, `bitlyFacebookMessengerClicks`

**Device & Platform**:
- `bitlyMobileClicks`, `bitlyDesktopClicks`, `bitlyTabletClicks`, `bitlyiOSClicks`, `bitlyAndroidClicks`

**Browsers**:
- `bitlyChromeClicks`, `bitlySafariClicks`, `bitlyFirefoxClicks`

#### Data Requirements

Bitly charts display "NA" if project lacks Bitly data. Expected data source:
- Bitly API analytics aggregated into `project.stats` (future implementation)
- Manual entry via Admin Variables (interim solution)

### Phase B.3: Manual Data Token Support

#### Overview

Enables `[MANUAL:key]` tokens for aggregated analytics data that doesn't belong in individual project stats (e.g., hashtag seasonality, partner benchmarks).

#### Implementation

**Formula Engine Extension**:
```typescript
// MANUAL token substitution
if (manualData) {
  processedFormula = processedFormula.replace(
    /\[MANUAL:([a-zA-Z0-9_]+)\]/g, 
    (_match, manualKey) => {
      const value = manualData[manualKey];
      return value !== undefined ? String(value) : '0';
    }
  );
}
```

**ChartElement Type Extension**:
```typescript
interface ChartElement {
  // ... existing fields
  manualData?: {
    [key: string]: number; // Simple key-value map for aggregated data
  };
}
```

**Validation Support**:
- `[PARAM:x]` and `[MANUAL:x]` tokens always considered valid
- No mapping required in VARIABLE_MAPPINGS
- Resolved externally at evaluation time

#### Use Cases

**Hashtag Seasonality** (Future):
```typescript
formula: "[MANUAL:q1EventCount] + [MANUAL:q2EventCount] + [MANUAL:q3EventCount]",
manualData: {
  q1EventCount: 45, // Pre-aggregated from MongoDB query
  q2EventCount: 62,
  q3EventCount: 38
}
```

**Partner Benchmarks** (Future):
```typescript
formula: "[MANUAL:avgFansPerEvent] / [SEYUTOTALFANS] * 100",
manualData: {
  avgFansPerEvent: 4200 // Computed across all partner events
}
```

### Integration Points

**Chart Calculator** (`lib/chartCalculator.ts`):
```typescript
// Extract parameters and manualData from element
const paramValues = element.parameters 
  ? Object.fromEntries(Object.entries(element.parameters).map(([k, v]) => [k, v.value]))
  : undefined;

const manualValues = element.manualData;

const value = evaluateFormula(element.formula, stats, paramValues, manualValues);
```

### Testing

**Validation**:
- ✅ Type-check passes (all types updated)
- ✅ Build passes (production-ready)
- ✅ Parameter substitution verified in dev environment
- ✅ 3 Bitly charts created in MongoDB Atlas

**Manual Testing Required**:
- Value chart displays parameterized values correctly
- Bitly charts render when Bitly data present
- Charts show "NA" gracefully when data missing
- Parameter editing via MongoDB updates chart values

### Future Enhancements

**Parameter Editor UI** (v6.11.0+):
- Admin page to edit chart parameters without MongoDB access
- Historical parameter value tracking
- Parameter inheritance across chart families

**Hashtag Analytics Charts** (v6.11.0+):
- Sport share pie chart with `[MANUAL:sportCounts]`
- Seasonality timeline with `[MANUAL:quarterCounts]`
- Partner filter dropdown for benchmark comparisons

**Bitly Data Aggregator** (v6.12.0+):
- Automated Bitly API polling
- `project.stats` population with Bitly metrics
- Cache layer to reduce API calls

---

## Advanced Chart Formatting System with VALUE Chart Type (Version 8.17.0)

### Overview

The Advanced Chart Formatting System replaces hardcoded type-based formatting with a flexible, configurable interface supporting custom prefix/suffix combinations and decimal precision control. This enables white-label deployments with multiple currencies and custom units without code changes.

**Status**: Production-Ready  
**Release**: v8.17.0 (2025-10-31)  
**Components**: ChartValueFormatting interface, VALUE chart type, dual formatting UI, API validation

### Key Features

#### 1. ChartValueFormatting Interface

```typescript
interface ChartValueFormatting {
  rounded?: boolean;  // true = whole numbers, false = 2 decimal places
  prefix?: string;    // Custom prefix (€, $, £, etc.)
  suffix?: string;    // Custom suffix (%, pts, etc.)
}
```

**Benefits**:
- **White-Label Ready**: Configure currency symbols per deployment ($, €, £, ¥, etc.)
- **Flexible Units**: Support any prefix/suffix (%, pts, units, goals, etc.)
- **Precision Control**: Toggle between whole numbers and 2 decimal places
- **No Code Changes**: All configuration via MongoDB or Admin UI

#### 2. NEW: VALUE Chart Type

**Purpose**: Financial dashboards combining KPI total with horizontal bar breakdown

**Requirements**:
- **Exactly 5 elements** (validated at API and component level)
- **Dual formatting configs**:
  - `kpiFormatting` - Separate formatting for large total display
  - `barFormatting` - Unified formatting for all 5 bar elements
- **Layout Support**: Portrait and landscape orientations

**Visual Structure**:
```
┌─────────────────────────┐
│  €142,500 ← KPI total   │ (uses kpiFormatting)
│                         │
│  Element 1: €45,000 ━━━ │ (uses barFormatting)
│  Element 2: €32,000 ━━  │
│  Element 3: €28,000 ━   │
│  Element 4: €22,000 ━   │
│  Element 5: €15,500 ━   │
└─────────────────────────┘
```

**Example Configuration**:
```typescript
{
  chartId: 'total-ad-value',
  title: 'Total Ad Value',
  type: 'value',
  emoji: '💰',
  kpiFormatting: {
    rounded: true,
    prefix: '€',
    suffix: ''
  },
  barFormatting: {
    rounded: true,
    prefix: '€',
    suffix: ''
  },
  elements: [
    { label: 'Email', formula: '[SEYUALLIMAGES] * [PARAM:cpmEmailOptin]', ... },
    { label: 'Social', formula: '[SEYUALLIMAGES] * [PARAM:cpmSocialOrganic]', ... },
    { label: 'Stadium', formula: '[SEYUINDOORFANS] * [PARAM:cpmStadiumAd]', ... },
    { label: 'Premium', formula: '[SEYUYOUTHFANS] * [PARAM:premiumContactValue]', ... },
    { label: 'Reoptin', formula: '[SEYUALLIMAGES] * [PARAM:cpmEmailAddon]', ... }
  ]
}
```

#### 3. Updated Chart Components

**ValueChart Component** (`components/DynamicChart.tsx`):
- New component with dual formatting support
- Validates exactly 5 elements on render
- Portrait and landscape layout switching
- Uses large KPI display + horizontal bar chart

**Existing Chart Updates**:
- **PieChart**: Updated to use `formatting` field (backward compatible)
- **BarChart**: Updated with flexible total formatting and **50/50 fixed layout** (v9.2.1)
  - **Layout**: Bar (50% left) | Legend (50% right) with `grid-template-columns: 1fr 1fr`
  - **Text Overflow**: Legend uses `.text-fade-end` utility (5% gradient fade to `var(--mm-white)`)
  - **Purpose**: Ensures consistent bar widths regardless of legend text length
  - **Design Tokens**: All spacing, colors, transitions use CSS variables (no hardcoded values)
- **KPIChart**: Maintains compatibility with legacy `type` field

**Backward Compatibility**:
```typescript
// Legacy mode (still works)
{ type: 'currency' } → displays as "€1,234.56"
{ type: 'percentage' } → displays as "45.67%"

// New mode (preferred)
{ formatting: { rounded: true, prefix: '€', suffix: '' } } → displays as "€1,235"
```

#### 4. formatChartValue() Function

**Updated Signature** (`lib/chartCalculator.ts`):
```typescript
function formatChartValue(
  value: number | 'NA',
  formatting?: { rounded?: boolean; prefix?: string; suffix?: string },
  type?: 'currency' | 'percentage' | 'number' // DEPRECATED, for backward compatibility
): string
```

**Logic**:
1. If `value === 'NA'`, return `'N/A'`
2. If `formatting` provided (new mode):
   - Round to 0 or 2 decimal places based on `rounded` flag
   - Use `toLocaleString()` for thousands separators
   - Return `prefix + number + suffix`
3. Else if `type` provided (legacy mode):
   - Apply hardcoded formatting based on type
4. Else: Return raw number with 2 decimals

**Examples**:
```typescript
formatChartValue(1234.567, { rounded: true, prefix: '€', suffix: '' }) 
// → "€1,235"

formatChartValue(0.4567, { rounded: false, prefix: '', suffix: '%' }) 
// → "0.46%"

formatChartValue(1234.567, undefined, 'currency') // Legacy
// → "€1,234.57"
```

### Admin UI Integration

**Chart Algorithm Manager** (`/admin/charts`):

**VALUE Chart Type Controls**:
1. **Chart Type Dropdown**: Includes "💰 VALUE Chart (KPI + 5 bars with dual formatting)" option
2. **KPI Total Formatting Section** (only for VALUE type):
   - ☑️ Checkbox: "Rounded (whole numbers)"
   - Text input: "Prefix" (default: €)
   - Text input: "Suffix" (default: %)
3. **Bar Elements Formatting Section** (only for VALUE type):
   - ☑️ Checkbox: "Rounded (whole numbers)"
   - Text input: "Prefix" (default: €)
   - Text input: "Suffix" (default: %)
4. **Element List**: Must have exactly 5 elements (validation enforced)

**Styling** (`components/ChartAlgorithmManager.module.css`):
- `.formattingControlsSection` - Container with spacing and borders
- `.formattingControlRow` - Horizontal layout for checkbox + inputs
- `.formattingLabel` - Bold section titles
- Uses design tokens (`--mm-color-*`, `--mm-space-*`) for consistency

### API Validation

**Chart Configuration API** (`/app/api/chart-config/route.ts`):

**validateFormatting() Helper**:
```typescript
function validateFormatting(
  formatting: any, 
  fieldName: string
): { valid: boolean; error?: string }
```

**Validation Rules**:
1. **VALUE Chart Requirements**:
   - Must have exactly 5 elements
   - Must have `kpiFormatting` object
   - Must have `barFormatting` object
   - Both formatting objects must be valid
2. **Formatting Object Validation**:
   - `rounded` must be boolean (if present)
   - `prefix` must be string (if present)
   - `suffix` must be string (if present)
3. **Element-Level Formatting**: Optional per-element `formatting` validated

**Error Examples**:
```json
// Missing formatting configs
{ "error": "VALUE charts must have both kpiFormatting and barFormatting" }

// Wrong element count
{ "error": "VALUE charts require exactly 5 elements, got 3" }

// Invalid formatting type
{ "error": "kpiFormatting.rounded must be a boolean" }
```

### Migration Path

**No Database Migration Required**:
- Existing charts with `type` field continue to work (legacy mode)
- New charts can use `formatting` object (preferred)
- Mixed usage supported (some charts legacy, some new)

**Gradual Migration Strategy**:
1. **Phase 1**: Deploy v8.17.0 with backward compatibility
2. **Phase 2**: Create new VALUE charts with dual formatting
3. **Phase 3**: Optionally migrate existing charts to use `formatting` field
4. **Phase 4**: Deprecate `type` field in future major version (v9.0.0+)

**Migration Script** (optional, for bulk updates):
```javascript
// Example: Migrate all currency-type KPI charts to formatting object
db.chart_configurations.updateMany(
  { type: 'kpi', 'elements.type': 'currency' },
  {
    $set: {
      'elements.$[elem].formatting': { rounded: false, prefix: '€', suffix: '' }
    },
    $unset: { 'elements.$[elem].type': '' }
  },
  { arrayFilters: [{ 'elem.type': 'currency' }] }
);
```

### Integration Points

**Chart Calculator** (`lib/chartCalculator.ts`):
- Passes `formatting` to `formatChartValue()` for each element
- Handles VALUE chart dual formatting (KPI vs. bars)

**DynamicChart** (`components/DynamicChart.tsx`):
- Routes VALUE type to `ValueChart` component
- Validates 5-element requirement before render

**Visualization Manager** (`app/admin/visualization/page.tsx`):
- Displays VALUE charts with dual formatting in preview blocks

### Performance

- **No Performance Impact**: Formatting is lightweight string concatenation
- **Validation Overhead**: Minimal (<1ms per chart validation)
- **Backward Compatibility**: No extra database queries (formatting stored inline)

### Accessibility

- ✅ **Screen Readers**: ARIA labels for formatting controls
- ✅ **Keyboard Navigation**: All inputs and checkboxes keyboard accessible
- ✅ **Color Independence**: Value formatting doesn't rely on color
- ✅ **Form Labels**: All inputs have associated labels

### Testing

**Validation**:
- ✅ TypeScript type-check passes (strict mode)
- ✅ Next.js production build successful
- ✅ VALUE chart type appears in dropdown
- ✅ Formatting controls display for VALUE type only
- ✅ API validation enforces VALUE requirements
- ✅ Backward compatibility with legacy `type` field
- ✅ All chart types render correctly

**Manual Testing**:
- Create VALUE chart with dual formatting
- Verify KPI and bars use separate formatting
- Test prefix/suffix combinations (€, $, %, pts)
- Test rounded vs. 2-decimal modes
- Verify 5-element requirement blocks save with <5 or >5 elements

### Future Enhancements

**Planned for v8.18.0+**:
1. **Default Chart Configurations**: Seed VALUE chart templates with common formats
2. **Formatting Presets**: Quick-select buttons (Currency €, Currency $, Percentage, Count)
3. **Element-Level Formatting Override**: Per-element formatting for mixed units (e.g., € + %)
4. **Locale-Aware Formatting**: Use user's locale for number separators
5. **Custom Decimal Places**: Allow 0, 1, 2, 3, or 4 decimal places (not just rounded vs. 2)

---

## Pie Chart Percentage Visibility Control (Version 11.43.0)

### Overview

The Pie Chart Percentage Visibility Control adds a configurable `showPercentages` field to pie charts, allowing admins to toggle percentage display in legends and tooltips on a per-chart basis. This provides flexibility for cleaner chart designs when percentages are not needed.

**Status**: Production-Ready  
**Release**: v11.43.0 (2025-12-22)  
**Components**: showPercentages field, Chart Algorithm Manager checkbox

### Key Features

#### 1. Configuration Field

**Database Schema Extension** (`lib/chartConfigTypes.ts`):
```typescript
interface ChartConfiguration {
  chartId: string;
  title: string;
  type: 'pie' | 'bar' | 'kpi' | 'text' | 'image' | 'value';
  showTitle?: boolean;        // Controls title visibility
  showPercentages?: boolean;  // ✅ NEW: Controls percentage visibility (pie charts only)
  // ... other fields
}
```

**Default Behavior**:
- `showPercentages` defaults to `true` if not specified
- All existing pie charts continue showing percentages (backward compatible)
- Only applies to pie chart type - ignored by other chart types

#### 2. Admin UI Integration

**Chart Algorithm Manager** (`components/ChartAlgorithmManager.tsx`):
- Checkbox appears in "Display Settings" section when `type === 'pie'`
- Label: "Show Percentages in Legend"
- Tooltip: "Uncheck for cleaner pie chart legends"
- Saved to MongoDB on chart creation/update

**UI Location**:
```
Chart Algorithm Manager > Edit Pie Chart
  └─ Display Settings
      ├─ Show Title [checkbox]
      └─ Show Percentages in Legend [checkbox] (✅ NEW)
```

#### 3. Rendering Implementation

**Legend Display** (`app/report/[slug]/ReportChart.tsx`):
```tsx
// Before: Always shows percentages
<div className={styles.pieLegendText}>
  {protectedLabel}: {percentage}%
</div>

// After: Conditional display
<div className={styles.pieLegendText}>
  {showPercentages ? `${protectedLabel}: ${percentage}%` : protectedLabel}
</div>
```

**Tooltip Display**:
```tsx
// Tooltip callback respects showPercentages flag
callbacks: {
  label: (context) => {
    const label = context.label || '';
    const value = context.parsed as number;
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
    return showPercentages 
      ? `${label}: ${value.toLocaleString()} (${percentage}%)`
      : `${label}: ${value.toLocaleString()}`;
  }
}
```

#### 4. Visual Comparison

**With Percentages** (`showPercentages: true` - default):
```
● Female: 45%
● Male: 55%
```

**Without Percentages** (`showPercentages: false`):
```
● Female
● Male
```

### Integration Points

**Report Calculator** (`lib/report-calculator.ts`):
- Passes `showPercentages` field from chart config to ChartResult
- Field flows through calculation pipeline without modification

**API Endpoints**:
- `GET /api/chart-config` - Returns `showPercentages` field
- `POST /api/chart-config` - Accepts `showPercentages` in request body
- `PUT /api/chart-config` - Updates `showPercentages` field
- `GET /api/chart-config/public` - Includes `showPercentages` for public access

### Use Cases

1. **Minimalist Reports**: Hide percentages when chart labels alone convey meaning
2. **Space-Constrained Layouts**: Reduce text length in small pie chart legends
3. **Design Preferences**: Match specific branding guidelines requiring clean labels
4. **Redundant Data**: Hide percentages when exact values are shown elsewhere

### Benefits

- ✅ **Per-Chart Control**: Configure percentage visibility independently for each pie chart
- ✅ **User Control**: Admins decide chart appearance without code changes
- ✅ **Backward Compatible**: Existing charts unchanged (default: show percentages)
- ✅ **Type Safety**: Full TypeScript support with proper type guards
- ✅ **Consistent Pattern**: Follows `showTitle` toggle pattern

### Migration

**Not Required**: Field is optional with default value `true`. All existing pie charts automatically continue showing percentages until explicitly disabled by an admin.

---

## Image Layout System with Aspect Ratio Support (Version 9.3.0)

### Overview

The Image Layout System introduces flexible aspect ratio configuration for IMAGE charts, enabling consistent visual presentation across landscape, portrait, and square formats. This system ensures predictable grid layouts, maintains image cropping quality, and guarantees WYSIWYG PDF exports.

**Status**: Production-Ready  
**Release**: v9.3.0 (2025-11-01)  
**Components**: aspectRatio field, automatic width calculation, background-image rendering

### Key Features

#### 1. Aspect Ratio Configuration

**Supported Ratios**:
- **16:9** (Landscape) - Wide format for panoramic images, event banners
- **9:16** (Portrait) - Tall format for mobile-first content, vertical posters
- **1:1** (Square) - Balanced format for social media, profile images

**Database Schema Extension** (`lib/chartConfigTypes.ts`):
```typescript
interface ChartConfiguration {
  chartId: string;
  title: string;
  type: 'pie' | 'bar' | 'kpi' | 'text' | 'image' | 'value';
  aspectRatio?: '16:9' | '9:16' | '1:1'; // ✅ NEW: For IMAGE type only
  // ... other fields
}
```

**Admin UI Integration** (`app/admin/chart-algorithms/page.tsx`):
- Aspect ratio dropdown appears when `type === 'image'`
- Default: 16:9 (landscape) for new IMAGE charts
- Saved to MongoDB on chart creation/update

#### 2. Automatic Width Calculation

**Problem Solved**: Manual width management causes inconsistent row heights when mixing aspect ratios.

**Solution**: `calculateImageWidth()` utility automatically derives grid width from aspect ratio to maintain consistent row heights.

**Implementation** (`lib/imageLayoutUtils.ts`):
```typescript
export function calculateImageWidth(aspectRatio: '16:9' | '9:16' | '1:1'): number {
  // Grid height = 1 unit (portrait chart: 100% of CSS grid row height)
  // Calculate width to maintain aspect ratio
  
  switch (aspectRatio) {
    case '9:16': return 1;   // Portrait: 1 grid unit (narrow, baseline)
    case '1:1':  return 2;   // Square: 2 grid units (medium width)
    case '16:9': return 3;   // Landscape: 3 grid units (wide)
    default:     return 3;   // Fallback to landscape
  }
}
```

**Helper Functions**:
- `getAspectRatioLabel(aspectRatio)` - Returns "16:9 Landscape", "9:16 Portrait", "1:1 Square"
- `getCSSAspectRatio(aspectRatio)` - Returns "16/9", "9/16", "1/1" for CSS `aspect-ratio` property
- `isValidAspectRatio(value)` - Type guard for runtime validation

**Integration** (`components/UnifiedDataVisualization.tsx`):
```typescript
// Automatic width derivation for IMAGE charts
const chartWidth = useMemo(() => {
  if (chart.type === 'image' && chart.aspectRatio) {
    return calculateImageWidth(chart.aspectRatio);
  }
  return chart.chartWidth || 1; // Fallback for other chart types
}, [chart.type, chart.aspectRatio, chart.chartWidth]);
```

**Result**:
- ✅ IMAGE charts automatically sized based on aspect ratio
- ✅ Consistent row heights across mixed-ratio grids
- ✅ No manual width management required
- ✅ Backward compatible (charts without aspectRatio default to 16:9)

#### 3. Background-Image Rendering

**Problem**: `<img>` elements with `object-fit: cover` cause distortion in PDF exports when processed by `html2canvas`.

**Solution**: Native `background-image` CSS rendering with `background-size: cover`.

**Before** (Legacy):
```tsx
<img 
  src={imageUrl} 
  alt={title}
  style={{ objectFit: 'cover' }}
/>
```

**After** (v9.3.0):
```tsx
<div 
  className={styles.imageChartImg}
  style={{ '--image-url': `url("${imageUrl}")` } as React.CSSProperties}
/>
```

**CSS Implementation** (`components/charts/ImageChart.module.css`):
```css
.imageChartImg {
  width: 100%;
  height: 100%;
  background-image: var(--image-url);
  background-size: cover;      /* Maintains cropping */
  background-position: center; /* Centers image */
  background-repeat: no-repeat;
  border-radius: var(--mm-radius-lg);
  transition: transform var(--transition-base);
}

.imageChartImg:hover {
  transform: scale(1.02); /* Subtle zoom effect */
}
```

**Benefits**:
- ✅ **PDF Export Compatibility**: No runtime DOM manipulation required
- ✅ **WYSIWYG**: UI and PDF exports render identically
- ✅ **Performance**: Eliminates `html2canvas` workaround overhead
- ✅ **Maintainability**: Simpler codebase without image-to-div conversion logic

#### 4. PDF Export Simplification

**Deprecated Workaround** (`lib/export/pdf.ts`):
```typescript
// DEPRECATED (v9.3.0+): ImageChart now uses background-image natively
// This workaround is NO LONGER NECESSARY but kept for backward compatibility
// with custom components that may still use <img> with object-fit: cover
```

**Legacy Code Path**: Preserved for backward compatibility with external custom components, but not used by core IMAGE charts.

**Migration Strategy**:
- Phase 1 (v9.3.0): ImageChart uses background-image, PDF workaround marked deprecated
- Phase 2 (v10.0.0): Remove PDF workaround entirely (breaking change)

### Database Migration

**Script**: `scripts/migrations/add-aspect-ratio-to-image-charts.ts`

**Purpose**: Assign default `aspectRatio: '16:9'` to all existing IMAGE charts.

**Execution**:
```bash
npm run ts-node scripts/migrations/add-aspect-ratio-to-image-charts.ts
```

**Safety**:
- ✅ Only updates charts with `type: 'image'`
- ✅ Skips charts that already have `aspectRatio` field
- ✅ Dry-run mode available (set `DRY_RUN=true`)
- ✅ Logs all changes for audit trail

### Layout Examples

**Mixed Aspect Ratio Grid**:
```
┌─────────────────────────┬────────┬────────┐
│ 16:9 Landscape (2 units)│ 1:1    │ 9:16   │
│ Image Chart             │ Square │ Port.  │
└─────────────────────────┴────────┴────────┘
  ↑ 2 grid columns          ↑ 1      ↑ 0.5
```

**Consistent Row Heights**:
- All charts maintain **1 unit height** (portrait chart height as baseline)
- Widths calculated automatically: 9:16 → 1 unit, 1:1 → 2 units, 16:9 → 3 units
- CSS Grid handles integer units for clean layout math

### Chart Calculator Integration

**Type Extension** (`lib/chartConfigTypes.ts`):
```typescript
interface ChartCalculationResult {
  chartId: string;
  title: string;
  type: ChartType;
  emoji?: string;
  elements: Array<{ label: string; value: number | 'NA'; formattedValue: string; color: string; }>;
  total?: number;
  formattedTotal?: string;
  imageUrl?: string;
  aspectRatio?: '16:9' | '9:16' | '1:1'; // ✅ NEW: Passed through for IMAGE charts
}
```

**Implementation** (`lib/chartCalculator.ts`):
```typescript
if (config.type === 'image') {
  return {
    // ... other fields
    imageUrl: config.elements[0]?.imageUrl,
    aspectRatio: config.aspectRatio || '16:9', // Default to landscape
  };
}
```

### Validation & Error Handling

**Type Safety**:
- ✅ `aspectRatio` union type enforces valid values at compile time
- ✅ `isValidAspectRatio()` guards against invalid runtime values
- ✅ TypeScript strict mode enabled across entire codebase

**Fallback Behavior**:
- Missing `aspectRatio` → defaults to `'16:9'` (backward compatible)
- Invalid `aspectRatio` → falls back to `'16:9'` with console warning
- IMAGE charts without `aspectRatio` → width calculated as 2 (landscape)

### Performance

- **Width Calculation**: O(1) switch statement, <0.1ms per chart
- **Background Rendering**: Native CSS, no JavaScript overhead
- **PDF Export**: Eliminates ~10-50ms per image (no DOM manipulation)
- **Grid Layout**: CSS Grid handles fractional widths efficiently

### Accessibility

- ✅ **Aspect Ratio Dropdown**: Keyboard accessible, ARIA labels
- ✅ **Background Images**: Decorative images don't interfere with screen readers
- ✅ **Alt Text Equivalent**: Chart title provides context via semantic HTML

### Testing

**Validation**:
- ✅ TypeScript type-check passes (strict mode)
- ✅ Next.js production build successful
- ✅ Aspect ratio dropdown appears for IMAGE type only
- ✅ Width calculation accurate for all 3 ratios
- ✅ Background-image rendering works in all major browsers
- ✅ PDF export quality matches UI rendering

**Manual Testing Checklist**:
- Create IMAGE chart with 16:9 aspect ratio
- Create IMAGE chart with 9:16 aspect ratio
- Create IMAGE chart with 1:1 aspect ratio
- Verify consistent row heights in mixed-ratio grids
- Export page to PDF and verify image cropping
- Test on mobile (portrait) and desktop (landscape)
- Verify hover effects work on background-image

### Future Enhancements

**Planned for v9.4.0+**:
1. **Additional Aspect Ratios**: 4:3 (classic), 21:9 (ultrawide), 3:2 (photography)
2. **Custom Aspect Ratios**: Admin-defined ratios via "Custom: W:H" input
3. **Focal Point Selection**: Click to set center point for background-position
4. **Image Cropping Tool**: Visual editor for adjusting background-position (top/center/bottom)
5. **Responsive Aspect Ratios**: Different ratios for mobile vs. desktop
6. **Image Optimization**: Automatic WebP conversion and lazy loading
7. **Placeholder System**: Low-res preview while high-res loads

### Related Documentation

- **WARP.md**: PDF Export System section (object-fit handling)
- **REUSABLE_COMPONENTS_INVENTORY.md**: ImageChart component catalog
- **CODING_STANDARDS.md**: Background-image vs. img element guidelines

---

## Admin Variables & Metrics System

3. Orders by `clickerOrder` (ascending) within each category
4. Renders grouped sections if groups exist, with KPI charts if `chartId` set

### Visibility Flags
**Benefits**:
- Runtime configuration without code deploys
- Flexible Editor UI tailored to project needs
- Consistent variable referencing across formulas and charts
- Multi-tenancy ready with SEYU namespace

### Roadmap Compliance

✅ **Milestone: Admin Variables — Org-Prefixed References & Card Layout**
- SEYU-prefixed reference tokens with normalization
- Card layout enforces exact line order (Label → REF → Flags → TYPE) and equal heights
- Derived label standardized to "Total Images"

✅ **Milestone: Variable Visibility & Editability Flags + Edit Integration**
- Flags persist across sessions via MongoDB
- Custom variables supported with modal creation
- Editor integration respects flags in clicker/manual sections
- No UI drift — centralized button/style system

### Performance

- ✅ Single API call on Editor mount loads all config
- ✅ Client-side filtering and ordering (no repeated API calls)
- ✅ MongoDB indexes on `name` for fast lookups
- ✅ CSS Modules for scoped, tree-shakable styling

### Future Enhancements

See ROADMAP.md for planned improvements:
1. Bulk variable operations (enable/disable multiple)
2. Variable templates (predefined sets for common event types)
3. Formula validation in UI for derived variables
4. Export/import variable configurations
5. Variable usage analytics (which variables are edited most)

For complete documentation, API reference, usage patterns, and technical decisions, see [ADMIN_VARIABLES_SYSTEM.md (archived)](archive/_archive/legacy-variable-system/archive-admin-variables-system.md).

---

## Technology Stack

### Frontend

| Technology | Version | Purpose |
|------------|---------|----------|
| **Next.js** | 15.5.4 | React framework with App Router (RSC) |
| **React** | 18.3.1 | UI library with concurrent features |
| **TypeScript** | 5.6.3 | Type safety and developer experience (strict mode) |
| **Chart.js** | 4.5.0 | Chart rendering library |
| **react-chartjs-2** | 5.3.0 | React wrapper for Chart.js |
| **html2canvas** | 1.4.1 | PNG export for charts |
| **jsPDF** | 3.0.1 | PDF generation for exports |
| **WebSocket (ws)** | 8.18.3 | Real-time client-server communication |
| **js-cookie** | 3.0.5 | Client-side cookie management |
| **uuid** | 11.1.0 | Unique identifier generation |

**Styling**:
- **CSS Modules**: Component-scoped styling
- **CSS Variables**: Design tokens (`--mm-*` prefix) via `app/styles/theme.css`
- **No Tailwind**: Fully custom design system (TailAdmin V2 flat design)
- **No External UI Library**: All components built from scratch

### Backend

| Technology | Version | Purpose |
|------------|---------|----------|
| **MongoDB** | 6.8.0 | NoSQL database (MongoDB Atlas cloud) |
| **Next.js API Routes** | 15.5.4 | REST API endpoints (serverless functions) |
| **Node.js** | ≥18.0.0 | JavaScript runtime (server-side) |
| **dotenv** | 17.2.1 | Environment variable management |

**External APIs**:
- **Bitly API v4**: Link shortening and analytics

**Authentication**:
- **Custom Session-Based Auth**: HTTP-only cookies (no NextAuth.js)
- **Password-Based**: Admin login with bcrypt hashing
- **Page Protection**: Per-page password gates for public stats

### Development Tools

| Tool | Version | Purpose |
|------|---------|----------|
| **ESLint** | 8.57.0 | JavaScript/TypeScript linting |
| **eslint-config-next** | 15.5.4 | Next.js-specific ESLint rules |
| **TypeScript Compiler** | 5.6.3 | Type checking (tsc --noEmit) |
| **npm** | ≥8.0.0 | Package manager |

**Build Tools**:
- Next.js built-in bundler (Turbopack in dev mode)
- TypeScript compiler for type checking
- ESLint for code quality enforcement

### Infrastructure & Deployment

| Service | Purpose |
|---------|----------|
| **Vercel** | Next.js app hosting (automatic deployment from GitHub main) |
| **Railway/Heroku** | WebSocket server hosting (separate Node.js process) |
| **MongoDB Atlas** | Cloud database (free tier or paid) |
| **Vercel Edge Network** | CDN for static assets and API routes |
| **GitHub** | Source control and CI/CD trigger |

**Environment Configuration**:
```bash
# Required in .env.local and Vercel Environment Variables
MONGODB_URI=mongodb+srv://...
MONGODB_DB=messmass
NEXT_PUBLIC_WS_URL=wss://websocket-server.com
ADMIN_PASSWORD=secure_password

# Optional (Bitly integration)
BITLY_ACCESS_TOKEN=...
BITLY_ORGANIZATION_GUID=...
BITLY_GROUP_GUID=...
```

### Project Slug Access Control

**Purpose:** UUID-based slugs for secure, password-less access to projects.

**Implementation:**
- **`viewSlug`** (UUID v4): Read-only public access to `/stats/[slug]`
- **`editSlug`** (UUID v4): Editor access to `/edit/[slug]`

**Key Features:**
1. **Auto-Generated**: Created on project creation via `lib/slugUtils.ts`
2. **Unique Constraint**: Both slugs indexed as unique in database
3. **Security**: UUIDs provide ~2^122 combinations (brute-force resistant)
4. **No Passwords Required**: Direct URL access without additional authentication
5. **Revocable**: Can regenerate slugs to revoke access

**Usage Pattern:**
```typescript
// Generate on project creation
import { generateProjectSlugs } from '@/lib/slugUtils';
const { viewSlug, editSlug } = await generateProjectSlugs();

// Find project by slug
const project = await findProjectByViewSlug(viewSlug);
const editable = await findProjectByEditSlug(editSlug);
```

**Why UUID Slugs:**
- Eliminates need for separate password management per project
- Shareable URLs (e.g., for clients, stakeholders)
- Stateless - no session/auth required for project access
- Simple revocation: regenerate slug → old URL invalid

**Example URLs:**
- View: `https://messmass.com/stats/00825405-0018-4483-8854-e18c25f7607d`
- Edit: `https://messmass.com/edit/8fffdaa5-838c-4bf3-a382-0ba62a589faf`

### Database Schema Summary

| Collection | Purpose | Indexes |
|------------|---------|----------|
| `projects` | Event records with stats | eventDate, updatedAt, viewSlug (unique), editSlug (unique) |
| `partners` | Partner organizations | name, createdAt |
| `bitly_links` | Bitly link metadata | bitlink, createdAt |
| `bitly_project_links` | Link-project associations (many-to-many) | projectId, linkId |
| `hashtag_categories` | Category definitions with colors | name |
| `hashtags` | Hashtag usage tracking | _id (hashtag text) |
| `notifications` | Multi-user notifications | createdAt, archivedBy |
| `variablesConfig` | Variable flags and overrides | name |
| `variableGroups` | Editor layout groups | groupOrder |
| `users` | Admin users | email (unique) |
| `analytics_aggregates` | Pre-computed event analytics (v6.26.0) | projectId, eventDate, partnerId+eventDate, updatedAt |
| `aggregation_logs` | Background job tracking (v6.26.0) | startTime, status, jobType+startTime, createdAt (TTL) |
| `system_settings` | System configuration (v6.26.0) | key |

### Real-Time Architecture

**WebSocket Server** (Separate Node.js Process):
- **Location**: `server/websocket-server.js`
- **Port**: 7654 (configurable)
- **Protocol**: WebSocket (ws library)
- **Features**:
  - Project-based rooms for isolation
  - Automatic reconnection with exponential backoff
  - Heartbeat mechanism (ping/pong)
  - Message types: join-project, stat-update, project-update

**Client-Side Integration**:
- **Hook**: `hooks/useWebSocket.ts`
- **Auto-Reconnect**: Yes, with exponential backoff
- **Connection URL**: `NEXT_PUBLIC_WS_URL` environment variable

### Performance Optimizations

1. **Server-Side Rendering (SSR)**: Pages pre-rendered on server for SEO and initial load speed
2. **API Route Caching**: Strategic caching headers on API responses
3. **MongoDB Indexes**: All frequently queried fields indexed
4. **Pagination**: 20 items per page across all admin interfaces
5. **Lazy Loading**: Bitly links and large datasets loaded on-demand
6. **CSS Modules**: Tree-shakable scoped styles (no runtime CSS-in-JS)
7. **Image Optimization**: Next.js automatic image optimization
8. **Edge Functions**: API routes deployed to Vercel Edge Network

### Security Measures

1. **HTTP-Only Cookies**: Session tokens never accessible via JavaScript
2. **CSRF Protection**: SameSite cookie attribute
3. **Password Hashing**: Bcrypt for admin passwords (if implemented)
4. **Environment Variables**: Secrets never committed to repository
5. **API Authentication**: Middleware validates session on all protected routes
6. **Input Validation**: TypeScript + runtime validation on API endpoints
7. **MongoDB Injection Prevention**: Parameterized queries via MongoDB driver
8. **Rate Limiting**: (To be implemented) Prevent brute force attacks

---

## Analytics Infrastructure (Version 6.26.0)

### Overview

The Analytics Infrastructure provides **pre-computed, high-performance analytics** for event metrics, partner performance, time-series trends, and industry benchmarking. Phase 1 implements the core data aggregation pipeline with 5 API endpoints serving sub-second query response times.

### Architecture Components

**1. Data Aggregation Pipeline**

- **Background Job**: `scripts/aggregateAnalytics.ts`
  - Runs every 5 minutes (cron or manual)
  - Incremental processing (only updated projects)
  - Processes 100+ projects within 5-minute window
  - Tracks last run time in `system_settings` collection
  - Batch upserts (50 projects per batch)
  - Creates detailed logs in `aggregation_logs` collection

- **Calculation Engine**: `lib/analyticsCalculator.ts`
  - CPM-based business model calculations
  - Fan metrics (engagement, core fan team value)
  - Merchandise metrics (penetration rate, diversity)
  - Advertisement metrics (ROI, viral coefficient)
  - Demographic distributions
  - Visit source tracking
  - Bitly analytics integration

**2. Database Collections**

```typescript
// analytics_aggregates - Pre-computed event metrics
{
  _id: ObjectId,
  projectId: ObjectId,
  eventDate: string,
  aggregationType: 'event',
  partnerContext: {
    partnerId?: ObjectId,
    opponentId?: ObjectId,
    partnerName?: string,
    partnerEmoji?: string,
    opponentName?: string,
    opponentEmoji?: string,
    isHomeGame?: boolean
  },
  fanMetrics: {
    totalFans: number,
    remoteFans: number,
    stadium: number,
    engagementRate: number,
    remoteQuality: number,
    stadiumQuality: number,
    selfieRate: number,
    coreFanTeam: number,
    fanToAttendeeConversion: number
  },
  merchMetrics: {
    totalMerched: number,
    penetrationRate: number,
    byType: {
      jersey: number,
      scarf: number,
      flags: number,
      baseballCap: number,
      other: number
    },
    merchToAttendee: number,
    diversityIndex: number,
    highValueFans: number,
    casualFans: number
  },
  adMetrics: {
    totalImpressions: number,
    socialValue: number,
    emailValue: number,
    totalROI: number,
    viralCoefficient: number,
    emailConversion: number,
    costPerEngagement: number,
    adValuePerFan: number,
    reachMultiplier: number
  },
  demographicMetrics: { /* age and gender distributions */ },
  visitMetrics: { /* visit source tracking */ },
  bitlyMetrics: { /* optional Bitly analytics */ },
  rawStats: { /* original project.stats */ },
  version: string,
  createdAt: string,
  updatedAt: string
}

// aggregation_logs - Job performance tracking
{
  _id: ObjectId,
  jobType: 'event_aggregation',
  status: 'success' | 'partial_failure' | 'failed',
  startTime: string,
  endTime: string,
  duration: number,
  projectsProcessed: number,
  projectsFailed: number,
  errors: Array<{ projectId: ObjectId, errorMessage: string }>,
  avgProcessingTime: number,
  maxProcessingTime: number,
  createdAt: string // TTL: 30 days
}
```

**3. Business Model Constants**

```typescript
AD_MODEL_CONSTANTS = {
  EMAIL_OPTIN_CPM: €4.87,        // Email opt-in value per 1000 impressions
  EMAIL_ADDON_CPM: €1.07,        // Additional email opens value
  STADIUM_AD_CPM: €6.00,         // In-stadium ad exposure value
  SOCIAL_ORGANIC_CPM: €14.50,    // Social media organic impressions
  YOUTH_PREMIUM: €2.14,          // Premium for Gen Alpha/YZ demographics
  SOCIAL_SHARES_PER_IMAGE: 20,   // Average social shares per event image
  AVG_VIEWS_PER_SHARE: 300,      // Average views per social share
  EMAIL_OPEN_RATE: 0.35          // 35% average email open rate
}
```

**4. MongoDB Indexes (20 total across 4 collections)**

- `analytics_aggregates`: projectId, eventDate, aggregationType, partnerId+eventDate (compound), updatedAt
- `partner_analytics`: partnerId, partnerType, partnerId+timeframe (unique compound), updatedAt
- `event_comparisons`: primaryProjectId, comparisonType, compound index
- `aggregation_logs`: startTime, status, jobType+startTime (compound), createdAt (TTL: 30 days)

**5. API Endpoints**

| Endpoint | Purpose | Performance | Query Params |
|----------|---------|-------------|---------------|
| `GET /api/analytics/event/[projectId]` | Single event metrics | <100ms | includeBitly, includeRaw |
| `GET /api/analytics/partner/[partnerId]` | Partner summary | <200ms | timeframe, includeEvents |
| `GET /api/analytics/trends` | Time-series data | <500ms (1-year) | startDate, endDate, partnerId, metrics, groupBy |
| `GET /api/analytics/compare` | Event comparison | <300ms (5 events) | projectIds, metrics |
| `GET /api/analytics/benchmarks` | Industry benchmarks | <500ms (full dataset) | category, metric, period |

### Type System

**Core Types** (`lib/analytics.types.ts`):
- `AnalyticsAggregate` - Complete aggregated event metrics
- `FanMetrics` - Fan engagement and conversion KPIs
- `MerchMetrics` - Merchandise penetration and diversity
- `AdMetrics` - Advertisement ROI and viral reach
- `DemographicMetrics` - Age and gender distributions
- `VisitMetrics` - Traffic source attribution
- `BitlyMetrics` - Link click analytics (optional)
- `PartnerAnalytics` - Partner-level summaries
- `EventComparison` - Comparative analysis results
- `AggregationLog` - Job execution tracking
- `AnalyticsAPIResponse` - Standardized API response

### Setup & Maintenance

**Initial Setup** (one-time):
```bash
npm run analytics:setup-indexes
```

**Background Aggregation** (every 5 minutes):
```bash
npm run analytics:aggregate
```

**Production Deployment**:
- **Vercel**: Use cron jobs or external scheduler (GitHub Actions, Vercel Cron)
- **Railway/Heroku**: Use native cron functionality
- **Manual**: Add cron entry on server

**Monitoring**:
- Check `aggregation_logs` collection for job status
- Monitor job duration (should be <5 minutes)
- Track `projectsFailed` for data quality issues
- Verify index performance with MongoDB Atlas metrics

### Performance Characteristics

**Aggregation Job**:
- Duration: 1-2 seconds for 50 projects
- Throughput: 25-50 projects/second
- Memory: <100MB for 200 projects
- CPU: Single-core, <50% utilization

**API Response Times** (actual measured):
- Event endpoint: 50-80ms (cached aggregate lookup)
- Partner endpoint: 100-150ms (aggregates across events)
- Trends endpoint: 200-400ms (1-year dataset with filtering)
- Compare endpoint: 150-250ms (5 events with calculations)
- Benchmarks endpoint: 300-450ms (full dataset statistical analysis)

**Database Performance**:
- Aggregate collection size: ~5KB per event
- Index overhead: ~15% of collection size
- Query execution: <10ms with proper indexes
- Concurrent queries: Supports 100+ simultaneous API requests

### Future Enhancements (Phase 2+)

**Phase 2: Insights Engine** (Q1-Q2 2026)
- Predictive attendance modeling
- Anomaly detection for unusual metrics
- Automated insights generation
- Recommendation engine for improvement

**Phase 3: Advanced Dashboards** (Q2 2026)
- Executive summary dashboards
- Partner performance scorecards
- Trend visualization widgets
- Custom report builder

**Phase 4: Reporting & Export** (Q2 2026)
- PDF report generation
- Excel export with formatting
- Scheduled email reports
- White-label partner reports

---

## Future Enhancements

### Planned Features (Version 2.3.0+)
- **Shareables Component Library** - Extract reusable components for other projects
- **Import/Export** - Category-aware project data migration tools
- **Team Collaboration** - Shared category definitions across team projects

### Technical Debt
- Consider MongoDB aggregation pipelines for complex filtering scenarios
- Implement caching layer for frequently accessed hashtag categories
- Add comprehensive error handling for category-related operations

---

## Contributing

When working with the hashtag categories system:

1. **Utility Functions**: Always use `hashtagCategoryUtils.ts` functions for consistency
2. **API Design**: Maintain backward compatibility when modifying hashtag-related endpoints
3. **UI Components**: Follow the established pattern for category color application
4. **Testing**: Manually validate both traditional and categorized hashtag workflows
5. **Documentation**: Update this document when adding new category-related features

---

*Last Updated: 2025-10-19T11:58:43.000Z*  
*Version: 6.26.0*  
*Status: Production-Ready — Enterprise Event Analytics Platform with Advanced Analytics Infrastructure*
